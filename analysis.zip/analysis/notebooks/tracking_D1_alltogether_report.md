# D1 Pairwise + Global Aggregated Tracking Report (globally comparable sites only)

- Locations : **ALGERIA, GERMANY, INDIA, USA**
- Category : **global**

## Overall tracking requests observed from one location but not another:

- Total vantage point-specific tracking requests (all directions): **155,505**
- Requests with reconstructed script inclusion chains: **152,093** (97.81%)
- Requests without chain: **3,412** (2.19%)

Among requests with reconstructed chains, we distinguish:


- **Behavioral differences**: Parent script loaded in both locations, but tracking only in one location: **38,138** (25.08%)
- **Inclusion differences**: Parent script included in only one location: **93,290** (61.34%)
- **First-party inline**: **20,665** (13.59%)

## Which countries contribute most third-party location-specific requests?

| Country (src) | 3P location-specific requests | Share of all 3P diff requests |
| --- | --- | --- |
| GERMANY | 58,292 | 38.42% |
| USA | 49,779 | 32.81% |
| INDIA | 22,955 | 15.13% |
| ALGERIA | 20,683 | 13.63% |


## Top third-party domains 

| Domain (eTLD+1) | Count | Share of all 3P diff requests |
| --- | --- | --- |
| googlesyndication.com | 8,284 | 5.46% |
| doubleclick.net | 7,990 | 5.27% |
| rubiconproject.com | 5,398 | 3.56% |
| googletagmanager.com | 5,149 | 3.39% |
| google.com | 4,685 | 3.09% |
| yandex.com | 3,780 | 2.49% |
| google-analytics.com | 3,413 | 2.25% |
| pubmatic.com | 3,263 | 2.15% |
| adnxs.com | 3,140 | 2.07% |
| tiktok.com | 2,214 | 1.46% |

## Top third-party domains per country (source vantage point)

Counts are restricted to **third-party (cross-site)** location-specific requests.

### ALGERIA

| Domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| doubleclick.net | 806 | 3.90% |
| google.dz | 801 | 3.87% |
| rubiconproject.com | 789 | 3.81% |
| pubmatic.com | 634 | 3.07% |
| googlesyndication.com | 495 | 2.39% |
| google.com | 486 | 2.35% |
| googletagmanager.com | 465 | 2.25% |
| adnxs.com | 389 | 1.88% |
| tsyndicate.com | 374 | 1.81% |
| google-analytics.com | 349 | 1.69% |

### GERMANY

| Domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| googlesyndication.com | 4,223 | 7.24% |
| doubleclick.net | 2,864 | 4.91% |
| rubiconproject.com | 2,623 | 4.50% |
| yandex.com | 2,141 | 3.67% |
| googletagmanager.com | 1,776 | 3.05% |
| google.com | 1,690 | 2.90% |
| tiktok.com | 1,435 | 2.46% |
| google.de | 1,333 | 2.29% |
| google-analytics.com | 1,326 | 2.27% |
| criteo.net | 1,243 | 2.13% |

### INDIA

| Domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| doubleclick.net | 1,481 | 6.45% |
| google.co.in | 1,457 | 6.35% |
| googletagmanager.com | 1,205 | 5.25% |
| googlesyndication.com | 969 | 4.22% |
| google.com | 883 | 3.85% |
| google-analytics.com | 765 | 3.33% |
| yandex.ru | 471 | 2.05% |
| adsco.re | 460 | 2.00% |
| rubiconproject.com | 449 | 1.96% |
| adnxs.com | 309 | 1.35% |

### USA

| Domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| doubleclick.net | 2,839 | 5.70% |
| googlesyndication.com | 2,597 | 5.22% |
| googletagmanager.com | 1,703 | 3.42% |
| yandex.com | 1,632 | 3.28% |
| google.com | 1,626 | 3.27% |
| rubiconproject.com | 1,537 | 3.09% |
| cloudflareinsights.com | 1,448 | 2.91% |
| pubmatic.com | 1,299 | 2.61% |
| adnxs.com | 1,200 | 2.41% |
| google-analytics.com | 973 | 1.95% |

## Behavioral differences: what are the most common scripts that behave differently

### ALGERIA: Top script src (

| Script src (full) | Count | Share within country |
| --- | --- | --- |
| https://www.googletagmanager.com/gtm.js?id=GTM-WQMQH4C6 | 1,572 | 21.75% |
| /cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js | 279 | 3.86% |
| https://securepubads.g.doubleclick.net/tag/js/gpt.js | 204 | 2.82% |
| https://platform.pubadx.one/pubadx-ad.js | 119 | 1.65% |
| //www.googletagmanager.com/gtm.js?id=GTM-KDDQ7L | 115 | 1.59% |
| //appointeeivyspongy.com/bn.js | 104 | 1.44% |
| //c.amazon-adsystem.com/aax2/apstag.js | 101 | 1.40% |
| https://js.wpadmngr.com/static/adManager.js | 87 | 1.20% |
| /_next/static/chunks/8687-9110b307fb2b05f2.js | 87 | 1.20% |
| /scripts/comingsoon_it_refresh.js | 85 | 1.18% |

**Example:**

- manhuafast.net / https://manhuafast.net/manga/astral-pet-store/chapter-190/: script `https://platform.pubadx.one/pubadx-ad.js` triggers a request to `mbidinp.com` in **ALGERIA**, but the request is not observed in **GERMANY** (dst match found on `https://platform.pubadx.one/pubadx-ad.js`).
- www.etihad.com / https://www.etihad.com/en-ae/etihadguest/miles-calculator: script `https://www.googletagmanager.com/gtm.js?id=GTM-WQMQH4C6` triggers a request to `clmbtech.com` in **ALGERIA**, but the request is not observed in **USA** (dst match found on `https://www.googletagmanager.com/gtm.js?id=GTM-WQMQH4C6`).

### ALGERIA: Top script src domains

| Script domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| googletagmanager.com | 2,756 | 38.13% |
| unknown | 2,318 | 32.07% |
| doubleclick.net | 204 | 2.82% |
| pubadx.one | 119 | 1.65% |
| wpadmngr.com | 90 | 1.25% |
| .. | 86 | 1.19% |
| ay.delivery | 77 | 1.07% |
| premiumads.com.br | 72 | 1.00% |
| usync.js | 53 | 0.73% |
| colamanga.com | 52 | 0.72% |

### GERMANY: Top script src (full URL)

| Script src (full) | Count | Share within country |
| --- | --- | --- |
| https://mc.yandex.ru/metrika/tag.js | 1,067 | 7.85% |
| /cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js | 905 | 6.66% |
| /sum.js?i=homep-desk&v=25320.020527&referrer_url=https%3A%2F%2Fwww.milffox.com%2Fmilf-pornstars%2FEmma-Butt%2F&referrer_site=&kw=%keywords% | 532 | 3.91% |
| https://securepubads.g.doubleclick.net/tag/js/gpt.js | 392 | 2.88% |
| https://www.googletagmanager.com/gtm.js?id=GTM-P78V88W4 | 327 | 2.41% |
| //d.otaserve.net/r/www/delivery/asyncjs.php | 306 | 2.25% |
| //www.googletagmanager.com/gtm.js?id=GTM-5RZ7W8C | 304 | 2.24% |
| //cdn.tsyndicate.com/sdk/v1/master.spot.js | 219 | 1.61% |
| /_adv/lib/v9/prebid9.50.0.js | 193 | 1.42% |
| https://js.wpadmngr.com/static/adManager.js | 181 | 1.33% |

**Examples:**

- www.paypal.com / https://www.paypal.com/myaccount/privacy/cookiePrefs: script `https://www.paypalobjects.com/pa/js/min/pa.js` triggers a request to `doubleclick.net` in **GERMANY**, but the request is not observed in **INDIA** (dst match found on `https://www.paypalobjects.com/martech/tm/paypal/mktgtagmanager.js`).
- it.youporn.com / https://it.youporn.com/: script `https://www.googletagmanager.com/gtm.js?id=GTM-W7HK5Q7` triggers a request to `google-analytics.com` in **GERMANY**, but the request is not observed in **ALGERIA** (dst match found on `https://www.googletagmanager.com/gtm.js?id=GTM-W7HK5Q7`).

### GERMANY: Top script src domains

| Script domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| unknown | 5,622 | 41.35% |
| googletagmanager.com | 2,417 | 17.78% |
| yandex.ru | 1,157 | 8.51% |
| doubleclick.net | 412 | 3.03% |
| wpadmngr.com | 184 | 1.35% |
| evolutionadv.it | 178 | 1.31% |
| usync.js | 176 | 1.29% |
| cookielaw.org | 129 | 0.95% |
| adsninja.ca | 112 | 0.82% |
| webvisor.org | 106 | 0.78% |

### INDIA: Top script src (full URL)

| Script src (full) | Count | Share within country |
| --- | --- | --- |
| /cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js | 226 | 3.53% |
| https://securepubads.g.doubleclick.net/tag/js/gpt.js | 190 | 2.97% |
| https://js.wpadmngr.com/static/adManager.js | 186 | 2.90% |
| //s10.histats.com/js15_as.js | 165 | 2.58% |
| https://api.ww.com/privacy-control/js/privacy.min.js | 112 | 1.75% |
| https://www.googletagmanager.com/gtm.js?id=GTM-KX367LN | 110 | 1.72% |
| https://media1.admicro.vn/cms/Arf.min.js | 101 | 1.58% |
| //get.optad360.io/sf/e490bd92-6cf2-11e8-88d7-06048607e8f8/plugin.min.js | 80 | 1.25% |
| https://d3u598arehftfk.cloudfront.net/prebid_hb_11797_24028.js | 73 | 1.14% |
| https://platform.pubadx.one/pubadx-ad.js | 60 | 0.94% |

**Examples:**

- hqporn.xxx / https://hqporn.xxx/alias/jade-luv/: script `https://cdn.wolf-327b.com/rdr/renderer.js` triggers a request to `tsyndicate.com` in **INDIA**, but the request is not observed in **GERMANY** (dst match found on `https://cdn.wolf-327b.com/rdr/renderer.js`).
- www.itmedia.co.jp / https://www.itmedia.co.jp/keywords/disaster.html: script `https://sync.logly.co.jp/sync/sync.js` triggers a request to `pubmatic.com` in **INDIA**, but the request is not observed in **USA** (dst match found on `https://sync.logly.co.jp/sync/sync.js`).



### INDIA: Top script src domains

| Script domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| unknown | 2,022 | 31.56% |
| googletagmanager.com | 1,721 | 26.87% |
| doubleclick.net | 190 | 2.97% |
| wpadmngr.com | 189 | 2.95% |
| ww.com | 112 | 1.75% |
| admicro.vn | 101 | 1.58% |
| cloudfront.net | 91 | 1.42% |
| datadoghq-browser-agent.com | 64 | 1.00% |
| pubadx.one | 60 | 0.94% |
| cookielaw.org | 55 | 0.86% |

### USA: Top script src (full URL)

| Script src (full) | Count | Share within country |
| --- | --- | --- |
| https://mc.yandex.ru/metrika/tag.js | 741 | 6.95% |
| /cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js | 554 | 5.20% |
| https://securepubads.g.doubleclick.net/tag/js/gpt.js | 396 | 3.72% |
| //www.googletagmanager.com/gtm.js?id=GTM-KDDQ7L | 285 | 2.67% |
| //s10.histats.com/js15_as.js | 216 | 2.03% |
| https://platform.pubadx.one/pubadx-ad.js | 199 | 1.87% |
| //waust.at/s.js | 149 | 1.40% |
| https://static.rba.nom.es/ads/pb9-general_250916.js | 148 | 1.39% |
| //cdn.intergient.com/1025267/74951/ramp_config.js | 142 | 1.33% |
| https://JRyhoywLYXNLYMAhs.ay.delivery/manager/JRyhoywLYXNLYMAhs | 141 | 1.32% |

**Examples:**

- rutube.ru / https://rutube.ru/forms/problem/: script `https://mc.yandex.ru/metrika/tag.js` triggers a request to `yandex.com` in **USA**, but the request is not observed in **GERMANY** (dst match found on `https://mc.yandex.ru/metrika/tag.js`).
- 5278.cc / https://5278.cc/: script `//waust.at/c.js` triggers a request to `eyeota.net` in **USA**, but the request is not observed in **GERMANY** (dst match found on `https://cdn.tynt.com/tc.js`).


### USA: Top script src domains

| Script domain (eTLD+1) | Count | Share within country |
| --- | --- | --- |
| googletagmanager.com | 1,534 | 14.39% |
| yandex.ru | 829 | 7.78% |
| doubleclick.net | 398 | 3.73% |
| pubadx.one | 199 | 1.87% |
| rba.nom.es | 148 | 1.39% |
| ay.delivery | 141 | 1.32% |
| adobedtm.com | 134 | 1.26% |
| adsninja.ca | 116 | 1.09% |
| sascdn.com | 112 | 1.05% |
