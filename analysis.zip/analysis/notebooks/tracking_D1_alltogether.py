#!/usr/bin/env python3
"""
D1 pairwise + global aggregated tracking report + JSON examples per attribution class,
WITH GLOBAL SITE FILTERING:

We first build the set of (site, normalized_url) that appear in *all* locations,
then we restrict ALL reporting/aggregation to ONLY records whose site is in that set.

This uses the DB (crawl_sessions) to build the intersection set once, so it is not
biased to “sites that happened to have diffs”.

Inputs (expected in --d1_dir):
  - <SRC>_TO_<DST>_summary.json
  - <SRC>_TO_<DST>_details.jsonl

Outputs (written into --out_dir, default: current working directory):
  - ./tracking_D1_alltogether_report.md
  - ./examples/behavioral_differences.json
  - ./examples/inclusion_differences.json
  - ./examples/first_party_inline_roots.json

Notes:
- "Top script src" uses the first external anchor in the source inclusion chain (full URL),
  scanning top->tail and preferring script.script_src, else html.src.
- Script-domain grouping uses eTLD+1 of that script src host (fallback to host).
- Per-country tables and examples are restricted to 3P diffs (etld_request_url_rel == cross-site).
"""

import argparse
import glob
import json
import os
import random
from collections import Counter, defaultdict
from urllib.parse import urlparse, urlunparse
from pymysql.cursors import DictCursor

# ---- NEW: DB access for global intersection ----
import pymysql
db_params = dict(
    host='localhost',
    user='cursor',
    password='whaTaShame',
    db='crawl_analysis_new',
    cursorclass=DictCursor

)

# -------------------------
# Helpers
# ------------------------- 

def pct(x: int, y: int) -> float:
    return 0.0 if y == 0 else 100.0 * (x / y)

def normalize_url(u: str) -> str:
    """
    Conservative URL normalization for joining across sources:
      - ensure scheme exists (assume http if missing)
      - lowercase hostname
      - drop fragment
      - keep path + query
      - strip default ports
      - normalize trailing slash (keep '/' for root, otherwise strip one trailing '/')
    """
    if not u:
        return ""
    u = str(u).strip()
    if not u:
        return ""
    if "://" not in u:
        u = "http://" + u
    try:
        p = urlparse(u)
        scheme = (p.scheme or "http").lower()
        netloc = (p.netloc or "").strip().lower()
        if "@" in netloc:
            netloc = netloc.split("@", 1)[1]
        # strip port if default
        if ":" in netloc:
            host, port = netloc.rsplit(":", 1)
            if (scheme == "http" and port == "80") or (scheme == "https" and port == "443"):
                netloc = host
        path = p.path or "/"
        if path != "/" and path.endswith("/"):
            path = path[:-1]
        # drop fragment
        return urlunparse((scheme, netloc, path, "", p.query or "", ""))
    except Exception:
        return u.strip()

def host_from_url(u: str) -> str:
    if not u:
        return ""
    u = str(u).strip()
    if not u:
        return ""
    if "://" not in u:
        u = "http://" + u
    try:
        host = urlparse(u).netloc.split(":")[0].lower()
        if "@" in host:
            host = host.split("@", 1)[1]
        return host
    except Exception:
        return ""

try:
    import tldextract
    _EXT = tldextract.TLDExtract(suffix_list_urls=None)

    def etld_plus_one(host: str) -> str:
        ext = _EXT(host)
        if ext.domain and ext.suffix:
            return f"{ext.domain}.{ext.suffix}"
        return ""
except Exception:
    def etld_plus_one(host: str) -> str:
        host = (host or "").strip().lower().strip(".")
        parts = [p for p in host.split(".") if p]
        return ".".join(parts[-2:]) if len(parts) >= 2 else host

def domain_from_url(u: str) -> str:
    host = host_from_url(u)
    dom = etld_plus_one(host)
    return dom or host or "unknown"

def classify_fp_tp_from_rel(rel: str) -> str:
    rel = (rel or "").strip().lower()
    if rel in ("same-site", "same-origin"):
        return "first_party"
    if rel == "cross-site":
        return "third_party"
    return "unknown"

def parse_pair_from_filename(path: str):
    base = os.path.basename(path)
    # e.g., ALGERIA_TO_USA_summary.json
    if "_TO_" not in base:
        return None
    left = base.split("_TO_", 1)[0]
    rest = base.split("_TO_", 1)[1]
    right = rest.split("_", 1)[0]
    return left, right

def load_summary(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    return obj.get("summary", obj)

def iter_details_jsonl(path: str):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)

def md_table(headers, rows):
    out = []
    out.append("| " + " | ".join(headers) + " |")
    out.append("| " + " | ".join(["---"] * len(headers)) + " |")
    for r in rows:
        out.append("| " + " | ".join(str(x) for x in r) + " |")
    return "\n".join(out)

def first_external_anchor_from_chain(chain):
    """
    Return (anchor_url, anchor_kind) from src chain.
    - Scans top->tail.
    - Prefers script_src, else html src.
    """
    if not chain:
        return "", ""
    for node in chain:
        kind = (node.get("kind") or "").strip().lower()
        if kind == "script":
            v = (node.get("script_src") or "").strip()
            if v:
                return v, "script_src"
        else:
            v = (node.get("src") or "").strip()
            if v:
                return v, "src"
    return "", ""

def reservoir_add_state(state: dict, key, item, k: int):
    """
    Uniform random k-sample from a stream per key.
    state[key] = {"seen": int, "items": list}
    """
    if k <= 0:
        return
    st = state.setdefault(key, {"seen": 0, "items": []})
    st["seen"] += 1
    seen = st["seen"]
    items = st["items"]
    if len(items) < k:
        items.append(item)
    else:
        j = random.randint(1, seen)
        if j <= k:
            items[j - 1] = item


# -------------------------
# NEW: Build global comparable set from DB
# -------------------------

def infer_locations_from_summaries(summary_paths):
    locs = set()
    for sp in summary_paths:
        pair = parse_pair_from_filename(sp)
        if not pair:
            continue
        a, b = pair
        locs.add(a)
        locs.add(b)
    return sorted(locs)

def load_common_sites_all_locations(category: str, locations):
    """
    Returns a set of keys: (etld, normalized_url)
    containing only sites that exist in crawl_sessions for *every* location.

    Matches your D1 selection constraints from the first script:
      - etld_url_rel <> 'cross-site'
      - is_cloudflare is not True
      - category = <category>
      - location in <locations>
    """
    if not locations:
        return set()

    placeholders = ",".join(["%s"] * len(locations))
    sql = f"""
        SELECT location, etld, url
        FROM crawl_sessions
        WHERE etld_url_rel <> 'cross-site'
          AND is_cloudflare is not True
          AND category = %s
          AND location IN ({placeholders})
    """

    per_loc = {loc: set() for loc in locations}

    conn = pymysql.connect(**db_params)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (category, *locations))
            for r in cur.fetchall():
                loc = r.get("location")
                etld = r.get("etld")
                url = r.get("url")
                if not loc or loc not in per_loc:
                    continue
                key = (str(etld), normalize_url(url))
                per_loc[loc].add(key)
    finally:
        conn.close()

    # intersection across all locations
    common = None
    for loc in locations:
        s = per_loc.get(loc, set())
        common = s if common is None else (common & s)
    return common or set()


# -------------------------
# Main
# -------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--d1_dir", default="../processed_data/tracking/D1")
    ap.add_argument("--out_dir", default=".",
                    help="Output directory for the markdown + examples. Default: current directory.")
    ap.add_argument("--out_md", default="tracking_D1_alltogether_report.md")
    ap.add_argument("--max_pairs_in_report", type=int, default=30,
                    help="How many unordered pairs to include in the pairwise table (sorted by 3P volume).")
    ap.add_argument("--examples_per_class", type=int, default=100,
                    help="Max full JSON examples to store per attribution class.")
    ap.add_argument("--example_src_locs", default="USA,GERMANY",
                    help="Comma-separated list of src locations allowed for FULL JSON example files. Default: USA,GERMANY")

    ap.add_argument("--topk", type=int, default=10, help="Top-K rows for per-country tables (default 10).")
    ap.add_argument("--examples_per_country", type=int, default=10,
                    help="Random examples per country after each per-country script table section (default 10).")
    ap.add_argument("--seed", type=int, default=1337, help="Random seed (default 1337).")
    ap.add_argument("--md_example_src_locs", default="",
                    help=("Optional comma-separated list of src locations to restrict Markdown examples. "
                          "Empty means no restriction for Markdown examples."))

    # NEW: global comparable filter controls
    ap.add_argument("--category", default="global", help="crawl_sessions.category to use for DB intersection (default: global).")
    ap.add_argument("--locations", default="",
                    help=("Comma-separated list of locations for the 'present in all locations' filter. "
                          "If empty, infer from filenames in --d1_dir."))

    args = ap.parse_args()
    random.seed(args.seed)

    d1_dir = args.d1_dir
    out_dir = args.out_dir
    os.makedirs(out_dir, exist_ok=True)
    out_md_path = os.path.join(out_dir, args.out_md)

    allowed_example_src_locs = {x.strip() for x in args.example_src_locs.split(",") if x.strip()}
    if not allowed_example_src_locs:
        allowed_example_src_locs = {"USA", "GERMANY"}  # fallback

    md_allowed_src_locs = {x.strip() for x in args.md_example_src_locs.split(",") if x.strip()}
    # if empty -> allow all

    summary_paths = sorted(glob.glob(os.path.join(d1_dir, "*_summary.json")))
    if not summary_paths:
        raise SystemExit(f"No summary files found in {d1_dir}")

    # ---- Determine locations for global comparable set ----
    if args.locations.strip():
        all_locs = [x.strip() for x in args.locations.split(",") if x.strip()]
    else:
        print('hna')
        all_locs = infer_locations_from_summaries(summary_paths)
        print('hna', all_locs)

    # ---- Build global comparable site set ONCE (from DB) ----

    common_sites = load_common_sites_all_locations(args.category, all_locs)
    if not common_sites:
        raise SystemExit("Common site set is empty. Check --category/--locations or crawl_sessions filters.")

    # ---- Aggregates from summaries (for decomposition + prevalence) ----
    dir_stats = {}  # (src,dst) -> dict

    total_diff_all = 0
    total_with_chain_all = 0
    total_without_chain_all = 0

    sum_found = 0
    sum_inline = 0
    sum_not_found = 0

    # ---- Aggregates from details (for 3P/1P and country dominance) ----
    dir_3p = Counter()   # (src,dst) -> count of 3P diffs (AFTER FILTER)
    dir_1p = Counter()   # (src,dst) -> count of 1P diffs (AFTER FILTER)

    country_3p_as_src = Counter()
    country_1p_as_src = Counter()

    country_top_3p_domains = defaultdict(Counter)  # src country -> Counter(domain)
    overall_top_3p_domains = Counter()

    # ---- Top script srcs per country per attribution class (3P only, AFTER FILTER) ----
    country_behavioral_script_src_full = defaultdict(Counter)   # src -> Counter(full_url)
    country_behavioral_script_src_dom  = defaultdict(Counter)   # src -> Counter(domain)

    country_inclusion_script_src_full  = defaultdict(Counter)   # src -> Counter(full_url)
    country_inclusion_script_src_dom   = defaultdict(Counter)   # src -> Counter(domain)

    # ---- Random examples per country (Markdown examples; 3P only, AFTER FILTER) ----
    EXK = int(args.examples_per_country)
    ex_behavioral_by_country = {}  # key=src -> reservoir
    ex_inclusion_by_country  = {}

    # ---- Example collectors (full JSON records; AFTER FILTER) ----
    MAX_EX = int(args.examples_per_class)
    examples_behavioral = []
    examples_inclusion = []
    examples_inline = []

    # ---- Load summaries (kept mainly for global breakdown headings; but note: we will recompute counts from details after filtering) ----
    for sp in summary_paths:
        pair = parse_pair_from_filename(sp)
        if not pair:
            continue
        src, dst = pair
        summ = load_summary(sp)
        st = summ.get("stats", {})

        dir_stats[(src, dst)] = {
            "summary_path": sp,
            "details_path": os.path.join(d1_dir, f"{src}_TO_{dst}_details.jsonl"),
            # keep original for metadata only
            "comparable_sites_raw": int(st.get("comparable_sites", 0)),
            "comparable_urls_raw": int(st.get("comparable_urls", 0)),
        }

    # ---- IMPORTANT: Recompute ALL totals FROM DETAILS, restricted to common_sites ----
    # This ensures your global percentages reflect the "appears in all locations" subset.
    total_diff_all = 0
    total_with_chain_all = 0
    total_without_chain_all = 0
    sum_found = 0
    sum_inline = 0
    sum_not_found = 0

    # Scan details with the common-site filter
    for (src, dst), st in dir_stats.items():
        dp = st["details_path"]
        if not os.path.exists(dp):
            continue

        for rec in iter_details_jsonl(dp):
            site = rec.get("site", {}) or {}
            etld = site.get("etld", "")
            page_url = site.get("page_url", "")
            site_key = (str(etld), normalize_url(page_url))

            # ---- FILTER: keep only globally comparable sites ----
            if site_key not in common_sites:
                continue

            req = rec.get("request", {}) or {}
            rel = (req.get("etld_request_url_rel") or "").strip().lower()
            party = classify_fp_tp_from_rel(rel)

            src_loc = rec.get("direction", {}).get("src_loc") or src
            dst_loc = rec.get("direction", {}).get("dst_loc") or dst

            match = rec.get("dst_match_attempt", {}) or {}
            found_flag = bool(match.get("found", False))
            reason = (match.get("reason") or "").strip()

            # ---- Global decomposition denominators (ALL requests, not only 3P) ----
            total_diff_all += 1
            chain = rec.get("html_chain_src_top_to_tail", []) or []
            has_chain = bool(chain)
            if has_chain:
                total_with_chain_all += 1
                if found_flag:
                    sum_found += 1
                elif reason == "inline_chain_no_src":
                    sum_inline += 1
                else:
                    # treat everything else among with-chain as "no_src_match"/not_found; in your generator it is "no_src_match" or inline
                    # we follow your earlier report mapping: inclusion is no_src_match
                    if reason == "no_src_match":
                        sum_not_found += 1
                    else:
                        # fallback bucket counts as "not_found" to keep totals consistent
                        sum_not_found += 1
            else:
                total_without_chain_all += 1

            # ---- Per-direction party counts (AFTER FILTER) ----
            if party == "third_party":
                dir_3p[(src, dst)] += 1
                country_3p_as_src[src_loc] += 1

                dom = domain_from_url(req.get("request_url", ""))
                country_top_3p_domains[src_loc][dom] += 1
                overall_top_3p_domains[dom] += 1

            elif party == "first_party":
                dir_1p[(src, dst)] += 1
                country_1p_as_src[src_loc] += 1

            # ---- Collect FULL JSON examples (restricted, AFTER FILTER) ----
            if src_loc in allowed_example_src_locs:
                if found_flag and len(examples_behavioral) < MAX_EX:
                    examples_behavioral.append(rec)
                elif reason == "inline_chain_no_src" and len(examples_inline) < MAX_EX:
                    examples_inline.append(rec)
                elif reason == "no_src_match" and len(examples_inclusion) < MAX_EX:
                    examples_inclusion.append(rec)

            # ---- Per-country script src tables + Markdown examples (3P only, AFTER FILTER) ----
            if party != "third_party":
                continue

            # optional restriction for markdown examples
            pass_restrict_md = (not md_allowed_src_locs) or (src_loc in md_allowed_src_locs)

            root_anchor, root_anchor_kind = first_external_anchor_from_chain(chain)
            root_anchor = (root_anchor or "").strip()
            root_dom = domain_from_url(root_anchor) if root_anchor else "unknown"

            request_url = (req.get("request_url") or "").strip()
            request_dom = domain_from_url(request_url)

            if found_flag:
                if root_anchor:
                    country_behavioral_script_src_full[src_loc][root_anchor] += 1
                    country_behavioral_script_src_dom[src_loc][root_dom] += 1

                if pass_restrict_md:
                    example_item = {
                        "src": src_loc,
                        "dst": dst_loc,
                        "etld": etld,
                        "page_url": page_url,
                        "root_script_src": root_anchor,
                        "root_script_kind": root_anchor_kind,
                        "request_url": request_url,
                        "request_domain": request_dom,
                        "dst_matched_kind": match.get("matched_kind", ""),
                        "dst_matched_value": match.get("matched_value", ""),
                        "dst_matched_on": match.get("matched_on", ""),
                    }
                    reservoir_add_state(ex_behavioral_by_country, src_loc, example_item, EXK)

            elif reason == "no_src_match":
                if root_anchor:
                    country_inclusion_script_src_full[src_loc][root_anchor] += 1
                    country_inclusion_script_src_dom[src_loc][root_dom] += 1

                if pass_restrict_md:
                    example_item = {
                        "src": src_loc,
                        "dst": dst_loc,
                        "etld": etld,
                        "page_url": page_url,
                        "root_script_src": root_anchor,
                        "root_script_kind": root_anchor_kind,
                        "request_url": request_url,
                        "request_domain": request_dom,
                        "reason": reason,
                        "dst_top_anchor": match.get("top_anchor", ""),
                        "dst_top_anchor_key": match.get("top_anchor_key", ""),
                        "dst_top_has_anchor": match.get("top_has_anchor", ""),
                    }
                    reservoir_add_state(ex_inclusion_by_country, src_loc, example_item, EXK)

    # -------------------------
    # Build report tables (AFTER FILTER)
    # -------------------------

    # Country ranking by 3P diff requests
    total_3p_all = sum(country_3p_as_src.values())
    country_rows = []
    for c, cnt in country_3p_as_src.most_common():
        country_rows.append([c, f"{cnt:,}", f"{pct(cnt, total_3p_all):.2f}%"])

    # Pairwise dominance (unordered pairs)
    pair_rows = []
    seen_unordered = set()

    for (a, b) in dir_stats.keys():
        u = tuple(sorted([a, b]))
        if u in seen_unordered:
            continue
        seen_unordered.add(u)

        a_to_b_3p = dir_3p.get((a, b), 0)
        b_to_a_3p = dir_3p.get((b, a), 0)

        if b_to_a_3p > 0:
            ratio = a_to_b_3p / b_to_a_3p
        elif a_to_b_3p > 0:
            ratio = float("inf")
        else:
            ratio = 1.0

        pair_rows.append({
            "pair": f"{a} vs {b}",
            "a_to_b_3p": a_to_b_3p,
            "b_to_a_3p": b_to_a_3p,
            "ratio": ratio,
            "volume": a_to_b_3p + b_to_a_3p
        })

    pair_rows.sort(key=lambda x: x["volume"], reverse=True)
    pair_rows = pair_rows[:max(1, args.max_pairs_in_report)]

    pair_table_rows = []
    for r in pair_rows:
        ratio_str = "∞" if r["ratio"] == float("inf") else f"{r['ratio']:.2f}"
        pair_table_rows.append([
            r["pair"],
            f"{r['a_to_b_3p']:,}",
            f"{r['b_to_a_3p']:,}",
            ratio_str,
        ])

    # Overall decomposition (conditional on having chain)
    denom_chain = total_with_chain_all
    chain_coverage = pct(total_with_chain_all, total_diff_all)
    behavioral_pct = pct(sum_found, denom_chain)
    inclusion_pct = pct(sum_not_found, denom_chain)
    inline_pct = pct(sum_inline, denom_chain)

    # Top domains overall (3P only)
    topk = int(args.topk)
    top_domains_rows = []
    for dom, cnt in overall_top_3p_domains.most_common(topk):
        top_domains_rows.append([dom, f"{cnt:,}", f"{pct(cnt, total_3p_all):.2f}%"])

    # -------------------------
    # Write Markdown report
    # -------------------------

    with open(out_md_path, "w", encoding="utf-8") as out:
        out.write("# D1 Pairwise + Global Aggregated Tracking Report (globally comparable sites only)\n\n")
        out.write(f"- Input directory: `{os.path.abspath(d1_dir)}`\n")
        out.write(f"- Output directory: `{os.path.abspath(out_dir)}`\n")
        out.write(f"- Locations (for global comparable filter): **{', '.join(all_locs)}**\n")
        out.write(f"- Category (DB filter): **{args.category}**\n")
        out.write(f"- Globally comparable (site, normalized_url) count: **{len(common_sites):,}**\n")
        out.write(f"- Random seed: **{args.seed}**\n\n")

        out.write("## Overall PageGraph attribution breakdown (restricted to globally comparable sites)\n\n")
        out.write(f"- Total vantage point-specific tracking requests (all directions): **{total_diff_all:,}**\n")
        out.write(f"- Requests with reconstructed chain: **{total_with_chain_all:,}** ({chain_coverage:.2f}%)\n")
        out.write(f"- Requests without chain: **{total_without_chain_all:,}** ({pct(total_without_chain_all, total_diff_all):.2f}%)\n\n")

        out.write("Among requests with reconstructed chains, we distinguish:\n\n")
        out.write(f"- **Behavioral differences** (dst match found): **{sum_found:,}** ({behavioral_pct:.2f}%)\n")
        out.write(f"- **Inclusion differences** (no src match): **{sum_not_found:,}** ({inclusion_pct:.2f}%)\n")
        out.write(f"- **First-party inline root**: **{sum_inline:,}** ({inline_pct:.2f}%)\n\n")

        out.write("## Which countries contribute most third-party location-specific requests?\n\n")
        out.write("Counts below attribute each location-specific request to the **source** vantage point "
                  "(the country where it was observed), restricted to requests classified as "
                  "**third-party (cross-site)**.\n\n")
        out.write(md_table(
            ["Country (src)", "3P location-specific requests", "Share of all 3P diff requests"],
            country_rows
        ))
        out.write("\n\n")

        out.write("## Pairwise dominance examples (third-party requests)\n\n")
        out.write("For each unordered pair {A,B}, we compare the number of third-party requests observed in A but not B "
                  "vs. in B but not A.\n\n")
        out.write(md_table(
            ["Pair", "A→B 3P diff reqs", "B→A 3P diff reqs", "Ratio (A→B / B→A)"],
            pair_table_rows
        ))
        out.write("\n\n")

        out.write("## Top third-party domains (overall)\n\n")
        out.write(md_table(
            ["Domain (eTLD+1)", "Count", "Share of all 3P diff requests"],
            top_domains_rows
        ))
        out.write("\n\n")

        # ---- Top 3P domains per country ----
        out.write("## Top third-party domains per country (source vantage point)\n\n")
        out.write("Counts are restricted to **third-party (cross-site)** location-specific requests.\n\n")
        for c in sorted(country_top_3p_domains.keys()):
            total_c = sum(country_top_3p_domains[c].values())
            rows = []
            for dom, cnt in country_top_3p_domains[c].most_common(topk):
                rows.append([dom, f"{cnt:,}", f"{pct(cnt, total_c):.2f}%"])
            out.write(f"### {c}\n\n")
            out.write(md_table(["Domain (eTLD+1)", "Count", "Share within country"], rows))
            out.write("\n\n")

        # ---- Behavioral script sources per country ----
        out.write("## Behavioral differences: top script sources per country\n\n")
        out.write("We count the first external anchor in the **source** inclusion chain (full URL), among "
                  "third-party records classified as **behavioral** (dst match found).\n\n")

        for c in sorted(country_behavioral_script_src_full.keys()):
            out.write(f"### {c}: Top script src (full URL)\n\n")
            total_c = sum(country_behavioral_script_src_full[c].values())
            rows = []
            for src_url, cnt in country_behavioral_script_src_full[c].most_common(topk):
                rows.append([src_url, f"{cnt:,}", f"{pct(cnt, total_c):.2f}%"])
            out.write(md_table(["Script src (full)", "Count", "Share within country"], rows))
            out.write("\n\n")

            items = ex_behavioral_by_country.get(c, {}).get("items", [])
            out.write(f"**Examples (random, n={len(items)}):**\n\n")
            for ex in items:
                out.write(
                    f"- {ex.get('etld','')} / {ex.get('page_url','')}: "
                    f"script `{ex.get('root_script_src','')}` triggers a request to `{ex.get('request_domain','')}` "
                    f"in **{ex.get('src','')}**, but the request is not observed in **{ex.get('dst','')}** "
                    f"(dst match found on `{ex.get('dst_matched_value','')}`).\n"
                )
            out.write("\n")

            out.write(f"### {c}: Top script src domains\n\n")
            total_cd = sum(country_behavioral_script_src_dom[c].values())
            rowsd = []
            for dom, cnt in country_behavioral_script_src_dom[c].most_common(topk):
                rowsd.append([dom, f"{cnt:,}", f"{pct(cnt, total_cd):.2f}%"])
            out.write(md_table(["Script domain (eTLD+1)", "Count", "Share within country"], rowsd))
            out.write("\n\n")

        # ---- Inclusion script sources per country ----
        out.write("## Inclusion differences: top script sources per country\n\n")
        out.write("We count the first external anchor in the **source** inclusion chain (full URL), among "
                  "third-party records classified as **inclusion** (no src match in destination).\n\n")

        for c in sorted(country_inclusion_script_src_full.keys()):
            out.write(f"### {c}: Top script src (full URL)\n\n")
            total_c = sum(country_inclusion_script_src_full[c].values())
            rows = []
            for src_url, cnt in country_inclusion_script_src_full[c].most_common(topk):
                rows.append([src_url, f"{cnt:,}", f"{pct(cnt, total_c):.2f}%"])
            out.write(md_table(["Script src (full)", "Count", "Share within country"], rows))
            out.write("\n\n")

            items = ex_inclusion_by_country.get(c, {}).get("items", [])
            out.write(f"**Examples (random, n={len(items)}):**\n\n")
            for ex in items:
                out.write(
                    f"- {ex.get('etld','')} / {ex.get('page_url','')}: "
                    f"script `{ex.get('root_script_src','')}` triggers a request to `{ex.get('request_domain','')}` "
                    f"in **{ex.get('src','')}**, and the anchor is not found in **{ex.get('dst','')}** "
                    f"(`reason=no_src_match`).\n"
                )
            out.write("\n")

            out.write(f"### {c}: Top script src domains\n\n")
            total_cd = sum(country_inclusion_script_src_dom[c].values())
            rowsd = []
            for dom, cnt in country_inclusion_script_src_dom[c].most_common(topk):
                rowsd.append([dom, f"{cnt:,}", f"{pct(cnt, total_cd):.2f}%"])
            out.write(md_table(["Script domain (eTLD+1)", "Count", "Share within country"], rowsd))
            out.write("\n\n")

        out.write("## JSON examples per attribution class\n\n")
        out.write("We write full JSON examples (including the source chain and, when applicable, the destination match chain) to:\n\n")
        out.write(f"- `./examples/behavioral_differences.json` (n={len(examples_behavioral)})\n")
        out.write(f"- `./examples/inclusion_differences.json` (n={len(examples_inclusion)})\n")
        out.write(f"- `./examples/first_party_inline_roots.json` (n={len(examples_inline)})\n\n")
        out.write(f"Full JSON examples are restricted to src locations: **{', '.join(sorted(allowed_example_src_locs))}**.\n")
        if md_allowed_src_locs:
            out.write(f"Markdown examples are restricted to src locations: **{', '.join(sorted(md_allowed_src_locs))}**.\n")
        else:
            out.write("Markdown examples are not restricted by src location.\n")
        out.write("\n")

    # -------------------------
    # Write JSON examples (full records)
    # -------------------------

    examples_dir = os.path.join(out_dir, "examples")
    os.makedirs(examples_dir, exist_ok=True)

    def dump_examples(fname: str, records: list):
        p = os.path.join(examples_dir, fname)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        return p

    p1 = dump_examples("behavioral_differences.json", examples_behavioral)
    p2 = dump_examples("inclusion_differences.json", examples_inclusion)
    p3 = dump_examples("first_party_inline_roots.json", examples_inline)

    print(f"[DONE] Wrote Markdown report: {out_md_path}")
    print("[DONE] Common site set size:", len(common_sites))
    print("[DONE] Wrote JSON examples:")
    print("  ", p1)
    print("  ", p2)
    print("  ", p3)


if __name__ == "__main__":
    main()
