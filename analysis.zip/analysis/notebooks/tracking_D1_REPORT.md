# D1 Tracking Difference Analysis Report
- Input directory: `/home/salim/Global-Privacy/analysis/processed_data/tracking/D1`
- Pairs analyzed: **12**

---

## ALGERIA → GERMANY
### Comparable denominators
- Compared sites: **5267**
- Compared URLs: **13769**
### Differences (from summary)
- Sites with tracking in src only: **2134** (40.52% of compared sites)
- URLs with tracking in src only: **4550** (33.05% of compared URLs)
- Total tracking requests in src only: **64253**
- Requests with chain: **63654** (99.07% of total-diff)
- Requests without chain: **599** (0.93% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **35126** (55.18% of with-chain)
- dst_chain_match_inline: **4964** (7.80% of with-chain)
- dst_chain_match_found: **23564** (37.02% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **435** (0.68%)
- `same-site`: **463** (0.72%)
- `cross-site`: **63355** (98.60%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **898** (1.40%)
- Third-party (cross-site): **63355** (98.60%)

### Top 10 third-party request domains (eTLD+1)
- `rubiconproject.com` — 3765 (5.94%)
- `pubmatic.com` — 2566 (4.05%)
- `doubleclick.net` — 2538 (4.01%)
- `googlesyndication.com` — 2269 (3.58%)
- `google.dz` — 1967 (3.10%)
- `adnxs.com` — 1820 (2.87%)
- `smartadserver.com` — 1375 (2.17%)
- `google.com` — 1317 (2.08%)
- `bidswitch.net` — 1180 (1.86%)
- `adsrvr.org` — 1164 (1.84%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 268 (29.84%)
- `/pmm/api/pmm/defined` — 31 (3.45%)
- `/pmm/api/pmm/api` — 12 (1.34%)
- `/wp-content/plugins/wp-rocket/assets/js/wpr-beacon.min.js` — 9 (1.00%)
- `/tag/opus.js` — 8 (0.89%)
- `/wm/record` — 6 (0.67%)
- `/ups/58784/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 6 (0.67%)
- `/ups/58824/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 6 (0.67%)
- `/ups/58831/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 6 (0.67%)
- `/ups/58834/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 6 (0.67%)

### `frame_main` distribution (details)
- main (1): **31393** (48.86%)
- non-main (0): **32860** (51.14%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 3016 (9.18%)
- `https://ssum-sec.casalemedia.com` — 1970 (6.00%)
- `https://visitor.omnitagjs.com` — 1874 (5.70%)
- `https://ads.pubmatic.com` — 1263 (3.84%)
- `https://sync.inmobi.com` — 1259 (3.83%)
- `https://ms-cookie-sync.presage.io` — 1176 (3.58%)
- `https://ssbsync.smartadserver.com` — 828 (2.52%)
- `https://csync.smartadserver.com` — 768 (2.34%)
- `https://ce.lijit.com` — 703 (2.14%)
- `https://prebid.a-mo.net` — 585 (1.78%)

### Tail of src chains (only among chains built)
- Chains built: **63654**
- Tail classified first-party: **7337** (11.53%)
- Tail classified third-party: **50856** (79.89%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 926 (1.82%)
- `https://js.datadome.co/tags.js` — 581 (1.14%)
- `https://hbagency.it/cdn/prebid_9_34_hb.js` — 401 (0.79%)
- `https://js.onclckmn.com/static/onclicka.js` — 336 (0.66%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 288 (0.57%)
- `https://cdn.id5-sync.com/api/1.0/id5PrebidModule.js` — 281 (0.55%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MWI5ZTBkMTQ4MQ.js` — 262 (0.52%)
- `https://lcdn.tsyndicate.com/sdk/v1/master.spot.js` — 254 (0.50%)
- `https://tags.crwdcntrl.net/lt/c/16589/sync.min.js` — 220 (0.43%)
- `https://hb.adpone.com/prebid9.30.0.js` — 206 (0.41%)

#### Top 10 first-party tail SRCs
- `usync.js` — 1255 (17.11%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 358 (4.88%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 192 (2.62%)
- `//cdn.tsyndicate.com/sdk/v1/master.spot.js` — 165 (2.25%)
- `//ib.adnxs.com/async_usersync?cbfn=queuePixels` — 144 (1.96%)
- `//cdn.snigelweb.com/prebid/9.43.0/prebid.js?v=16763-1761556481092` — 128 (1.74%)
- `//cdn.snigelweb.com/prebid/9.43.0/prebid.js?v=16645-1760696732927` — 117 (1.59%)
- `//s.lngtdv.com/prebid/calciomercato/prebid9.53.2.1754074900.min.js` — 93 (1.27%)
- `//cadmus.script.ac/d2uap9jskdzp2/script.js` — 90 (1.23%)
- `//secure.cdn.fastclick.net/js/pubcid/latest/pubcid.min.js` — 88 (1.20%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **23564**
- Matched SRC classified first-party: **7299** (30.98%)
- Matched SRC classified third-party: **16265** (69.02%)

#### Top 10 third-party matched SRCs (found)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 1612 (9.91%)
- `https://JRyhoywLYXNLYMAhs.ay.delivery/manager/JRyhoywLYXNLYMAhs` — 345 (2.12%)
- `https://cdn.snigelweb.com/adengine/notebookcheck.net/loader.js` — 279 (1.72%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 270 (1.66%)
- `https://lcdn.tsyndicate.com/sdk/v1/master.spot.js` — 254 (1.56%)
- `https://platform.pubadx.one/pubadx-ad.js` — 229 (1.41%)
- `https://static.foxnews.com/static/isa/core-app.js` — 216 (1.33%)
- `https://consent.cookiebot.com/uc.js?cbid=413c9b8b-659f-48a0-b94c-ac47178d423e&implementation=gtm&consentmode-dataredaction=dynamic` — 196 (1.21%)
- `https://c.amazon-adsystem.com/aax2/apstag.js` — 182 (1.12%)
- `https://cdn.pubfuture-ad.com/v2/unit/pt.js` — 177 (1.09%)

#### Top 10 first-party matched SRCs (found)
- `//dynamic.criteo.com/js/ld/ld.js?a=115335&a=115336&a=115723&a=115731&a=115730&a=115712&a=115729&a=115732&a=114332&a=115772&a=115769&a=115768&a=115763&a=115764&a=115765&a=115770&a=115762&a=115771&a=115766&a=115767&a=115733&a=116519&a=116517&a=116510&a=116513&a=116512&a=116508&a=116511&a=116516&a=116520&a=116509&a=116523&a=116518&a=116522&a=116515&a=119677&a=119732&a=122221` — 514 (7.04%)
- `/_next/static/chunks/9834-ef804c25a2536732.js` — 469 (6.43%)
- `usync.js` — 233 (3.19%)
- `//securepubads.g.doubleclick.net/tag/js/gpt.js` — 199 (2.73%)
- `//s10.histats.com/js15_as.js` — 171 (2.34%)
- `//palibzh.tech/libs/projectagora.min.js` — 161 (2.21%)
- `//cdn.orangeclickmedia.com/tech/enikos.gr/ocm.js` — 158 (2.16%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 147 (2.01%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 146 (2.00%)
- `//static.adman.gr/adman.js` — 138 (1.89%)

---
## ALGERIA → INDIA
### Comparable denominators
- Compared sites: **4426**
- Compared URLs: **6865**
### Differences (from summary)
- Sites with tracking in src only: **1402** (31.68% of compared sites)
- URLs with tracking in src only: **1961** (28.57% of compared URLs)
- Total tracking requests in src only: **31366**
- Requests with chain: **31041** (98.96% of total-diff)
- Requests without chain: **325** (1.04% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **18140** (58.44% of with-chain)
- dst_chain_match_inline: **4455** (14.35% of with-chain)
- dst_chain_match_found: **8446** (27.21% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **339** (1.08%)
- `same-site`: **425** (1.35%)
- `cross-site`: **30602** (97.56%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **764** (2.44%)
- Third-party (cross-site): **30602** (97.56%)

### Top 10 third-party request domains (eTLD+1)
- `rubiconproject.com` — 1775 (5.80%)
- `googlesyndication.com` — 1202 (3.93%)
- `pubmatic.com` — 1181 (3.86%)
- `doubleclick.net` — 1170 (3.82%)
- `google.dz` — 842 (2.75%)
- `adnxs.com` — 786 (2.57%)
- `google.com` — 740 (2.42%)
- `googletagmanager.com` — 731 (2.39%)
- `smartadserver.com` — 685 (2.24%)
- `amazon-adsystem.com` — 616 (2.01%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 170 (22.25%)
- `/log?format=json&hasfast=true&authuser=0` — 29 (3.80%)
- `/?log=stats-beta` — 20 (2.62%)
- `/event/home-globo` — 20 (2.62%)
- `/v1/devices/events/web` — 16 (2.09%)
- `/pmm/api/pmm/defined` — 16 (2.09%)
- `/dot/pop4.php` — 14 (1.83%)
- `/?log=preroll` — 12 (1.57%)
- `/event/globoplay` — 11 (1.44%)
- `/id` — 11 (1.44%)

### `frame_main` distribution (details)
- main (1): **16828** (53.65%)
- non-main (0): **14538** (46.35%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 1440 (9.91%)
- `https://visitor.omnitagjs.com` — 886 (6.09%)
- `https://ssum-sec.casalemedia.com` — 748 (5.15%)
- `https://sync.inmobi.com` — 545 (3.75%)
- `https://ads.pubmatic.com` — 517 (3.56%)
- `https://www.etihad.com` — 514 (3.54%)
- `https://ms-cookie-sync.presage.io` — 459 (3.16%)
- `https://ssbsync.smartadserver.com` — 341 (2.35%)
- `https://ce.lijit.com` — 329 (2.26%)
- `https://csync.smartadserver.com` — 276 (1.90%)

### Tail of src chains (only among chains built)
- Chains built: **31041**
- Tail classified first-party: **4048** (13.04%)
- Tail classified third-party: **24969** (80.44%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 547 (2.19%)
- `https://cdn.adsninja.ca/biddertypelibrary/live/XDA/Prebid_Default.js?v=3156` — 375 (1.50%)
- `https://js.onclckmn.com/static/onclicka.js` — 205 (0.82%)
- `https://a.magsrv.com/ad-provider.js` — 168 (0.67%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MWI5ZTBkMTQ4MQ.js` — 161 (0.64%)
- `https://btloader.com/tag?aax_id=AAXA1OS6M&upapi=true` — 142 (0.57%)
- `https://www.google-analytics.com/analytics.js` — 141 (0.56%)
- `https://cdn.jsdelivr.net/npm/prebid.js@10.12.0/dist/not-for-prod/prebid.js?v=AD%2F1.0_2025101601` — 137 (0.55%)
- `https://static.adman.gr/vendors.js` — 135 (0.54%)
- `https://mc.yandex.ru/metrika/tag.js` — 134 (0.54%)

#### Top 10 first-party tail SRCs
- `usync.js` — 633 (15.64%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 256 (6.32%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 130 (3.21%)
- `//micro.rubiconproject.com/prebid/dynamic/16836.js` — 119 (2.94%)
- `/static/a221b964/s/widgets/ThumbSpot/main.b5e999e5acffb659e49a.js` — 95 (2.35%)
- `//cdn.tsyndicate.com/sdk/v1/master.spot.js` — 71 (1.75%)
- `//flux-cdn.com/client/1000025/nikkei225jp_1148.min.js` — 68 (1.68%)
- `/_next/static/chunks/6167-614a10ea0271c4e5.js` — 49 (1.21%)
- `//cdn.tsyndicate.com/sdk/v1/n.js` — 48 (1.19%)
- `//secure.cdn.fastclick.net/js/pubcid/latest/pubcid.min.js` — 47 (1.16%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **8446**
- Matched SRC classified first-party: **2337** (27.67%)
- Matched SRC classified third-party: **6109** (72.33%)

#### Top 10 third-party matched SRCs (found)
- `https://www.googletagmanager.com/gtm.js?id=GTM-WQMQH4C6` — 536 (8.77%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 487 (7.97%)
- `https://player.hbmp.ops.co/prebidlink/31ee76261d87fed8cb9d4c465c48158c/hbp_master_775112_22697.js` — 122 (2.00%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202510060101/pubads_impl.js` — 119 (1.95%)
- `https://www.googletagmanager.com/gtag/js?id=DC-5731039` — 115 (1.88%)
- `https://scripts.finanzen.net/Content/Scripts/dist/layout-render-blocking.js` — 94 (1.54%)
- `https://monetiseup.tech/tags/mu.js` — 87 (1.42%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-T6LZTG2&gtm_auth=UV2Rh9pHhutsLk-s7J2KJQ&gtm_preview=env-46&gtm_cookies_win=x` — 76 (1.24%)
- `https://www.rawstory.com/static/dist/social-ux/main.defdfeb3de149b091756.bundle.mjs` — 66 (1.08%)
- `https://ru.viadata.store/v2/comm_min.js?sid=108095` — 62 (1.01%)

#### Top 10 first-party matched SRCs (found)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 164 (7.02%)
- `//static.adman.gr/adman.js` — 125 (5.35%)
- `//static.criteo.net/js/ld/ld.js` — 112 (4.79%)
- `usync.js` — 91 (3.89%)
- `//www.googletagmanager.com/gtm.js?id=GTM-KDDQ7L` — 86 (3.68%)
- `//securepubads.g.doubleclick.net/tag/js/gpt.js` — 77 (3.29%)
- `/_next/static/chunks/6167-614a10ea0271c4e5.js` — 75 (3.21%)
- `//www.googletagmanager.com/gtm.js?id=GTM-PZ83PG` — 52 (2.23%)
- `//cdn.taboola.com/libtrc/nationgroupthailand-bangkokbiznewscom/loader.js` — 51 (2.18%)
- `//dynamic.criteo.com/js/ld/ld.js?a=87843` — 50 (2.14%)

---
## ALGERIA → USA
### Comparable denominators
- Compared sites: **3790**
- Compared URLs: **6418**
### Differences (from summary)
- Sites with tracking in src only: **1122** (29.60% of compared sites)
- URLs with tracking in src only: **1540** (24.00% of compared URLs)
- Total tracking requests in src only: **13670**
- Requests with chain: **13432** (98.26% of total-diff)
- Requests without chain: **238** (1.74% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **6948** (51.73% of with-chain)
- dst_chain_match_inline: **1025** (7.63% of with-chain)
- dst_chain_match_found: **5459** (40.64% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **77** (0.56%)
- `same-site`: **66** (0.48%)
- `cross-site`: **13527** (98.95%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **143** (1.05%)
- Third-party (cross-site): **13527** (98.95%)

### Top 10 third-party request domains (eTLD+1)
- `google.dz` — 715 (5.29%)
- `doubleclick.net` — 505 (3.73%)
- `rubiconproject.com` — 395 (2.92%)
- `google.com` — 327 (2.42%)
- `googlesyndication.com` — 319 (2.36%)
- `pubmatic.com` — 292 (2.16%)
- `blcdog.com` — 240 (1.77%)
- `tsyndicate.com` — 237 (1.75%)
- `googletagmanager.com` — 235 (1.74%)
- `adnxs.com` — 226 (1.67%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 33 (23.08%)
- `/track` — 18 (12.59%)
- `/js/` — 4 (2.80%)
- `/?log=stats-beta` — 4 (2.80%)
- `/id/popup/adblock/promo/banner/ad-scripts--/discourse-adplugin-/exonob/ad/neverblock/ad/1761433209/ad.js` — 4 (2.80%)
- `/assets/default/js/excluded/300x600_disclaimer.js?v=1` — 4 (2.80%)
- `/tags.js` — 3 (2.10%)
- `/next-integrations/integrations/twitter-ads/2.5.4/twitter-ads.dynamic.js.gz` — 2 (1.40%)
- `/akam/13/40a543ae` — 2 (1.40%)
- `/akam/13/pixel_40a543ae` — 2 (1.40%)

### `frame_main` distribution (details)
- main (1): **7112** (52.03%)
- non-main (0): **6558** (47.97%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://www.etihad.com` — 514 (7.84%)
- `https://ssum-sec.casalemedia.com` — 405 (6.18%)
- `https://eus.rubiconproject.com` — 387 (5.90%)
- `https://visitor.omnitagjs.com` — 331 (5.05%)
- `https://creative.blcdog.com` — 226 (3.45%)
- `https://bcp.crwdcntrl.net` — 199 (3.03%)
- `https://bn.adbestnet.com` — 168 (2.56%)
- `https://ms-cookie-sync.presage.io` — 155 (2.36%)
- `https://pagead2.googlesyndication.com` — 149 (2.27%)
- `https://ssbsync.smartadserver.com` — 139 (2.12%)

### Tail of src chains (only among chains built)
- Chains built: **13432**
- Tail classified first-party: **1719** (12.80%)
- Tail classified third-party: **10754** (80.06%)

#### Top 10 third-party tail SRCs
- `https://js.onclckmn.com/static/onclicka.js` — 200 (1.86%)
- `https://hbagency.it/cdn/prebid_9_34_hb.js` — 174 (1.62%)
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 115 (1.07%)
- `https://js.wpadmngr.com/static/adManager.js` — 98 (0.91%)
- `https://a.magsrv.com/ad-provider.js` — 77 (0.72%)
- `https://js.onclckbnr.com/banner-admanager/build.m.js` — 71 (0.66%)
- `https://s.adplay.it/meteolive/prebid.js` — 63 (0.59%)
- `https://btloader.com/tag?aax_id=AAXA1OS6M&upapi=true` — 59 (0.55%)
- `https://mc.yandex.ru/metrika/tag.js` — 57 (0.53%)
- `https://lcdn.tsyndicate.com/sdk/v1/master.spot.js` — 57 (0.53%)

#### Top 10 first-party tail SRCs
- `usync.js` — 145 (8.44%)
- `/static/a7bbed3a/s/widgets/v4/Universal/main.efff7dd06e83080d1a67.js` — 80 (4.65%)
- `/static/a221b964/s/widgets/ThumbSpot/main.b5e999e5acffb659e49a.js` — 70 (4.07%)
- `//cdn.tsyndicate.com/sdk/v1/master.spot.js` — 66 (3.84%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 33 (1.92%)
- `//afrdtech.com/v1/script.js?kmnrKey=239040355` — 31 (1.80%)
- `//cdn.tsyndicate.com/sdk/v1/n.js` — 28 (1.63%)
- `/static/a221b964/s/widgets/v4/Universal/main.4027212a82d56bd696d1.js` — 26 (1.51%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 20 (1.16%)
- `//ads.pubmatic.com/AdServer/js/pwt/163386/10601/pwt.js` — 19 (1.11%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **5459**
- Matched SRC classified first-party: **1556** (28.50%)
- Matched SRC classified third-party: **3903** (71.50%)

#### Top 10 third-party matched SRCs (found)
- `https://www.googletagmanager.com/gtm.js?id=GTM-WQMQH4C6` — 527 (13.50%)
- `https://tags.tiqcdn.com/utag/uber/eatsv2/prod/utag.js` — 255 (6.53%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 244 (6.25%)
- `https://js.wpadmngr.com/static/adManager.js` — 173 (4.43%)
- `https://platform.pubadx.one/pubadx-ad.js` — 99 (2.54%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-NQ3XB9&l=dataLayerAt1333` — 70 (1.79%)
- `https://mc.webvisor.org/metrika/tag_ww.js` — 57 (1.46%)
- `https://micro.rubiconproject.com/prebid/dynamic/16836.js` — 51 (1.31%)
- `https://ubistatic-a.ubisoft.com/0106/prod-cmp/global/tracking/ubiAutoBlock.js` — 47 (1.20%)
- `https://cdn.wolf-327b.com/rdr/renderer.js` — 41 (1.05%)

#### Top 10 first-party matched SRCs (found)
- `//adv.rtbuzz.net/w4192.js` — 140 (9.00%)
- `//appointeeivyspongy.com/bn.js` — 64 (4.11%)
- `usync.js` — 59 (3.79%)
- `//www.googletagmanager.com/gtm.js?id=GTM-KDDQ7L` — 56 (3.60%)
- `//cdnjs.cloudflare.com/ajax/libs/postscribe/2.0.8/postscribe.min.js` — 56 (3.60%)
- `//www.ezojs.com/ezoic/sa.min.js` — 51 (3.28%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 44 (2.83%)
- `//securepubads.g.doubleclick.net/tag/js/gpt.js?network-code=22152718` — 35 (2.25%)
- `/pf/dist/components/combinations/default.js?d=755&mxId=00000000` — 34 (2.19%)
- `/a1.js` — 32 (2.06%)

---
## GERMANY → ALGERIA
### Comparable denominators
- Compared sites: **5267**
- Compared URLs: **13769**
### Differences (from summary)
- Sites with tracking in src only: **3284** (62.35% of compared sites)
- URLs with tracking in src only: **7803** (56.67% of compared URLs)
- Total tracking requests in src only: **190448**
- Requests with chain: **186548** (97.95% of total-diff)
- Requests without chain: **3900** (2.05% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **125045** (67.03% of with-chain)
- dst_chain_match_inline: **29708** (15.93% of with-chain)
- dst_chain_match_found: **31795** (17.04% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **1569** (0.82%)
- `same-site`: **2027** (1.06%)
- `cross-site`: **186852** (98.11%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **3596** (1.89%)
- Third-party (cross-site): **186852** (98.11%)

### Top 10 third-party request domains (eTLD+1)
- `googlesyndication.com` — 19951 (10.68%)
- `doubleclick.net` — 11207 (6.00%)
- `rubiconproject.com` — 7374 (3.95%)
- `googletagmanager.com` — 7166 (3.84%)
- `google.com` — 5613 (3.00%)
- `tiktok.com` — 4573 (2.45%)
- `amazon-adsystem.com` — 4393 (2.35%)
- `yandex.com` — 4344 (2.32%)
- `criteo.net` — 4273 (2.29%)
- `adnxs.com` — 4087 (2.19%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 498 (13.85%)
- `/log?format=json&hasfast=true&authuser=0` — 103 (2.86%)
- `/` — 49 (1.36%)
- `/1/events/com.amazon.csm.csa.prod` — 39 (1.08%)
- `/bdtrck/updDcEv` — 35 (0.97%)
- `/v2/log/web?content_type=pbrequest&logid=021434&disable_compression=true` — 29 (0.81%)
- `/web/statistics` — 28 (0.78%)
- `/events` — 28 (0.78%)
- `/gol/postweb?000016,000016,000016` — 23 (0.64%)
- `/p2TBVNJZ/xhr/api/v2/collector` — 22 (0.61%)

### `frame_main` distribution (details)
- main (1): **102580** (53.86%)
- non-main (0): **87868** (46.14%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 6908 (7.86%)
- `https://googleads.g.doubleclick.net` — 5530 (6.29%)
- `https://pagead2.googlesyndication.com` — 5173 (5.89%)
- `https://ads.eu.criteo.com` — 3695 (4.21%)
- `https://ssum-sec.casalemedia.com` — 3420 (3.89%)
- `https://s0.2mdn.net` — 2377 (2.71%)
- `https://onetag-sys.com` — 2087 (2.38%)
- `https://csync.smartadserver.com` — 1970 (2.24%)
- `https://visitor.omnitagjs.com` — 1284 (1.46%)
- `https://sync.inmobi.com` — 1252 (1.42%)

### Tail of src chains (only among chains built)
- Chains built: **186548**
- Tail classified first-party: **24826** (13.31%)
- Tail classified third-party: **144737** (77.59%)

#### Top 10 third-party tail SRCs
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 3462 (2.39%)
- `https://mc.yandex.ru/metrika/tag.js` — 2575 (1.78%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202509110101/pubads_impl.js` — 1386 (0.96%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MTE5NjQzNGRmMQ.js` — 1324 (0.91%)
- `https://a.magsrv.com/ad-provider.js` — 1200 (0.83%)
- `https://www.google-analytics.com/analytics.js` — 1131 (0.78%)
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 1126 (0.78%)
- `https://connect.facebook.net/en_US/fbevents.js` — 828 (0.57%)
- `https://mc.yandex.ru/metrika/watch.js` — 795 (0.55%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 763 (0.53%)

#### Top 10 first-party tail SRCs
- `usync.js` — 1794 (7.23%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 1442 (5.81%)
- `//cdn.tsyndicate.com/sdk/v1/hls.light.min.js` — 857 (3.45%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 559 (2.25%)
- `//imasdk.googleapis.com/formats/outstream/versioned/prod2/outstream_web_client_20250428_RC00/outstream.min.js` — 429 (1.73%)
- `//bat.bing.com/bat.js` — 422 (1.70%)
- `//secure.cdn.fastclick.net/js/pubcid/latest/pubcid.min.js` — 232 (0.93%)
- `//s.lngtdv.com/prebid/playfootballgames/prebid9.53.2.1756970144.min.js` — 229 (0.92%)
- `//www.google-analytics.com/analytics.js` — 215 (0.87%)
- `//tpc.googlesyndication.com/sodar/Q12zgMmT.js` — 210 (0.85%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **31795**
- Matched SRC classified first-party: **7777** (24.46%)
- Matched SRC classified third-party: **24018** (75.54%)

#### Top 10 third-party matched SRCs (found)
- `https://mc.yandex.ru/metrika/tag.js` — 2164 (9.01%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 1926 (8.02%)
- `https://connect.facebook.net/en_US/fbevents.js` — 594 (2.47%)
- `https://assets.evolutionadv.it/optiload/4.x.x/optiload.min.js` — 536 (2.23%)
- `https://boot.pbstck.com/v1/adm/b17997cb-d242-457a-b955-0ac08c8cfc10` — 453 (1.89%)
- `https://bat.bing.com/bat.js` — 342 (1.42%)
- `https://mc.yandex.ru/metrika/watch.js` — 341 (1.42%)
- `https://adsystem.pages.dev/ad-system/loader.js` — 279 (1.16%)
- `https://boot.pbstck.com/v1/adm/f97deb8f-e326-473e-8369-b75346a0b772` — 260 (1.08%)
- `https://www.googletagservices.com/tag/js/gpt.js` — 220 (0.92%)

#### Top 10 first-party matched SRCs (found)
- `usync.js` — 592 (7.61%)
- `//dynamic.criteo.com/js/ld/ld.js?a=115335&a=115336&a=115723&a=115731&a=115730&a=115712&a=115729&a=115732&a=114332&a=115772&a=115769&a=115768&a=115763&a=115764&a=115765&a=115770&a=115762&a=115771&a=115766&a=115767&a=115733&a=116519&a=116517&a=116510&a=116513&a=116512&a=116508&a=116511&a=116516&a=116520&a=116509&a=116523&a=116518&a=116522&a=116515&a=119677&a=119732&a=122221` — 390 (5.01%)
- `//bat.bing.com/bat.js` — 298 (3.83%)
- `//assets.adobedtm.com/launch-ENfc31ab1bac944ca8866743454782e0b0.min.js` — 266 (3.42%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 209 (2.69%)
- `//www.googletagmanager.com/gtm.js?id=GTM-5RZ7W8C` — 192 (2.47%)
- `/sum.js?i=homep-desk&v=25320.020527&referrer_url=https%3A%2F%2Fwww.milffox.com%2Fmilf-pornstars%2FEmma-Butt%2F&referrer_site=&kw=%keywords%` — 176 (2.26%)
- `//securepubads.g.doubleclick.net/tag/js/gpt.js` — 149 (1.92%)
- `/sum.js?i=homep-desk&v=25320.020527&referrer_url=https%3A%2F%2Fwww.milffox.com%2Fmilf-pornstars%2FAlanah-Rae%2F&referrer_site=&kw=%keywords%` — 135 (1.74%)
- `//anymind360.com/js/5043/ats.js` — 129 (1.66%)

---
## GERMANY → INDIA
### Comparable denominators
- Compared sites: **6406**
- Compared URLs: **10192**
### Differences (from summary)
- Sites with tracking in src only: **3072** (47.96% of compared sites)
- URLs with tracking in src only: **4517** (44.32% of compared URLs)
- Total tracking requests in src only: **92194**
- Requests with chain: **90431** (98.09% of total-diff)
- Requests without chain: **1763** (1.91% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **54655** (60.44% of with-chain)
- dst_chain_match_inline: **9981** (11.04% of with-chain)
- dst_chain_match_found: **25795** (28.52% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **677** (0.73%)
- `same-site`: **1548** (1.68%)
- `cross-site`: **89969** (97.59%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **2225** (2.41%)
- Third-party (cross-site): **89969** (97.59%)

### Top 10 third-party request domains (eTLD+1)
- `googlesyndication.com` — 5790 (6.44%)
- `rubiconproject.com` — 4321 (4.80%)
- `doubleclick.net` — 4127 (4.59%)
- `yandex.com` — 2891 (3.21%)
- `2mdn.net` — 2656 (2.95%)
- `google.com` — 2463 (2.74%)
- `smartadserver.com` — 2238 (2.49%)
- `adnxs.com` — 2227 (2.48%)
- `googletagmanager.com` — 2123 (2.36%)
- `tiktok.com` — 2110 (2.35%)

### Top 10 first-party request paths (path only)
- `/events/single` — 502 (22.56%)
- `/cdn-cgi/rum` — 108 (4.85%)
- `/configs?tenant=gshow&platform=js` — 72 (3.24%)
- `/?log=stats-beta` — 66 (2.97%)
- `/?log=united-impression` — 42 (1.89%)
- `/?log=xh-widgets-events-v2` — 36 (1.62%)
- `/api/v2/collect` — 33 (1.48%)
- `/api/uisprime/track` — 31 (1.39%)
- `/log?format=json&hasfast=true&authuser=0` — 29 (1.30%)
- `/api/v1/activities` — 19 (0.85%)

### `frame_main` distribution (details)
- main (1): **47293** (51.30%)
- non-main (0): **44901** (48.70%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 3933 (8.76%)
- `https://pagead2.googlesyndication.com` — 2806 (6.25%)
- `https://s0.2mdn.net` — 2245 (5.00%)
- `https://ssum-sec.casalemedia.com` — 1820 (4.05%)
- `https://ads.eu.criteo.com` — 1641 (3.65%)
- `https://googleads.g.doubleclick.net` — 1486 (3.31%)
- `https://onetag-sys.com` — 1187 (2.64%)
- `https://csync.smartadserver.com` — 980 (2.18%)
- `https://visitor.omnitagjs.com` — 790 (1.76%)
- `https://apps.smartadserver.com` — 553 (1.23%)

### Tail of src chains (only among chains built)
- Chains built: **90431**
- Tail classified first-party: **12654** (13.99%)
- Tail classified third-party: **71100** (78.62%)

#### Top 10 third-party tail SRCs
- `https://mc.yandex.ru/metrika/tag.js` — 1680 (2.36%)
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 1078 (1.52%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202509110101/pubads_impl.js` — 522 (0.73%)
- `https://assets.wfcdn.com/webpack/sf-ui-core-funnel/_next/static/chunks/app/layout-8248f6e887ed1633.js` — 506 (0.71%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MTE5NjQzNGRmMQ.js` — 455 (0.64%)
- `https://mc.yandex.ru/metrika/watch.js` — 397 (0.56%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MTE5NjQzNGRmMA.js` — 378 (0.53%)
- `https://connect.facebook.net/en_US/fbevents.js` — 358 (0.50%)
- `https://bat.bing.com/bat.js` — 349 (0.49%)
- `https://a.magsrv.com/ad-provider.js` — 348 (0.49%)

#### Top 10 first-party tail SRCs
- `usync.js` — 1056 (8.35%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 609 (4.81%)
- `//cdn.tsyndicate.com/sdk/v1/hls.light.min.js` — 475 (3.75%)
- `//bat.bing.com/bat.js` — 309 (2.44%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 305 (2.41%)
- `//imasdk.googleapis.com/formats/outstream/versioned/prod2/outstream_web_client_20250428_RC00/outstream.min.js` — 222 (1.75%)
- `//micro.rubiconproject.com/prebid/dynamic/16836.js` — 165 (1.30%)
- `code.min.js` — 108 (0.85%)
- `//delivery.r2b2.io/hb/kompasGramedia/tribunnews.com_desktop` — 108 (0.85%)
- `//secure.cdn.fastclick.net/js/pubcid/latest/pubcid.min.js` — 99 (0.78%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **25795**
- Matched SRC classified first-party: **5955** (23.09%)
- Matched SRC classified third-party: **19840** (76.91%)

#### Top 10 third-party matched SRCs (found)
- `https://mc.yandex.ru/metrika/tag.js` — 1915 (9.65%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 1316 (6.63%)
- `https://assets.evolutionadv.it/optiload/4.x.x/optiload.min.js` — 527 (2.66%)
- `https://bat.bing.com/bat.js` — 309 (1.56%)
- `https://a.thecoreadv.com/s/viagginews/ads.js` — 299 (1.51%)
- `https://mc.yandex.ru/metrika/watch.js` — 271 (1.37%)
- `https://connect.facebook.net/en_US/fbevents.js` — 270 (1.36%)
- `https://www.googletagservices.com/tag/js/gpt.js` — 247 (1.24%)
- `https://boot.pbstck.com/v1/adm/f97deb8f-e326-473e-8369-b75346a0b772` — 246 (1.24%)
- `https://cdn.qwtag.com/b9039d0e-a9af-4f8e-94eb-99107c4245e1/qw.js` — 187 (0.94%)

#### Top 10 first-party matched SRCs (found)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 417 (7.00%)
- `//www.googletagmanager.com/gtm.js?id=GTM-5RZ7W8C` — 317 (5.32%)
- `//bat.bing.com/bat.js` — 253 (4.25%)
- `usync.js` — 248 (4.16%)
- `/sum.js?i=homep-desk&v=25320.020527&referrer_url=https%3A%2F%2Fwww.milffox.com%2Fmilf-pornstars%2FEmma-Butt%2F&referrer_site=&kw=%keywords%` — 177 (2.97%)
- `//static.criteo.net/js/ld/ld.js` — 143 (2.40%)
- `//cdn.tsyndicate.com/sdk/v1/master.spot.js` — 122 (2.05%)
- `//static.vocstatic.com/voonto2/latest/voonto.js` — 120 (2.02%)
- `//d.otaserve.net/r/www/delivery/asyncjs.php` — 102 (1.71%)
- `/_adv/lib/v9/prebid9.50.0.js` — 93 (1.56%)

---
## GERMANY → USA
### Comparable denominators
- Compared sites: **4353**
- Compared URLs: **7395**
### Differences (from summary)
- Sites with tracking in src only: **1924** (44.20% of compared sites)
- URLs with tracking in src only: **2881** (38.96% of compared URLs)
- Total tracking requests in src only: **40033**
- Requests with chain: **39140** (97.77% of total-diff)
- Requests without chain: **893** (2.23% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **23152** (59.15% of with-chain)
- dst_chain_match_inline: **3474** (8.88% of with-chain)
- dst_chain_match_found: **12514** (31.97% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **158** (0.39%)
- `same-site`: **124** (0.31%)
- `cross-site`: **39751** (99.30%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **282** (0.70%)
- Third-party (cross-site): **39751** (99.30%)

### Top 10 third-party request domains (eTLD+1)
- `googlesyndication.com` — 1816 (4.57%)
- `rubiconproject.com` — 1799 (4.53%)
- `doubleclick.net` — 1339 (3.37%)
- `google.de` — 1184 (2.98%)
- `adnxs.com` — 1043 (2.62%)
- `smartadserver.com` — 996 (2.51%)
- `criteo.net` — 992 (2.50%)
- `2mdn.net` — 916 (2.30%)
- `tiktok.com` — 898 (2.26%)
- `google.com` — 867 (2.18%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 75 (26.60%)
- `/1/events/com.amazon.csm.csa.prod` — 8 (2.84%)
- `/v3/frontlogsrv/log/web?platform=desktop` — 6 (2.13%)
- `/?log=stats-beta` — 5 (1.77%)
- `/Adv/Masthead/LifeOfChuck_15s.mp4` — 4 (1.42%)
- `/p2TBVNJZ/xhr/api/v2/collector` — 4 (1.42%)
- `/?local_ga_js=cc7b31391f16baaa48bd9833427e21c6` — 4 (1.42%)
- `/v3/frontlogsrv/log/web` — 4 (1.42%)
- `/assets/default/js/excluded/300x600_disclaimer.js?v=1` — 4 (1.42%)
- `/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.min.js?ver=9.8.0` — 4 (1.42%)

### `frame_main` distribution (details)
- main (1): **18638** (46.56%)
- non-main (0): **21395** (53.44%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 1784 (8.34%)
- `https://pagead2.googlesyndication.com` — 1321 (6.17%)
- `https://ssum-sec.casalemedia.com` — 1053 (4.92%)
- `https://ads.eu.criteo.com` — 871 (4.07%)
- `https://googleads.g.doubleclick.net` — 819 (3.83%)
- `https://s0.2mdn.net` — 726 (3.39%)
- `https://csync.smartadserver.com` — 635 (2.97%)
- `https://onetag-sys.com` — 503 (2.35%)
- `https://cdn.amon1.net` — 354 (1.65%)
- `https://toonstream.love` — 333 (1.56%)

### Tail of src chains (only among chains built)
- Chains built: **39140**
- Tail classified first-party: **6176** (15.78%)
- Tail classified third-party: **29762** (76.04%)

#### Top 10 third-party tail SRCs
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 299 (1.00%)
- `https://js.wpadmngr.com/static/adManager.js` — 298 (1.00%)
- `https://bat.bing.com/bat.js` — 201 (0.68%)
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 192 (0.65%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MTE5NjQzNGRmMQ.js` — 189 (0.64%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MTE5NjQzNGRmMA.js` — 171 (0.57%)
- `https://a.magsrv.com/ad-provider.js` — 167 (0.56%)
- `https://hb.adpone.com/prebid9.30.0.js` — 164 (0.55%)
- `https://static.21wiz.com/mp_dist/mstream2.js?ver=11320164079` — 161 (0.54%)
- `https://www.google-analytics.com/analytics.js` — 134 (0.45%)

#### Top 10 first-party tail SRCs
- `//cdn.tsyndicate.com/sdk/v1/hls.light.min.js` — 599 (9.70%)
- `usync.js` — 470 (7.61%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 216 (3.50%)
- `//bat.bing.com/bat.js` — 158 (2.56%)
- `//micro.rubiconproject.com/prebid/dynamic/16836.js` — 114 (1.85%)
- `code.min.js` — 108 (1.75%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 94 (1.52%)
- `/static/themes/actu_v2/dist/bundles/scripts.ae9a80fc1a1f183cefb1.min.js` — 68 (1.10%)
- `/static/4c0fab5f/s/widgets/ThumbSpot/main.897064467ef3861d612f.js` — 64 (1.04%)
- `/static/4c0fab5f/s/widgets/v4/Universal/main.ec7828d565026f6c293c.js` — 61 (0.99%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **12514**
- Matched SRC classified first-party: **3542** (28.30%)
- Matched SRC classified third-party: **8972** (71.70%)

#### Top 10 third-party matched SRCs (found)
- `https://boot.pbstck.com/v1/adm/b17997cb-d242-457a-b955-0ac08c8cfc10` — 601 (6.70%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 546 (6.09%)
- `https://js.wpadmngr.com/static/adManager.js` — 432 (4.81%)
- `https://www.googletagservices.com/tag/js/gpt.js` — 290 (3.23%)
- `https://bat.bing.com/bat.js` — 233 (2.60%)
- `https://a.thecoreadv.com/s/viagginews/ads.js` — 219 (2.44%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-NMHSPC8` — 183 (2.04%)
- `https://connect.facebook.net/en_US/fbevents.js` — 157 (1.75%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-P78V88W4` — 111 (1.24%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-TT2KL3D&gtm_auth=tsgUTfJXVlV5LrQHghe4Mw&gtm_preview=env-2&gtm_cookies_win=x` — 109 (1.21%)

#### Top 10 first-party matched SRCs (found)
- `usync.js` — 234 (6.61%)
- `//www.googletagmanager.com/gtm.js?id=GTM-5RZ7W8C` — 212 (5.99%)
- `//bat.bing.com/bat.js` — 198 (5.59%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 188 (5.31%)
- `//cdn.tsyndicate.com/sdk/v1/master.spot.js` — 186 (5.25%)
- `/sum.js?i=homep-desk&v=25320.020527&referrer_url=https%3A%2F%2Fwww.milffox.com%2Fmilf-pornstars%2FEmma-Butt%2F&referrer_site=&kw=%keywords%` — 179 (5.05%)
- `/sum.js?i=homep-desk&v=25320.020527&referrer_url=https%3A%2F%2Fwww.milffox.com%2Fmilf-pornstars%2FAlanah-Rae%2F&referrer_site=&kw=%keywords%` — 136 (3.84%)
- `//d.otaserve.net/r/www/delivery/asyncjs.php` — 102 (2.88%)
- `//rumcdn.geoedge.be/e8906ba2-e437-4b70-a933-2c1ab9468453/grumi-ip.js` — 70 (1.98%)
- `/_adv/lib/v9/prebid9.50.0.js` — 65 (1.84%)

---
## INDIA → ALGERIA
### Comparable denominators
- Compared sites: **4426**
- Compared URLs: **6865**
### Differences (from summary)
- Sites with tracking in src only: **2005** (45.30% of compared sites)
- URLs with tracking in src only: **2878** (41.92% of compared URLs)
- Total tracking requests in src only: **35547**
- Requests with chain: **34756** (97.77% of total-diff)
- Requests without chain: **791** (2.23% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **21230** (61.08% of with-chain)
- dst_chain_match_inline: **8320** (23.94% of with-chain)
- dst_chain_match_found: **5206** (14.98% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **513** (1.44%)
- `same-site`: **742** (2.09%)
- `cross-site`: **34292** (96.47%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **1255** (3.53%)
- Third-party (cross-site): **34292** (96.47%)

### Top 10 third-party request domains (eTLD+1)
- `doubleclick.net` — 2565 (7.48%)
- `googlesyndication.com` — 2537 (7.40%)
- `googletagmanager.com` — 2444 (7.13%)
- `google.com` — 1687 (4.92%)
- `google-analytics.com` — 1332 (3.88%)
- `google.co.in` — 1296 (3.78%)
- `rubiconproject.com` — 748 (2.18%)
- `pubmatic.com` — 558 (1.63%)
- `yandex.ru` — 514 (1.50%)
- `amazon-adsystem.com` — 497 (1.45%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 233 (18.57%)
- `/log?format=json&hasfast=true&authuser=0` — 34 (2.71%)
- `/bdtrck/updDcEv` — 29 (2.31%)
- `/hit` — 18 (1.43%)
- `/1/events/com.amazon.csm.csa.prod` — 16 (1.27%)
- `/` — 15 (1.20%)
- `/events` — 15 (1.20%)
- `/wp-content/plugins/wp-rocket/assets/js/wpr-beacon.min.js` — 13 (1.04%)
- `/ping` — 10 (0.80%)
- `/v2/log/web?content_type=pbrequest&logid=021436&disable_compression=true` — 7 (0.56%)

### `frame_main` distribution (details)
- main (1): **25505** (71.75%)
- non-main (0): **10042** (28.25%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 568 (5.66%)
- `https://googleads.g.doubleclick.net` — 432 (4.30%)
- `https://onetag-sys.com` — 370 (3.68%)
- `https://ssum-sec.casalemedia.com` — 330 (3.29%)
- `https://pagead2.googlesyndication.com` — 322 (3.21%)
- `https://bcp.crwdcntrl.net` — 295 (2.94%)
- `https://www.cadena3.com` — 245 (2.44%)
- `https://ads.pubmatic.com` — 195 (1.94%)
- `https://tuoitre.vn` — 181 (1.80%)
- `https://apps.smartadserver.com` — 152 (1.51%)

### Tail of src chains (only among chains built)
- Chains built: **34756**
- Tail classified first-party: **4891** (14.07%)
- Tail classified third-party: **26704** (76.83%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 509 (1.91%)
- `https://a.magsrv.com/ad-provider.js` — 463 (1.73%)
- `https://www.google-analytics.com/analytics.js` — 368 (1.38%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202511120101/pubads_impl.js` — 286 (1.07%)
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 252 (0.94%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202510090101/pubads_impl.js` — 225 (0.84%)
- `https://mc.yandex.ru/metrika/tag.js` — 223 (0.84%)
- `https://connect.facebook.net/en_US/fbevents.js` — 217 (0.81%)
- `https://js.wpadmngr.com/static/adManager.js` — 185 (0.69%)
- `https://c.adsco.re/` — 176 (0.66%)

#### Top 10 first-party tail SRCs
- `/_next/static/chunks/pages/_app-0720b24371e85d0b.js` — 262 (5.36%)
- `usync.js` — 198 (4.05%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 169 (3.46%)
- `https://qvc.jp/resources/8e7355fc827268ddaa1a05e53bc540d80faca36bcaa41` — 125 (2.56%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 88 (1.80%)
- `/static/a7bbed3a/s/widgets/v4/Universal/main.efff7dd06e83080d1a67.js` — 87 (1.78%)
- `//www.google-analytics.com/analytics.js` — 76 (1.55%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 62 (1.27%)
- `//cdn.valuad.cloud/hb/wallacoil-prod.js?timestamp=1760659200000` — 46 (0.94%)
- `//applets.ebxcdn.com/ebx.js` — 44 (0.90%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **5206**
- Matched SRC classified first-party: **1569** (30.14%)
- Matched SRC classified third-party: **3637** (69.86%)

#### Top 10 third-party matched SRCs (found)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 297 (8.17%)
- `https://boot.pbstck.com/v1/adm/b17997cb-d242-457a-b955-0ac08c8cfc10` — 103 (2.83%)
- `https://consent.cookiebot.com/uc.js?cbid=ff3b7dd5-a1df-479f-bfe4-79039109158c&data-framework=TCFv2.2&georegions={'region':'US-06','cbid':'02b636b3-a9e5-4a14-a24c-5f8b12801aa9'},{'region':'AT, BE, BG, CY, CZ, DE, DK, EE, ES, FI, FR, GB, GR, HR, HU, IE, IT, LT, LU, LV, MT, NL, PL, PT, RO, SE, SI, SK','cbid':'e65386e1-3560-413e-8fc0-f27adcd7f9ec'}` — 79 (2.17%)
- `https://connect.facebook.net/en_US/fbevents.js` — 77 (2.12%)
- `https://core.dimatter.ai/pubs/nra-lv.min.js` — 77 (2.12%)
- `https://secure.quantserve.com/quant.js` — 57 (1.57%)
- `https://hbagency.it/cdn/prebid_9_52_hb.js` — 48 (1.32%)
- `https://www.datadoghq-browser-agent.com/datadog-rum-v4.js` — 47 (1.29%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 46 (1.26%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-KX367LN` — 45 (1.24%)

#### Top 10 first-party matched SRCs (found)
- `//assets.adobedtm.com/launch-ENfc31ab1bac944ca8866743454782e0b0.min.js` — 221 (14.09%)
- `usync.js` — 81 (5.16%)
- `//www.googletagmanager.com/gtm.js?id=GTM-K86F9FM` — 74 (4.72%)
- `//static.criteo.net/js/ld/ld.js` — 45 (2.87%)
- `../../static/js/v0.js` — 38 (2.42%)
- `//assets.adobedtm.com/72afb75f5516/0da5fe63c80f/launch-a47c3b57c1fa.min.js` — 37 (2.36%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 33 (2.10%)
- `https://prop.faroutmagazine.co.uk/loader.js?v=3.14` — 29 (1.85%)
- `//tags.tiqcdn.com/utag/rakuten-travel/main/prod/utag.js` — 28 (1.78%)
- `//micro.rubiconproject.com/prebid/dynamic/7959.js?contentPass` — 28 (1.78%)

---
## INDIA → GERMANY
### Comparable denominators
- Compared sites: **6406**
- Compared URLs: **10192**
### Differences (from summary)
- Sites with tracking in src only: **2501** (39.04% of compared sites)
- URLs with tracking in src only: **3641** (35.72% of compared URLs)
- Total tracking requests in src only: **30932**
- Requests with chain: **30391** (98.25% of total-diff)
- Requests without chain: **541** (1.75% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **14354** (47.23% of with-chain)
- dst_chain_match_inline: **2236** (7.36% of with-chain)
- dst_chain_match_found: **13801** (45.41% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **245** (0.79%)
- `same-site`: **375** (1.21%)
- `cross-site`: **30312** (98.00%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **620** (2.00%)
- Third-party (cross-site): **30312** (98.00%)

### Top 10 third-party request domains (eTLD+1)
- `google.co.in` — 2038 (6.72%)
- `doubleclick.net` — 1690 (5.58%)
- `rubiconproject.com` — 1220 (4.02%)
- `pubmatic.com` — 943 (3.11%)
- `google.com` — 890 (2.94%)
- `adnxs.com` — 726 (2.40%)
- `googletagmanager.com` — 621 (2.05%)
- `smartadserver.com` — 597 (1.97%)
- `googlesyndication.com` — 587 (1.94%)
- `id5-sync.com` — 571 (1.88%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 105 (16.94%)
- `/pmm/api/pmm/defined` — 19 (3.06%)
- `/wp-content/plugins/wp-rocket/assets/js/wpr-beacon.min.js` — 8 (1.29%)
- `/splunkservices/v1/collectors/logs` — 7 (1.13%)
- `/tag/opus.js` — 6 (0.97%)
- `/pmm/api/pmm/api` — 6 (0.97%)
- `/ups/58784/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 4 (0.65%)
- `/ups/58824/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 4 (0.65%)
- `/ups/58831/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 4 (0.65%)
- `/ups/58834/sync?format=json&gdpr=false&gdpr_consent=&gpp=DBAA&gpp_sid=-1&us_privacy=1---` — 4 (0.65%)

### `frame_main` distribution (details)
- main (1): **18197** (58.83%)
- non-main (0): **12735** (41.17%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://eus.rubiconproject.com` — 957 (7.51%)
- `https://ssum-sec.casalemedia.com` — 709 (5.57%)
- `https://onetag-sys.com` — 581 (4.56%)
- `https://bcp.crwdcntrl.net` — 477 (3.75%)
- `https://ads.pubmatic.com` — 429 (3.37%)
- `https://pagead2.googlesyndication.com` — 390 (3.06%)
- `https://sync.inmobi.com` — 362 (2.84%)
- `https://apps.smartadserver.com` — 312 (2.45%)
- `https://ms-cookie-sync.presage.io` — 301 (2.36%)
- `https://creative.xlivrdr.com` — 293 (2.30%)

### Tail of src chains (only among chains built)
- Chains built: **30391**
- Tail classified first-party: **3927** (12.92%)
- Tail classified third-party: **23865** (78.53%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 372 (1.56%)
- `https://www.datadoghq-browser-agent.com/datadog-rum-v4.js` — 244 (1.02%)
- `https://tags.crwdcntrl.net/lt/c/16589/sync.min.js` — 169 (0.71%)
- `https://js.wpadmngr.com/static/adManager.js` — 160 (0.67%)
- `https://hbagency.it/cdn/prebid_9_34_hb.js` — 150 (0.63%)
- `https://cdn.id5-sync.com/api/1.0/id5PrebidModule.js` — 127 (0.53%)
- `https://static.criteo.net/js/ld/publishertag.ids.js` — 118 (0.49%)
- `https://cdn.id5-sync.com/api/1.0/esp.js` — 116 (0.49%)
- `https://www.google-analytics.com/analytics.js` — 115 (0.48%)
- `https://connect.facebook.net/en_US/fbevents.js` — 112 (0.47%)

#### Top 10 first-party tail SRCs
- `usync.js` — 371 (9.45%)
- `//cdn.hubvisor.io/wrapper/01BYK28ENND8X5G8K0AJ2DPK9E/hubvisor-ccm.js` — 274 (6.98%)
- `/_next/static/chunks/pages/_app-0720b24371e85d0b.js` — 266 (6.77%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 137 (3.49%)
- `/static/93555537/s/widgets/v4/MobileSliderSquareRowsXH/main.410a09baac3002340d9f.js` — 77 (1.96%)
- `/static/a7bbed3a/s/widgets/v4/Universal/main.efff7dd06e83080d1a67.js` — 73 (1.86%)
- `//ib.adnxs.com/async_usersync?cbfn=queuePixels` — 66 (1.68%)
- `//bat.bing.com/bat.js` — 45 (1.15%)
- `//tagmanager.smartadserver.com/1947/105101/smart.prebid.js` — 41 (1.04%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 40 (1.02%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **13801**
- Matched SRC classified first-party: **4030** (29.20%)
- Matched SRC classified third-party: **9771** (70.80%)

#### Top 10 third-party matched SRCs (found)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 787 (8.05%)
- `https://www.datadoghq-browser-agent.com/datadog-rum-v4.js` — 244 (2.50%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202511120101/pubads_impl.js` — 211 (2.16%)
- `https://static.foxnews.com/static/isa/core-app.js` — 169 (1.73%)
- `https://cdn.pubfuture-ad.com/v2/unit/pt.js` — 154 (1.58%)
- `https://platform.pubadx.one/pubadx-ad.js` — 150 (1.54%)
- `https://secure.quantserve.com/quant.js` — 135 (1.38%)
- `https://js.wpadmngr.com/static/adManager.js` — 106 (1.08%)
- `https://ads.blogherads.com/static/blogherads.js` — 102 (1.04%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 91 (0.93%)

#### Top 10 first-party matched SRCs (found)
- `//cdn.hubvisor.io/wrapper/01BYK28ENND8X5G8K0AJ2DPK9E/hubvisor-ccm.js` — 334 (8.29%)
- `//s10.histats.com/js15_as.js` — 283 (7.02%)
- `usync.js` — 117 (2.90%)
- `//palibzh.tech/libs/projectagora.min.js` — 85 (2.11%)
- `//www.googletagmanager.com/gtm.js?id=GTM-K86F9FM` — 74 (1.84%)
- `CookieSync.min.js` — 66 (1.64%)
- `//global.fncstatic.com/static/isa/core.js` — 65 (1.61%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 62 (1.54%)
- `//static.criteo.net/js/ld/ld.js` — 62 (1.54%)
- `//static.foxnews.com/static/strike/ver/foxnews/loader.global.js` — 61 (1.51%)

---
## INDIA → USA
### Comparable denominators
- Compared sites: **3335**
- Compared URLs: **4257**
### Differences (from summary)
- Sites with tracking in src only: **1103** (33.07% of compared sites)
- URLs with tracking in src only: **1288** (30.26% of compared URLs)
- Total tracking requests in src only: **7811**
- Requests with chain: **7470** (95.63% of total-diff)
- Requests without chain: **341** (4.37% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **3397** (45.48% of with-chain)
- dst_chain_match_inline: **818** (10.95% of with-chain)
- dst_chain_match_found: **3255** (43.57% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **65** (0.83%)
- `same-site`: **25** (0.32%)
- `cross-site`: **7721** (98.85%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **90** (1.15%)
- Third-party (cross-site): **7721** (98.85%)

### Top 10 third-party request domains (eTLD+1)
- `google.co.in` — 704 (9.12%)
- `adsco.re` — 324 (4.20%)
- `doubleclick.net` — 278 (3.60%)
- `google-analytics.com` — 186 (2.41%)
- `googletagmanager.com` — 173 (2.24%)
- `googlesyndication.com` — 167 (2.16%)
- `google.com` — 162 (2.10%)
- `yandex.ru` — 161 (2.09%)
- `rubiconproject.com` — 117 (1.52%)
- `tsyndicate.com` — 114 (1.48%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 29 (32.22%)
- `/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.min.js?ver=9.9.0` — 3 (3.33%)
- `/wp-content/plugins/koko-analytics/assets/dist/js/script.js?ver=2.0.18` — 2 (2.22%)
- `/api/16/store/?sentry_key=5e4c8aeec7fe62be0bdb5c79abec805a&sentry_version=7` — 2 (2.22%)
- `/wp-content/plugins/wp-rocket/assets/js/wpr-beacon.min.js` — 2 (2.22%)
- `/b/ss/nikkocojp/1/H.27.5/s22625872080956?AQB=1&ndh=1&t=16%2F9%2F2025%2020%3A11%3A32%204%200&ce=UTF-8&ns=nikkocordial&cdp=3&pageName=%5Btrd%5D%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BD%EF%BF%BD%EF%BD%BDK%EF%BF%BD%EF%BD%BDC%EF%BF%BD%EF%BD%BDh%20%EF%BF%BD%EF%BD%BD&g=https%3A%2F%2Ftrade.smbcnikko.co.jp%2Fhtml%2Fguide_kabu_tkeshi.html&cc=JPY&ch=trade.smbcnikko.co.jp%2Fhtml&server=trade.smbcnikko.co.jp&events=event11&c1=https%3A%2F%2Ftrade.smbcnikko.co.jp%2Fhtml%2Fguide_kabu_tkeshi.html&c2=D%3Dr&v2=D%3DpageName&c3=D%3DpageName&c5=D%3D%22New%3A%22%2BpageName&v5=%E5%88%9D%E5%9B%9E%E8%A8%AA%E5%95%8F%E8%80%85&c8=D%3Dv8&v8=Friday&c9=D%3Dv9&v9=5%3A00AM&v10=D%3DpageName&c11=trade.smbcnikko.co.jp%2Fhtml%2F%E7%9B%B4%E4%B8%8B&c12=trade.smbcnikko.co.jp%2Fhtml%2F%E7%9B%B4%E4%B8%8B&v12=D%3Dg&c13=D%3DpageName&c17=D%3Dv17&v17=https%3A%2F%2Ftrade.smbcnikko.co.jp%2Fhtml%2Fguide_kabu_tkeshi.html&c21=D%3Dv21&v21=%E7%9B%B4%E6%8E%A5%E6%B5%81%E5%85%A5&c23=D%3Dv21%2B%22%3A%22%2BpageName&v23=D%3Dv21%2B%22%3A%22%2BpageName&c25=D%3Dv21%2B%22%3A%22%2BpageName&c41=D%3Dv41&v41=Not%20Android-iPhone&c42=D%3Dv42&v42=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F140.0.0.0%20Safari%2F537.36&v73=D%3Dr&c74=https%3A%2F%2Ftrade.smbcnikko.co.jp%2Frsc%2Fjs%2Fs_code.js&v74=D%3Dc74&c75=20240509_H.27.5&v75=D%3Dc75&h1=trade.smbcnikko.co.jp%2Chtml%2Cguide_kabu_tkeshi.html&s=1024x768&c=24&j=1.6&v=N&k=Y&bw=1200&bh=1108&AQE=1` — 1 (1.11%)
- `/api/comscore?ts=1760557860687` — 1 (1.11%)
- `/event?s=631328&idclient=mgrscbmvumqfa03w` — 1 (1.11%)
- `/m` — 1 (1.11%)
- `/akam/13/b379ba6` — 1 (1.11%)

### `frame_main` distribution (details)
- main (1): **5109** (65.41%)
- non-main (0): **2702** (34.59%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://bcp.crwdcntrl.net` — 234 (8.66%)
- `https://pagead2.googlesyndication.com` — 124 (4.59%)
- `https://eus.rubiconproject.com` — 117 (4.33%)
- `https://c.adsco.re` — 106 (3.92%)
- `https://ssum-sec.casalemedia.com` — 102 (3.77%)
- `https://arabhotx.com` — 86 (3.18%)
- `https://onetag-sys.com` — 77 (2.85%)
- `https://googleads.g.doubleclick.net` — 76 (2.81%)
- `https://creative.sexchatters.com` — 69 (2.55%)
- `https://creative.xlivrdr.com` — 52 (1.92%)

### Tail of src chains (only among chains built)
- Chains built: **7470**
- Tail classified first-party: **906** (12.13%)
- Tail classified third-party: **6075** (81.33%)

#### Top 10 third-party tail SRCs
- `https://js.wpadmngr.com/static/adManager.js` — 212 (3.49%)
- `https://c.adsco.re/` — 139 (2.29%)
- `https://mc.webvisor.org/metrika/tag_ww.js` — 74 (1.22%)
- `https://hbagency.it/cdn/prebid_9_34_hb.js` — 73 (1.20%)
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 68 (1.12%)
- `https://a.magsrv.com/ad-provider.js` — 66 (1.09%)
- `https://js.wpushsdk.com/npc/sdk/wpu/npush.m.js` — 47 (0.77%)
- `https://www.google-analytics.com/analytics.js` — 46 (0.76%)
- `https://mc.yandex.ru/metrika/tag.js` — 45 (0.74%)
- `https://tags.crwdcntrl.net/lt/c/3825/lt.min.js` — 42 (0.69%)

#### Top 10 first-party tail SRCs
- `usync.js` — 36 (3.97%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 27 (2.98%)
- `/static/a7bbed3a/s/widgets/v4/Universal/main.efff7dd06e83080d1a67.js` — 22 (2.43%)
- `/static/a7bbed3a/s/widgets/ThumbSpot/main.4a4ab07664ccbe21d2fc.js` — 20 (2.21%)
- `//micro.rubiconproject.com/prebid/dynamic/11530.js` — 18 (1.99%)
- `//cdn.tsyndicate.com/sdk/v1/n.js` — 15 (1.66%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 13 (1.43%)
- `//madurird.com/5/6180508/?bnr=1` — 13 (1.43%)
- `//adzilla1.name/v9YKYQb.js` — 13 (1.43%)
- `//www.google-analytics.com/analytics.js` — 11 (1.21%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **3255**
- Matched SRC classified first-party: **757** (23.26%)
- Matched SRC classified third-party: **2498** (76.74%)

#### Top 10 third-party matched SRCs (found)
- `https://js.wpadmngr.com/static/adManager.js` — 224 (8.97%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 170 (6.81%)
- `https://mc.webvisor.org/metrika/tag_ww.js` — 81 (3.24%)
- `https://cdn.pubfuture-ad.com/v2/unit/pt.js` — 63 (2.52%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-WBXVMXS` — 56 (2.24%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-KX367LN` — 45 (1.80%)
- `https://media1.admicro.vn/cms/Arf.min.js` — 37 (1.48%)
- `https://platform.pubadx.one/pubadx-ad.js` — 33 (1.32%)
- `https://get.optad360.io/assets/js/prebid10.3.3.js` — 33 (1.32%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-P7M62WP` — 29 (1.16%)

#### Top 10 first-party matched SRCs (found)
- `usync.js` — 43 (5.68%)
- `//dynamic.criteo.com/js/ld/ld.js?a=94120` — 36 (4.76%)
- `//femalepilesteering.com/cd/90/e2/cd90e2fd845ce9409adcc25803b19bba.js` — 21 (2.77%)
- `//cdn.taboola.com/libtrc/eauctionsindia-publisher/loader.js` — 20 (2.64%)
- `//micro.rubiconproject.com/prebid/dynamic/11530.js` — 19 (2.51%)
- `/_next/static/chunks/main-b62ef0cef25df54f.js` — 19 (2.51%)
- `//adzilla1.name/v9YKYQb.js` — 16 (2.11%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 15 (1.98%)
- `//cdn.taboola.com/libtrc/adwelljsc-tuoitrevn/loader.js` — 15 (1.98%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 14 (1.85%)

---
## USA → ALGERIA
### Comparable denominators
- Compared sites: **3790**
- Compared URLs: **6418**
### Differences (from summary)
- Sites with tracking in src only: **1916** (50.55% of compared sites)
- URLs with tracking in src only: **2947** (45.92% of compared URLs)
- Total tracking requests in src only: **56036**
- Requests with chain: **55085** (98.30% of total-diff)
- Requests without chain: **951** (1.70% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **37110** (67.37% of with-chain)
- dst_chain_match_inline: **7991** (14.51% of with-chain)
- dst_chain_match_found: **9984** (18.12% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **1040** (1.86%)
- `same-site`: **691** (1.23%)
- `cross-site`: **54305** (96.91%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **1731** (3.09%)
- Third-party (cross-site): **54305** (96.91%)

### Top 10 third-party request domains (eTLD+1)
- `googlesyndication.com` — 4143 (7.63%)
- `doubleclick.net` — 3756 (6.92%)
- `googletagmanager.com` — 2248 (4.14%)
- `google.com` — 2021 (3.72%)
- `yandex.com` — 1694 (3.12%)
- `rubiconproject.com` — 1528 (2.81%)
- `google-analytics.com` — 1309 (2.41%)
- `pubmatic.com` — 1290 (2.38%)
- `adnxs.com` — 1143 (2.10%)
- `creativecdn.com` — 965 (1.78%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 698 (40.32%)
- `/log?format=json&hasfast=true&authuser=0` — 100 (5.78%)
- `/api/uisprime/track` — 14 (0.81%)
- `/wp-content/plugins/wp-rocket/assets/js/wpr-beacon.min.js` — 13 (0.75%)
- `/` — 13 (0.75%)
- `/pab-ssl.js?v=0.4` — 11 (0.64%)
- `/web/metrics` — 11 (0.64%)
- `/bdtrck/updDcEv` — 9 (0.52%)
- `/hit` — 8 (0.46%)
- `/v2/log/web?content_type=pbrequest&logid=021434&disable_compression=true` — 7 (0.40%)

### `frame_main` distribution (details)
- main (1): **30502** (54.43%)
- non-main (0): **25534** (45.57%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://googleads.g.doubleclick.net` — 2239 (8.77%)
- `https://pagead2.googlesyndication.com` — 1958 (7.67%)
- `https://eus.rubiconproject.com` — 1155 (4.52%)
- `https://cs-server-s2s.yellowblue.io` — 807 (3.16%)
- `https://s0.2mdn.net` — 596 (2.33%)
- `https://sync.inmobi.com` — 581 (2.28%)
- `https://onetag-sys.com` — 580 (2.27%)
- `https://ads.us.criteo.com` — 493 (1.93%)
- `https://ads.pubmatic.com` — 434 (1.70%)
- `https://visitor.omnitagjs.com` — 373 (1.46%)

### Tail of src chains (only among chains built)
- Chains built: **55085**
- Tail classified first-party: **6624** (12.03%)
- Tail classified third-party: **43808** (79.53%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 1821 (4.16%)
- `https://mc.yandex.ru/metrika/tag.js` — 973 (2.22%)
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 969 (2.21%)
- `https://www.google-analytics.com/analytics.js` — 403 (0.92%)
- `https://a.magsrv.com/ad-provider.js` — 397 (0.91%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202511040101/pubads_impl.js` — 296 (0.68%)
- `https://connect.facebook.net/en_US/fbevents.js` — 251 (0.57%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202511050101/pubads_impl.js` — 251 (0.57%)
- `https://js.onclckmn.com/static/onclicka.js` — 207 (0.47%)
- `https://analytics.tiktok.com/i18n/pixel/static/main.MTQwMDFhOTU1MQ.js` — 182 (0.42%)

#### Top 10 first-party tail SRCs
- `usync.js` — 489 (7.38%)
- `//imasdk.googleapis.com/formats/outstream/versioned/prod2/outstream_web_client_20251027_RC00/outstream.min.js` — 215 (3.25%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 214 (3.23%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 148 (2.23%)
- `/static/7fe8c77e/s/widgets/v4/Universal/main.9ca8ff76724190e868d6.js` — 146 (2.20%)
- `//ib.adnxs.com/async_usersync?cbfn=queuePixels` — 73 (1.10%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 72 (1.09%)
- `//bat.bing.com/bat.js` — 70 (1.06%)
- `//go.ezodn.com/hb/dall.js?cb=195-1-134` — 62 (0.94%)
- `obPixelFrame.js` — 57 (0.86%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **9984**
- Matched SRC classified first-party: **2589** (25.93%)
- Matched SRC classified third-party: **7395** (74.07%)

#### Top 10 third-party matched SRCs (found)
- `https://mc.yandex.ru/metrika/tag.js` — 913 (12.35%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 503 (6.80%)
- `https://connect.facebook.net/en_US/fbevents.js` — 156 (2.11%)
- `https://cdn.tynt.com/tc.js` — 147 (1.99%)
- `https://hbagency.it/cdn/prebid_9_52_hb.js` — 145 (1.96%)
- `https://mc.webvisor.org/metrika/tag_ww.js` — 137 (1.85%)
- `https://consent.cookiebot.com/uc.js?cbid=30afc6db-6adf-42aa-ad81-e096cec4956a&implementation=gtm&consentmode-dataredaction=dynamic&framework=TCFv2.2` — 124 (1.68%)
- `https://assets.evolutionadv.it/optiload/4.x.x/optiload.min.js` — 107 (1.45%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 107 (1.45%)
- `https://a.pub.network/word-tips/prod/history/27c8fcb5-e81e-4b6d-8fa2-8c3139f99327/pubfig.min.js?bypass=true` — 90 (1.22%)

#### Top 10 first-party matched SRCs (found)
- `//www.googletagmanager.com/gtm.js?id=GTM-KDDQ7L` — 283 (10.93%)
- `//adv.rtbuzz.net/w4192.js` — 82 (3.17%)
- `usync.js` — 79 (3.05%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 67 (2.59%)
- `/_next/static/chunks/47-5f3decddf82ec4a8.js` — 59 (2.28%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 56 (2.16%)
- `https://mgronline.com/js/libs/jquery.min.js?_=1_0_1` — 54 (2.09%)
- `https://icdn.lenta.ru/assets/webpack/vendorsOwl.9e47e3ea.js` — 53 (2.05%)
- `//cdn.vlitag.com/w/934ee574-be33-4ddc-a998-7bc7e9242cc7.js` — 47 (1.82%)
- `//mc.yandex.ru/metrika/tag.js` — 45 (1.74%)

---
## USA → GERMANY
### Comparable denominators
- Compared sites: **4353**
- Compared URLs: **7395**
### Differences (from summary)
- Sites with tracking in src only: **1937** (44.50% of compared sites)
- URLs with tracking in src only: **2987** (40.39% of compared URLs)
- Total tracking requests in src only: **37477**
- Requests with chain: **36787** (98.16% of total-diff)
- Requests without chain: **690** (1.84% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **23048** (62.65% of with-chain)
- dst_chain_match_inline: **3160** (8.59% of with-chain)
- dst_chain_match_found: **10579** (28.76% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **752** (2.01%)
- `same-site`: **348** (0.93%)
- `cross-site`: **36377** (97.06%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **1100** (2.94%)
- Third-party (cross-site): **36377** (97.06%)

### Top 10 third-party request domains (eTLD+1)
- `doubleclick.net` — 1775 (4.88%)
- `rubiconproject.com` — 1459 (4.01%)
- `pubmatic.com` — 1247 (3.43%)
- `cloudflareinsights.com` — 1078 (2.96%)
- `googlesyndication.com` — 1068 (2.94%)
- `adnxs.com` — 1027 (2.82%)
- `google.com` — 889 (2.44%)
- `2mdn.net` — 881 (2.42%)
- `creativecdn.com` — 842 (2.31%)
- `smartadserver.com` — 731 (2.01%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 665 (60.45%)
- `/_/_/trace/trace/` — 9 (0.82%)
- `/wp-content/plugins/wp-rocket/assets/js/wpr-beacon.min.js` — 6 (0.55%)
- `/zoneload/preroll_exo/load` — 6 (0.55%)
- `/perf-metrics-collector/v4/rum/bx/web` — 5 (0.45%)
- `/m` — 3 (0.27%)
- `/heicha/mw/abclite-2020-s.js` — 3 (0.27%)
- `/abdr` — 3 (0.27%)
- `/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.min.js?ver=9.9.0` — 3 (0.27%)
- `/event?s=631328&idclient=mhrnpoqir8p55b3o` — 2 (0.18%)

### `frame_main` distribution (details)
- main (1): **16478** (43.97%)
- non-main (0): **20999** (56.03%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://pagead2.googlesyndication.com` — 1759 (8.38%)
- `https://googleads.g.doubleclick.net` — 1375 (6.55%)
- `https://eus.rubiconproject.com` — 1119 (5.33%)
- `https://cs-server-s2s.yellowblue.io` — 841 (4.00%)
- `https://s0.2mdn.net` — 622 (2.96%)
- `https://onetag-sys.com` — 587 (2.80%)
- `https://sync.inmobi.com` — 479 (2.28%)
- `https://ads.pubmatic.com` — 422 (2.01%)
- `https://bcp.crwdcntrl.net` — 384 (1.83%)
- `https://ash.creativecdn.com` — 382 (1.82%)

### Tail of src chains (only among chains built)
- Chains built: **36787**
- Tail classified first-party: **4384** (11.92%)
- Tail classified third-party: **29359** (79.81%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 1938 (6.60%)
- `https://js.onclckmn.com/static/onclicka.js` — 231 (0.79%)
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 213 (0.73%)
- `https://statics.creativecdn.com/1i4SekErFfu4zIJjduQpCpYVk8cDbf0d/main/total.js` — 191 (0.65%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 158 (0.54%)
- `https://cdn.id5-sync.com/api/1.0/id5PrebidModule.js` — 142 (0.48%)
- `https://cdn.id5-sync.com/api/1.0/id5-api.js` — 134 (0.46%)
- `https://hbagency.it/cdn/prebid_9_34_hb.js` — 132 (0.45%)
- `https://www.google-analytics.com/analytics.js` — 119 (0.41%)
- `https://tags.crwdcntrl.net/lt/c/16589/sync.min.js` — 112 (0.38%)

#### Top 10 first-party tail SRCs
- `usync.js` — 554 (12.64%)
- `//imasdk.googleapis.com/formats/outstream/versioned/prod2/outstream_web_client_20251027_RC00/outstream.min.js` — 229 (5.22%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 91 (2.08%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 84 (1.92%)
- `//ib.adnxs.com/async_usersync?cbfn=queuePixels` — 66 (1.51%)
- `//cdn.tsyndicate.com/sdk/v1/hls.light.min.js` — 64 (1.46%)
- `//cdn.snigelweb.com/prebid/9.43.0/prebid.js?v=17029-1762780254828` — 59 (1.35%)
- `/static/7fe8c77e/s/widgets/v4/Universal/main.9ca8ff76724190e868d6.js` — 57 (1.30%)
- `//cdn.vlitag.com/pbs/c72434b3-eb8e-4110-8d36-02c64c016dc4/prebid-10.7.0.js?t=1762923761` — 56 (1.28%)
- `code.min.js` — 52 (1.19%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **10579**
- Matched SRC classified first-party: **2988** (28.24%)
- Matched SRC classified third-party: **7591** (71.76%)

#### Top 10 third-party matched SRCs (found)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 643 (8.47%)
- `https://cdn.tynt.com/tc.js` — 179 (2.36%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 134 (1.77%)
- `https://platform.pubadx.one/pubadx-ad.js` — 129 (1.70%)
- `https://static.foxnews.com/static/isa/core-app.js` — 126 (1.66%)
- `https://lib.wtg-ads.com/publisher/www.90minut.pl/lib.min.js` — 103 (1.36%)
- `https://JRyhoywLYXNLYMAhs.ay.delivery/manager/JRyhoywLYXNLYMAhs` — 101 (1.33%)
- `https://www.googletagservices.com/tag/js/gpt.js` — 90 (1.19%)
- `https://stpd.cloud/saas/3148` — 82 (1.08%)
- `https://cpt.geniee.jp/hb/v1/lib/prebid-v9.50.0.js` — 79 (1.04%)

#### Top 10 first-party matched SRCs (found)
- `//s10.histats.com/js15_as.js` — 319 (10.68%)
- `//palibzh.tech/libs/projectagora.min.js` — 142 (4.75%)
- `//securepubads.g.doubleclick.net/tag/js/gpt.js` — 124 (4.15%)
- `usync.js` — 105 (3.51%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 65 (2.18%)
- `//dsh7ky7308k4b.cloudfront.net/publishers/minijuegoscom.min.js` — 51 (1.71%)
- `//cdn.taboola.com/libtrc/divinelightindia-network/loader.js` — 46 (1.54%)
- `//cdn.vlitag.com/w/934ee574-be33-4ddc-a998-7bc7e9242cc7.js` — 41 (1.37%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 39 (1.31%)
- `//anymind360.com/js/910/ats.js` — 35 (1.17%)

---
## USA → INDIA
### Comparable denominators
- Compared sites: **3335**
- Compared URLs: **4257**
### Differences (from summary)
- Sites with tracking in src only: **1324** (39.70% of compared sites)
- URLs with tracking in src only: **1621** (38.08% of compared URLs)
- Total tracking requests in src only: **24922**
- Requests with chain: **24434** (98.04% of total-diff)
- Requests without chain: **488** (1.96% of total-diff)
### Destination chain outcome (only among requests_with_chain)
- dst_chain_match_not_found: **15139** (61.96% of with-chain)
- dst_chain_match_inline: **2511** (10.28% of with-chain)
- dst_chain_match_found: **6784** (27.76% of with-chain)
### `etld_request_url_rel` distribution (details)
- `same-origin`: **594** (2.38%)
- `same-site`: **174** (0.70%)
- `cross-site`: **24154** (96.92%)

### First-party vs Third-party (derived from `etld_request_url_rel`)
- First-party (same-site+same-origin): **768** (3.08%)
- Third-party (cross-site): **24154** (96.92%)

### Top 10 third-party request domains (eTLD+1)
- `googlesyndication.com` — 1204 (4.98%)
- `doubleclick.net` — 1187 (4.91%)
- `yandex.com` — 1062 (4.40%)
- `rubiconproject.com` — 790 (3.27%)
- `google.com` — 697 (2.89%)
- `pubmatic.com` — 666 (2.76%)
- `adnxs.com` — 627 (2.60%)
- `cloudflareinsights.com` — 605 (2.50%)
- `googletagmanager.com` — 561 (2.32%)
- `creativecdn.com` — 478 (1.98%)

### Top 10 first-party request paths (path only)
- `/cdn-cgi/rum` — 394 (51.30%)
- `/api/uisprime/track` — 21 (2.73%)
- `/?log=stats-beta` — 14 (1.82%)
- `/event/home-globo` — 12 (1.56%)
- `/egcs/v2/collect` — 10 (1.30%)
- `/dot/pop4.php` — 9 (1.17%)
- `/?log=experiment` — 9 (1.17%)
- `/?log=united-impression` — 9 (1.17%)
- `/?log=xh-widgets-events-v2` — 8 (1.04%)
- `/v1/devices/events/web` — 8 (1.04%)

### `frame_main` distribution (details)
- main (1): **12490** (50.12%)
- non-main (0): **12432** (49.88%)

### Top 10 `frame_origin` among non-main-frame requests
- `https://pagead2.googlesyndication.com` — 909 (7.31%)
- `https://googleads.g.doubleclick.net` — 715 (5.75%)
- `https://eus.rubiconproject.com` — 591 (4.75%)
- `https://cs-server-s2s.yellowblue.io` — 477 (3.84%)
- `https://sync.inmobi.com` — 261 (2.10%)
- `https://s0.2mdn.net` — 254 (2.04%)
- `https://cdn.amon1.net` — 228 (1.83%)
- `https://ads.pubmatic.com` — 224 (1.80%)
- `https://ads.us.criteo.com` — 223 (1.79%)
- `https://ash.creativecdn.com` — 219 (1.76%)

### Tail of src chains (only among chains built)
- Chains built: **24434**
- Tail classified first-party: **2997** (12.27%)
- Tail classified third-party: **19664** (80.48%)

#### Top 10 third-party tail SRCs
- `https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015` — 1155 (5.87%)
- `https://mc.yandex.ru/metrika/tag.js` — 560 (2.85%)
- `https://a.magsrv.com/ad-provider.js` — 196 (1.00%)
- `https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js` — 185 (0.94%)
- `https://mc.webvisor.org/metrika/tag_ww.js` — 153 (0.78%)
- `https://cdn.intergient.com/prebid/prebid.ae6790c95efdb5dcce9e.js` — 108 (0.55%)
- `https://statics.creativecdn.com/1i4SekErFfu4zIJjduQpCpYVk8cDbf0d/main/total.js` — 97 (0.49%)
- `https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202511040101/pubads_impl.js` — 95 (0.48%)
- `https://www.google-analytics.com/analytics.js` — 94 (0.48%)
- `https://connect.facebook.net/en_US/fbevents.js` — 94 (0.48%)

#### Top 10 first-party tail SRCs
- `usync.js` — 268 (8.94%)
- `//imasdk.googleapis.com/formats/outstream/versioned/prod2/outstream_web_client_20251027_RC00/outstream.min.js` — 116 (3.87%)
- `//c.amazon-adsystem.com/aax2/apstag.js` — 95 (3.17%)
- `//cdn.id5-sync.com/api/1.0/id5-api.js` — 86 (2.87%)
- `/static/7fe8c77e/s/LPOmega/main.daf4501d6ecc0950079a.js` — 69 (2.30%)
- `code.min.js` — 52 (1.74%)
- `//s.clickiocdn.com/t/233047/360_light.js` — 50 (1.67%)
- `/static/7fe8c77e/s/widgets/v4/Universal/main.9ca8ff76724190e868d6.js` — 48 (1.60%)
- `//news.jennydanny.com/oT5Ugwa.js` — 41 (1.37%)
- `//bat.bing.com/bat.js` — 40 (1.33%)

### For dst_chain_match_found only: matched SRC first-party vs third-party
- Found matches: **6784**
- Matched SRC classified first-party: **1715** (25.28%)
- Matched SRC classified third-party: **5069** (74.72%)

#### Top 10 third-party matched SRCs (found)
- `https://mc.yandex.ru/metrika/tag.js` — 657 (12.96%)
- `https://securepubads.g.doubleclick.net/tag/js/gpt.js` — 353 (6.96%)
- `https://www.googletagservices.com/tag/js/gpt.js` — 134 (2.64%)
- `https://mc.webvisor.org/metrika/tag_ww.js` — 128 (2.53%)
- `https://assets.evolutionadv.it/optiload/4.x.x/optiload.min.js` — 117 (2.31%)
- `https://a.pub.network/emojipedia-org/pubfig.min.js` — 101 (1.99%)
- `https://platform.pubadx.one/pubadx-ad.js` — 100 (1.97%)
- `https://www.googletagmanager.com/gtm.js?id=GTM-T6ZGQ5Q&l=dataLayerObs` — 98 (1.93%)
- `https://cadmus.script.ac/ddla593ymz72o/script.js` — 88 (1.74%)
- `https://static.rba.nom.es/ads/pb9-general_250916.js` — 75 (1.48%)

#### Top 10 first-party matched SRCs (found)
- `//www.googletagmanager.com/gtm.js?id=GTM-KDDQ7L` — 162 (9.45%)
- `/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js` — 150 (8.75%)
- `/app-183cff673b2478558c13.js` — 88 (5.13%)
- `//www.googletagmanager.com/gtm.js?id=GTM-WSZ3V98` — 63 (3.67%)
- `usync.js` — 54 (3.15%)
- `//waust.at/s.js` — 45 (2.62%)
- `//dynamic.criteo.com/js/ld/ld.js?a=121128&a=121384` — 38 (2.22%)
- `//hu.adocean.pl/files/js/ado.js` — 37 (2.16%)
- `//dynamic.criteo.com/js/ld/ld.js?a=28657` — 34 (1.98%)
- `/build/scheduler.502d905fb8.js` — 30 (1.75%)

---
