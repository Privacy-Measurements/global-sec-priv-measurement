import argparse
import csv
import glob
import json
import os
from collections import Counter, defaultdict
from urllib.parse import urlparse

# --- eTLD+1 extraction (no network fetch) ---
try:
    import tldextract  # type: ignore
    _TLD_EXTRACTOR = tldextract.TLDExtract(suffix_list_urls=None)

    def etld_plus_one_from_host(host: str) -> str:
        host = (host or "").strip().lower().strip(".")
        if not host:
            return ""
        ext = _TLD_EXTRACTOR(host)
        if not ext.domain or not ext.suffix:
            return ""
        return f"{ext.domain}.{ext.suffix}"

except Exception:
    # naive fallback (may be wrong for co.uk etc.)
    def etld_plus_one_from_host(host: str) -> str:
        host = (host or "").strip().lower().strip(".")
        if not host:
            return ""
        parts = [p for p in host.split(".") if p]
        if len(parts) < 2:
            return host
        return ".".join(parts[-2:])


def host_from_url(u: str) -> str:
    if not u:
        return ""
    u = str(u).strip()
    if not u:
        return ""
    try:
        p = urlparse(u if "://" in u else ("http://" + u))
        host = (p.netloc or "").strip().lower()
        if "@" in host:
            host = host.split("@", 1)[1]
        if ":" in host:
            host = host.split(":", 1)[0]
        return host
    except Exception:
        return ""


def is_urlish(s: str) -> bool:
    if not s:
        return False
    s = s.strip()
    return ("://" in s) or s.startswith("//")


def url_path_only(u: str) -> str:
    """Keep only path (+query)."""
    if not u:
        return ""
    try:
        p = urlparse(u if "://" in u else ("http://" + u))
        path = p.path or "/"
        if p.query:
            return f"{path}?{p.query}"
        return path
    except Exception:
        return ""


def pct(num: int, den: int) -> float:
    if den <= 0:
        return 0.0
    return 100.0 * float(num) / float(den)


def fmt_pct(num: int, den: int) -> str:
    return f"{pct(num, den):.2f}%"


def topn_lines(counter: Counter, n: int, denom: int):
    """Return markdown bullet lines: '- item — count (xx.xx%)'."""
    lines = []
    if denom <= 0:
        denom = 0
    for item, c in counter.most_common(n):
        p = pct(c, denom) if denom > 0 else 0.0
        lines.append(f"- `{item}` — {c} ({p:.2f}%)")
    if not lines:
        lines.append("- (none)")
    return lines


def classify_fp_tp_from_rel(rel: str) -> str:
    rel = (rel or "").strip().lower()
    if rel in ("same-site", "same-origin"):
        return "first_party"
    if rel == "cross-site":
        return "third_party"
    return "unknown"


def anchor_value_for_chain_node(node: dict) -> str:
    if not node:
        return ""
    kind = node.get("kind")
    if kind == "script":
        return (node.get("script_src") or "").strip()
    return (node.get("src") or "").strip()


def classify_anchor_fp_tp(anchor: str, site_etld: str) -> str:
    """
    Your rule:
      - if not a URL => first-party
      - else compare eTLD+1(anchor) vs site_etld
    """
    anchor = (anchor or "").strip()
    site_etld = (site_etld or "").strip().lower()
    if not anchor:
        return "unknown"

    if not is_urlish(anchor):
        return "first_party"

    host = host_from_url(anchor)
    a_etld = etld_plus_one_from_host(host)
    if not a_etld or not site_etld:
        return "first_party"
    return "first_party" if a_etld == site_etld else "third_party"


def parse_pair_from_filename(path: str):
    base = os.path.basename(path)
    if "_TO_" not in base:
        return None
    left = base.split("_TO_", 1)[0]
    rest = base.split("_TO_", 1)[1]
    right = rest.split("_", 1)[0]
    return left, right


def load_summary(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    return obj.get("summary", obj)


def iter_details_jsonl(path: str):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def analyze_pair(summary_path: str, details_path: str):
    summary = load_summary(summary_path)
    stats = summary.get("stats", {})

    src = summary.get("src_loc") or (summary.get("direction") or {}).get("src_loc")
    dst = summary.get("dst_loc") or (summary.get("direction") or {}).get("dst_loc")

    comparable_sites = int(stats.get("comparable_sites", 0))
    comparable_urls = int(stats.get("comparable_urls", 0))

    sites_src_only = int(stats.get("sites_with_tracking_in_src_only", 0))
    urls_src_only = int(stats.get("urls_with_tracking_in_src_only", 0))
    total_diff_reqs = int(stats.get("total_tracking_requests_in_src_only", 0))

    reqs_with_chain = int(stats.get("requests_with_chain", 0))
    reqs_without_chain = int(stats.get("requests_without_chain", 0))

    dst_not_found = int(stats.get("dst_chain_match_not_found", 0))
    dst_inline = int(stats.get("dst_chain_match_inline", 0))
    dst_found = int(stats.get("dst_chain_match_found", 0))

    # --- details-derived ---
    rel_counter = Counter()
    fp_tp_counter = Counter()

    third_party_domain_counter = Counter()
    first_party_path_counter = Counter()

    frame_main_counter = Counter()
    non_main_origin_counter = Counter()

    chains_built = 0
    tail_fp_tp_counter = Counter()
    tail_third_party_src_counter = Counter()
    tail_first_party_src_counter = Counter()

    found_total = 0
    found_match_fp_tp_counter = Counter()
    found_third_party_src_counter = Counter()
    found_first_party_src_counter = Counter()

    for rec in iter_details_jsonl(details_path):
        site_etld = ((rec.get("site") or {}).get("etld") or "").strip().lower()
        req = rec.get("request") or {}
        request_url = (req.get("request_url") or "").strip()
        rel = (req.get("etld_request_url_rel") or "").strip().lower()
        frame_main = req.get("frame_main")
        frame_origin = (req.get("frame_origin") or "").strip()

        # rel / fp-tp
        rel_counter[rel if rel else "missing"] += 1
        cls = classify_fp_tp_from_rel(rel)
        fp_tp_counter[cls] += 1

        if cls == "third_party":
            host = host_from_url(request_url)
            dom = etld_plus_one_from_host(host) or host or "unknown"
            third_party_domain_counter[dom] += 1

        if cls == "first_party":
            path = url_path_only(request_url) or "unknown"
            first_party_path_counter[path] += 1

        # frame_main
        if frame_main in (0, 1, "0", "1", True, False):
            val = 1 if frame_main in (1, "1", True) else 0
            frame_main_counter[str(val)] += 1
            if val == 0 and frame_origin:
                non_main_origin_counter[frame_origin] += 1
        else:
            frame_main_counter["missing"] += 1

        # chain tail
        chain = rec.get("html_chain_src_top_to_tail") or []
        if chain:
            chains_built += 1
            tail = chain[-1]
            tail_anchor = anchor_value_for_chain_node(tail)
            tail_cls = classify_anchor_fp_tp(tail_anchor, site_etld)
            tail_fp_tp_counter[tail_cls] += 1
            if tail_cls == "third_party":
                tail_third_party_src_counter[tail_anchor or "missing"] += 1
            elif tail_cls == "first_party":
                tail_first_party_src_counter[tail_anchor or "missing"] += 1

        # dst match found
        match = rec.get("dst_match_attempt") or {}
        if match.get("found") is True:
            found_total += 1
            matched_value = (match.get("matched_value") or "").strip()
            mcls = classify_anchor_fp_tp(matched_value, site_etld)
            found_match_fp_tp_counter[mcls] += 1
            if mcls == "third_party":
                found_third_party_src_counter[matched_value or "missing"] += 1
            elif mcls == "first_party":
                found_first_party_src_counter[matched_value or "missing"] += 1

    result = {
        "src": src, "dst": dst,
        "comparable_sites": comparable_sites,
        "comparable_urls": comparable_urls,
        "sites_src_only": sites_src_only,
        "urls_src_only": urls_src_only,
        "total_diff_reqs": total_diff_reqs,
        "reqs_with_chain": reqs_with_chain,
        "reqs_without_chain": reqs_without_chain,
        "dst_not_found": dst_not_found,
        "dst_inline": dst_inline,
        "dst_found": dst_found,

        "rel_counter": rel_counter,
        "fp_tp_counter": fp_tp_counter,
        "third_party_domain_counter": third_party_domain_counter,
        "first_party_path_counter": first_party_path_counter,

        "frame_main_counter": frame_main_counter,
        "non_main_origin_counter": non_main_origin_counter,

        "chains_built": chains_built,
        "tail_fp_tp_counter": tail_fp_tp_counter,
        "tail_third_party_src_counter": tail_third_party_src_counter,
        "tail_first_party_src_counter": tail_first_party_src_counter,

        "found_total": found_total,
        "found_match_fp_tp_counter": found_match_fp_tp_counter,
        "found_third_party_src_counter": found_third_party_src_counter,
        "found_first_party_src_counter": found_first_party_src_counter,
    }
    return result


def md_pair_section(r: dict) -> str:
    src = r["src"]; dst = r["dst"]
    comp_sites = r["comparable_sites"]
    comp_urls = r["comparable_urls"]

    sites_src_only = r["sites_src_only"]
    urls_src_only = r["urls_src_only"]
    total = r["total_diff_reqs"]

    with_chain = r["reqs_with_chain"]
    without_chain = r["reqs_without_chain"]

    nf = r["dst_not_found"]
    inline = r["dst_inline"]
    found = r["dst_found"]

    fp = r["fp_tp_counter"].get("first_party", 0)
    tp = r["fp_tp_counter"].get("third_party", 0)
    unk = r["fp_tp_counter"].get("unknown", 0)

    non_main = r["frame_main_counter"].get("0", 0)
    main = r["frame_main_counter"].get("1", 0)

    chains_built = r["chains_built"]
    tail_fp = r["tail_fp_tp_counter"].get("first_party", 0)
    tail_tp = r["tail_fp_tp_counter"].get("third_party", 0)

    found_total = r["found_total"]
    found_fp = r["found_match_fp_tp_counter"].get("first_party", 0)
    found_tp = r["found_match_fp_tp_counter"].get("third_party", 0)

    lines = []
    lines.append(f"## {src} → {dst}\n")

    lines.append("### Comparable denominators\n")
    lines.append(f"- Compared sites: **{comp_sites}**\n")
    lines.append(f"- Compared URLs: **{comp_urls}**\n")

    lines.append("### Differences (from summary)\n")
    lines.append(f"- Sites with tracking in src only: **{sites_src_only}** ({fmt_pct(sites_src_only, comp_sites)} of compared sites)\n")
    lines.append(f"- URLs with tracking in src only: **{urls_src_only}** ({fmt_pct(urls_src_only, comp_urls)} of compared URLs)\n")
    lines.append(f"- Total tracking requests in src only: **{total}**\n")
    lines.append(f"- Requests with chain: **{with_chain}** ({fmt_pct(with_chain, total)} of total-diff)\n")
    lines.append(f"- Requests without chain: **{without_chain}** ({fmt_pct(without_chain, total)} of total-diff)\n")

    lines.append("### Destination chain outcome (only among requests_with_chain)\n")
    lines.append(f"- dst_chain_match_not_found: **{nf}** ({fmt_pct(nf, with_chain)} of with-chain)\n")
    lines.append(f"- dst_chain_match_inline: **{inline}** ({fmt_pct(inline, with_chain)} of with-chain)\n")
    lines.append(f"- dst_chain_match_found: **{found}** ({fmt_pct(found, with_chain)} of with-chain)\n")

    lines.append("### `etld_request_url_rel` distribution (details)\n")
    # Print as bullets in a stable order
    rel = r["rel_counter"]
    for k in ["same-origin", "same-site", "cross-site", "missing"]:
        if k in rel:
            lines.append(f"- `{k}`: **{rel[k]}** ({fmt_pct(rel[k], sum(rel.values()))})\n")

    lines.append("\n### First-party vs Third-party (derived from `etld_request_url_rel`)\n")
    denom_rel = fp + tp + unk
    lines.append(f"- First-party (same-site+same-origin): **{fp}** ({fmt_pct(fp, denom_rel)})\n")
    lines.append(f"- Third-party (cross-site): **{tp}** ({fmt_pct(tp, denom_rel)})\n")
    if unk:
        lines.append(f"- Unknown/other: **{unk}** ({fmt_pct(unk, denom_rel)})\n")

    lines.append("\n### Top 10 third-party request domains (eTLD+1)\n")
    lines.extend([l + "\n" for l in topn_lines(r["third_party_domain_counter"], 10, tp)])

    lines.append("\n### Top 10 first-party request paths (path only)\n")
    lines.extend([l + "\n" for l in topn_lines(r["first_party_path_counter"], 10, fp)])

    lines.append("\n### `frame_main` distribution (details)\n")
    denom_fm = main + non_main + r["frame_main_counter"].get("missing", 0)
    if "1" in r["frame_main_counter"]:
        lines.append(f"- main (1): **{main}** ({fmt_pct(main, denom_fm)})\n")
    if "0" in r["frame_main_counter"]:
        lines.append(f"- non-main (0): **{non_main}** ({fmt_pct(non_main, denom_fm)})\n")
    if r["frame_main_counter"].get("missing", 0):
        lines.append(f"- missing: **{r['frame_main_counter']['missing']}** ({fmt_pct(r['frame_main_counter']['missing'], denom_fm)})\n")

    lines.append("\n### Top 10 `frame_origin` among non-main-frame requests\n")
    lines.extend([l + "\n" for l in topn_lines(r["non_main_origin_counter"], 10, non_main)])

    lines.append("\n### Tail of src chains (only among chains built)\n")
    lines.append(f"- Chains built: **{chains_built}**\n")
    lines.append(f"- Tail classified first-party: **{tail_fp}** ({fmt_pct(tail_fp, chains_built)})\n")
    lines.append(f"- Tail classified third-party: **{tail_tp}** ({fmt_pct(tail_tp, chains_built)})\n")

    lines.append("\n#### Top 10 third-party tail SRCs\n")
    lines.extend([l + "\n" for l in topn_lines(r["tail_third_party_src_counter"], 10, tail_tp)])

    lines.append("\n#### Top 10 first-party tail SRCs\n")
    lines.extend([l + "\n" for l in topn_lines(r["tail_first_party_src_counter"], 10, tail_fp)])

    lines.append("\n### For dst_chain_match_found only: matched SRC first-party vs third-party\n")
    lines.append(f"- Found matches: **{found_total}**\n")
    lines.append(f"- Matched SRC classified first-party: **{found_fp}** ({fmt_pct(found_fp, found_total)})\n")
    lines.append(f"- Matched SRC classified third-party: **{found_tp}** ({fmt_pct(found_tp, found_total)})\n")

    lines.append("\n#### Top 10 third-party matched SRCs (found)\n")
    lines.extend([l + "\n" for l in topn_lines(r["found_third_party_src_counter"], 10, found_tp)])

    lines.append("\n#### Top 10 first-party matched SRCs (found)\n")
    lines.extend([l + "\n" for l in topn_lines(r["found_first_party_src_counter"], 10, found_fp)])

    lines.append("\n---\n")
    return "".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--d1_dir", default="../processed_data/tracking/D1", help="Path to D1 output directory")
    ap.add_argument("--out_dir", default=None, help="Output directory (default: <d1_dir>/analysis)")
    ap.add_argument("--write_json", action="store_true", help="Also write per-pair JSON analysis files")
    args = ap.parse_args()

    d1_dir = args.d1_dir
    out_dir = args.out_dir or '.'
    os.makedirs(out_dir, exist_ok=True)

    summary_paths = sorted(glob.glob(os.path.join(d1_dir, "*_summary.json")))
    if not summary_paths:
        raise SystemExit(f"No summary files found in {d1_dir}")

    # CSV table (summary-derived)
    out_csv = os.path.join(out_dir, "tracking_D1_PAIR_LEVEL_summary_table.csv")
    fieldnames = [
        "src_loc", "dst_loc",
        "comparable_sites", "comparable_urls",
        "sites_with_tracking_in_src_only", "sites_with_tracking_in_src_only_pct",
        "urls_with_tracking_in_src_only", "urls_with_tracking_in_src_only_pct",
        "total_tracking_requests_in_src_only",
        "requests_with_chain", "requests_with_chain_pct",
        "requests_without_chain", "requests_without_chain_pct",
        "dst_chain_match_not_found", "dst_chain_match_not_found_pct",
        "dst_chain_match_inline", "dst_chain_match_inline_pct",
        "dst_chain_match_found", "dst_chain_match_found_pct",
    ]

    csv_rows = []
    md_sections = []
    json_reports = {}

    for sp in summary_paths:
        pair = parse_pair_from_filename(sp)
        if not pair:
            continue
        src, dst = pair
        dp = os.path.join(d1_dir, f"{src}_TO_{dst}_details.jsonl")
        if not os.path.exists(dp):
            print(f"[WARN] Missing details for {src}_TO_{dst}: {dp}")
            continue

        print(f"[INFO] Analyzing {src} -> {dst}")
        r = analyze_pair(sp, dp)

        # markdown section
        md_sections.append(md_pair_section(r))

        # csv row (summary-derived)
        comp_sites = r["comparable_sites"]
        comp_urls = r["comparable_urls"]
        total = r["total_diff_reqs"]
        with_chain = r["reqs_with_chain"]

        csv_rows.append({
            "src_loc": src,
            "dst_loc": dst,
            "comparable_sites": comp_sites,
            "comparable_urls": comp_urls,

            "sites_with_tracking_in_src_only": r["sites_src_only"],
            "sites_with_tracking_in_src_only_pct": pct(r["sites_src_only"], comp_sites),

            "urls_with_tracking_in_src_only": r["urls_src_only"],
            "urls_with_tracking_in_src_only_pct": pct(r["urls_src_only"], comp_urls),

            "total_tracking_requests_in_src_only": total,

            "requests_with_chain": with_chain,
            "requests_with_chain_pct": pct(with_chain, total),

            "requests_without_chain": r["reqs_without_chain"],
            "requests_without_chain_pct": pct(r["reqs_without_chain"], total),

            "dst_chain_match_not_found": r["dst_not_found"],
            "dst_chain_match_not_found_pct": pct(r["dst_not_found"], with_chain),

            "dst_chain_match_inline": r["dst_inline"],
            "dst_chain_match_inline_pct": pct(r["dst_inline"], with_chain),

            "dst_chain_match_found": r["dst_found"],
            "dst_chain_match_found_pct": pct(r["dst_found"], with_chain),
        })

        if args.write_json:
            key = f"{src}_TO_{dst}"
            json_reports[key] = {
                "pair": {"src_loc": src, "dst_loc": dst},
                "computed": {k: (dict(v) if isinstance(v, Counter) else v) for k, v in r.items()},
            }

    # write CSV
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in csv_rows:
            w.writerow(row)

    # write Markdown
    out_md = os.path.join(out_dir, "tracking_D1_REPORT.md")
    header = [
        "# D1 Tracking Difference Analysis Report\n",
        f"- Input directory: `{os.path.abspath(d1_dir)}`\n",
        f"- Pairs analyzed: **{len(md_sections)}**\n",
        "\n---\n\n",
    ]
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("".join(header))
        for s in md_sections:
            f.write(s)

    # optional JSON
    if args.write_json:
        out_json = os.path.join(out_dir, "ALL_PAIRS_analysis.json")
        # Counters are not JSON serializable directly; convert carefully.
        serializable = {}
        for k, v in json_reports.items():
            computed = {}
            for ck, cv in v["computed"].items():
                if isinstance(cv, Counter):
                    computed[ck] = dict(cv)
                else:
                    computed[ck] = cv
            serializable[k] = {"pair": v["pair"], "computed": computed}
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(serializable, f, ensure_ascii=False, indent=2)

    print(f"[DONE] Wrote Markdown report: {out_md}")
    print(f"[DONE] Wrote CSV table: {out_csv}")
    if args.write_json:
        print(f"[DONE] Wrote combined JSON: {out_json}")


if __name__ == "__main__":
    main()
