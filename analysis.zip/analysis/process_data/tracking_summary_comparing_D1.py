import json
import pymysql
from collections import defaultdict, Counter
from urllib.parse import urlparse
from config import db_params
import tldextract  
_TLD_EXTRACTOR = tldextract.TLDExtract(suffix_list_urls=None)



TARGET_LOCATIONS = ("ALGERIA", "INDIA", "USA", "GERMANY")

#TARGET_LOCATIONS = ("ALGERIA", "USA")

CATEGORY = "global"

TRACKER_ONLY_COMPLETE = False

OUT_BASE = "../processed_data/tracking/D1"


def norm_src(s):
    if s is None:
        return ""
    return str(s).strip()

def load_sessions():
    placeholders = ",".join(["%s"] * len(TARGET_LOCATIONS))
    sql = f"""
        SELECT id, location, etld, url, category
        FROM crawl_sessions
        WHERE etld_url_rel <> 'cross-site'
          AND is_cloudflare is not True
          AND category = %s
          AND location IN ({placeholders})
    """
    #      and etld = 'www.cesenatoday.it' 
    #      and url = 'https://www.cesenatoday.it/attualita/pastificio-appuntamento-in-centro-colazione.html'
    
    conn = pymysql.connect(**db_params)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (CATEGORY, *TARGET_LOCATIONS))
            return cur.fetchall()
    finally:
        conn.close()

def host_from_url(u):
    if not u:
        return ""
    u = str(u).strip()
    if not u:
        return ""
    try:
        p = urlparse(u if "://" in u else ("http://" + u))
        host = (p.netloc or "").strip().lower()

        # strip creds and port
        if "@" in host:
            host = host.split("@", 1)[1]
        if ":" in host:
            host = host.split(":", 1)[0]

        return host
    except Exception:
        return ""

def etld_plus_one(host):
    host = (host or "").strip().lower().strip(".")
    if not host:
        return ""
    ext = _TLD_EXTRACTOR(host)
    if not ext.suffix or not ext.domain:
        return ""
    return f"{ext.domain}.{ext.suffix}"

def tracker_etld_plus1_from_request_row(r):
    host = host_from_url(r.get("request_url", ""))
    return etld_plus_one(host)

def build_sessions_index(sessions):
    sessions_by_site_loc = defaultdict(lambda: defaultdict(list))
    for r in sessions:
        key = (r["etld"], r["url"])
        sessions_by_site_loc[key][r["location"]].append(r["id"])
    return sessions_by_site_loc

def pick_one_session(sessions_by_site_loc, site_key, loc):
    ids = sessions_by_site_loc[site_key].get(loc, [])
    if not ids:
        return None
    return min(ids)

def eligible_sites_for_pair(sessions_by_site_loc, loc1, loc2):
    out = []
    for site_key, per_loc in sessions_by_site_loc.items():
        if loc1 in per_loc and loc2 in per_loc:
            out.append(site_key)
    return out

def load_requests_html_scripts_for_sessions(session_ids):

    requests_by_session = defaultdict(list)
    html_by_session = defaultdict(dict)
    html_src_index_by_session = defaultdict(lambda: defaultdict(list))
    scripts_by_session = defaultdict(dict)  
    scripts_src_index_by_session = defaultdict(lambda: defaultdict(list))  # NEW

    if not session_ids:
        return requests_by_session, html_by_session, html_src_index_by_session, scripts_by_session, scripts_src_index_by_session

    placeholders = ",".join(["%s"] * len(session_ids))
    conn = pymysql.connect(**db_params)
    try:
        with conn.cursor() as cur:
            # ---- tracker requests ----
            if TRACKER_ONLY_COMPLETE:
                req_sql = f"""
                    SELECT
                        id AS request_row_id,
                        session_id,
                        request_id,
                        request_url,
                        frame_main,
                        frame_url,
                        frame_origin,
                        parent_id,
                        request_type,
                        etld_request_url_rel,
                        result_status
                    FROM requests
                    WHERE session_id IN ({placeholders})
                      AND is_tracker = 1
                      AND result_status = 'complete'
                """
            else:
                req_sql = f"""
                    SELECT
                        id AS request_row_id,
                        session_id,
                        request_id,
                        request_url,
                        frame_main,
                        frame_url,
                        frame_origin,
                        request_type,
                        parent_id,
                        etld_request_url_rel,
                        result_status
                    FROM requests
                    WHERE session_id IN ({placeholders})
                      AND is_tracker = 1
                """
            cur.execute(req_sql, session_ids)
            for r in cur.fetchall():
                requests_by_session[r["session_id"]].append(r)

            # ---- html elements ----
            html_sql = f"""
                SELECT
                    id AS html_row_id,
                    session_id,
                    element_id,
                    tag,
                    src,
                    attrs_json,
                    parent_id,
                    parent_type
                FROM html_elements
                WHERE session_id IN ({placeholders})
                  AND element_id IS NOT NULL
            """
            cur.execute(html_sql, session_ids)
            for r in cur.fetchall():
                sid = r["session_id"]
                eid = r["element_id"]
                r["src"] = norm_src(r.get("src", ""))

                html_by_session[sid][eid] = r
                if r["src"]:
                    html_src_index_by_session[sid][r["src"]].append(eid)

            # ---- scripts ----
            scripts_sql = f"""
                SELECT
                    id AS script_row_id,
                    session_id,
                    script_id,
                    script_type,
                    script_src,
                    executor_id,
                    executor_tag,
                    executor_attrs,
                    frame_id,
                    frame_main,
                    frame_url,
                    frame_origin,
                    etld_script_src_rel
                FROM scripts
                WHERE session_id IN ({placeholders})
                  AND script_id IS NOT NULL
            """
            cur.execute(scripts_sql, session_ids)
            for r in cur.fetchall():
                sid = r["session_id"]
                script_id = r["script_id"]
                r["script_src"] = norm_src(r.get("script_src", ""))

                scripts_by_session[sid][script_id] = r
                
                if r["script_src"]:
                    scripts_src_index_by_session[sid][r["script_src"]].append(script_id)

        return requests_by_session, html_by_session, html_src_index_by_session, scripts_by_session, scripts_src_index_by_session
    finally:
        conn.close()


def build_html_chain_for_request(sid, request_row, html_by_session, scripts_by_session):


    start_id = request_row.get("parent_id")
    if not start_id:
        return [], ""

    html_map = html_by_session.get(sid, {})
    script_map = scripts_by_session.get(sid, {})

    chain_tail_to_top = []
    cur_id = start_id
    seen = set()

    while cur_id and cur_id not in seen:
        seen.add(cur_id)

        # 1) HTML element node
        h = html_map.get(cur_id)
        if h:
            chain_tail_to_top.append({
                "kind": "html",
                "html_row_id": h.get("html_row_id"),
                "element_id": h.get("element_id"),
                "tag": h.get("tag"),
                "src": h.get("src", ""),
                "attrs_json": h.get("attrs_json"),
                "parent_id": h.get("parent_id"),
                "parent_type": h.get("parent_type"),
            })

            nxt = h.get("parent_id")
            cur_id = nxt if nxt else ""
            continue

        # 2) Script node fallback
        s = script_map.get(cur_id)
        if s:
            chain_tail_to_top.append({
                "kind": "script",
                "script_row_id": s.get("script_row_id"),
                "script_id": s.get("script_id"),
                "script_type": s.get("script_type"),
                "script_src": norm_src(s.get("script_src", "")),
                "executor_attrs": s.get("executor_attrs", ""),
                'etld_script_src_rel': s.get("etld_script_src_rel", ""),
                'frame_id': s.get("frame_id", ""),
                'frame_url': s.get("frame_url", ""),
                'frame_origin': s.get("frame_origin", ""),
                "executor_id": s.get("executor_id"),
                "executor_tag": s.get("executor_tag"),
            })

            nxt = s.get("executor_id")
            cur_id = nxt if nxt else ""
            continue

        # 3) not found anywhere -> stop
        break

    chain_top_to_tail = list(reversed(chain_tail_to_top))
    tail_id = start_id
    return chain_top_to_tail, tail_id


def try_match_chain_in_other_location(
    src_chain_top_to_tail,
    sid_dst,
    html_by_session,
    html_src_index_by_session,
    scripts_by_session,
    scripts_src_index_by_session,
):
    if not src_chain_top_to_tail:
        return {"found": False, "reason": "no_src_chain"}

    dst_html_map = html_by_session.get(sid_dst, {})
    dst_html_src_index = html_src_index_by_session.get(sid_dst, {})

    dst_script_map = scripts_by_session.get(sid_dst, {})
    dst_script_src_index = scripts_src_index_by_session.get(sid_dst, {})

    top = src_chain_top_to_tail[0]
    top_kind = top.get("kind")

    is_top_anchor_the_top_parser = False

    if top_kind == "script":
        top_anchor = norm_src(top.get("script_src", ""))
        top_anchor_key = "script_src"

        if top['script_id'] in ['n47', 'n48'] or top['executor_id'] in ['n47', 'n48']:
            is_top_anchor_the_top_parser = True 

    else:
        top_anchor = norm_src(top.get("src", ""))
        top_anchor_key = "src"

        if top['element_id'] in ['n47', 'n48'] or top['parent_id'] in ['n47', 'n48']:
            is_top_anchor_the_top_parser = True 


    top_has_anchor = bool(top_anchor)
    saw_any_anchor_anywhere = False


    # Scan tail -> top, stop at first match
    for idx in range(len(src_chain_top_to_tail) - 1, -1, -1):
        el = src_chain_top_to_tail[idx]
        kind = el.get("kind")

        if kind == "script":
            anchor = norm_src(el.get("script_src", ""))
            anchor_key = "script_src"
        else:
            anchor = norm_src(el.get("src", ""))
            anchor_key = "src"

        if not anchor:
            continue

        saw_any_anchor_anywhere = True

        # ---- Match HTML by src ----
        if kind != "script":
            candidates = dst_html_src_index.get(anchor, [])
            if not candidates:
                continue

            matched_eid = sorted(candidates)[0]
            matched_row = dst_html_map.get(matched_eid, {})

            matched_element = {
                "element_id": matched_row.get("element_id", matched_eid),
                "parent_type": matched_row.get("parent_type"),
                "tag": matched_row.get("tag"),
                "src": matched_row.get("src", ""),
                "parent_id": matched_row.get("parent_id"),
            }

            # ancestor chain context (HTML)
            ancestor_tail_to_top = []
            cur_eid = matched_eid
            seen = set()
            while cur_eid and cur_eid not in seen:
                seen.add(cur_eid)
                row = dst_html_map.get(cur_eid)
                if not row:
                    break
                ancestor_tail_to_top.append({
                    "element_id": row.get("element_id"),
                    "parent_type": row.get("parent_type"),
                    "tag": row.get("tag"),
                    "src": row.get("src", ""),
                })
                nxt = row.get("parent_id")
                cur_eid = nxt if nxt else ""

            return {
                "found": True,
                "matched_kind": "html",
                "matched_on": anchor_key,
                "matched_value": anchor,
                "matched_element_id": matched_eid,
                "matched_element": matched_element,
                "dst_ancestor_chain_top_to_matched": list(reversed(ancestor_tail_to_top)),
                "matched_at_src_chain_index": idx,
            }

        # ---- Match SCRIPT by script_src ----
        else:
            candidates = dst_script_src_index.get(anchor, [])
            if not candidates:
                continue

            matched_sid = sorted(candidates)[0]
            matched_row = dst_script_map.get(matched_sid, {})

            matched_script = {
                "script_id": matched_row.get("script_id", matched_sid),
                "script_type": matched_row.get("script_type"),
                "script_src": norm_src(matched_row.get("script_src", "")),
                "executor_id": matched_row.get("executor_id"),
                "executor_tag": matched_row.get("executor_tag"),
                "frame_id": matched_row.get("frame_id"),
                "frame_url": matched_row.get("frame_url"),
                "frame_origin": matched_row.get("frame_origin"),
            }

            # executor chain context (script->script only, as in your current code)
            ancestor_tail_to_top = []
            cur_id = matched_sid
            seen = set()
            while cur_id and cur_id not in seen:
                seen.add(cur_id)
                row = dst_script_map.get(cur_id)
                if not row:
                    break
                ancestor_tail_to_top.append({
                    "script_id": row.get("script_id", cur_id),
                    "script_type": row.get("script_type"),
                    "script_src": norm_src(row.get("script_src", "")),
                    "executor_id": row.get("executor_id"),
                    "executor_tag": row.get("executor_tag"),
                })
                nxt = row.get("executor_id")
                cur_id = nxt if (nxt and nxt in dst_script_map) else ""

            return {
                "found": True,
                "matched_kind": "script",
                "matched_on": anchor_key,
                "matched_value": anchor,
                "matched_script_id": matched_sid,
                "matched_script": matched_script,
                "dst_script_executor_chain_top_to_matched": list(reversed(ancestor_tail_to_top)),
                "matched_at_src_chain_index": idx,
            }

    # inline if:
    #   (1) no anchor anywhere (inline-only), OR
    #   (2) top element has no anchor (even if anchors exist lower down but didn't match)
    if ((not saw_any_anchor_anywhere) or (not top_has_anchor)) and is_top_anchor_the_top_parser:
        return {
            "found": False,
            "reason": "inline_chain_no_src",
            "top_has_anchor": top_has_anchor,
            "top_anchor_key": top_anchor_key,
            "top_anchor": top_anchor,
        }

    # otherwise: top has anchor, but it wasn't found in dst -> not_found
    return {
        "found": False,
        "reason": "no_src_match",
        "top_has_anchor": top_has_anchor,
        "top_anchor_key": top_anchor_key,
        "top_anchor": top_anchor,
    }


def analyze_direction(loc1, loc2, sessions_by_site_loc,
                      requests_by_session, html_by_session, html_src_index_by_session, scripts_by_session, scripts_src_index_by_session,
                      details_out_fh):
    sites = eligible_sites_for_pair(sessions_by_site_loc, loc1, loc2)

    stats = Counter()
    stats["comparable_urls"] = len(sites)
    stats["comparable_sites"] = len(set([item[0] for item in sites]))
    stats["sites_with_tracking_in_src_only"] = []

    examples = []

    for (etld, page_url) in sites:
        sid1 = pick_one_session(sessions_by_site_loc, (etld, page_url), loc1)
        sid2 = pick_one_session(sessions_by_site_loc, (etld, page_url), loc2)
        if not sid1 or not sid2:
            continue

        reqs1 = requests_by_session.get(sid1, [])
        reqs2 = requests_by_session.get(sid2, [])

        reqs1_with_t = []
        set1 = set()
        for r in reqs1:
            t = tracker_etld_plus1_from_request_row(r)
            if not t:
                continue
            rr = dict(r)                 
            rr["_tracker_etld_plus1"] = t
            reqs1_with_t.append(rr)
            set1.add(t)

        set2 = set()
        for r in reqs2:
            t = tracker_etld_plus1_from_request_row(r)
            if t:
                set2.add(t)

        unique_tracker_etlds = set1 - set2
        if not unique_tracker_etlds:
            continue

        stats["urls_with_tracking_in_src_only"] += 1
        stats["sites_with_tracking_in_src_only"].append(etld)


        # Filter using the already-computed _tracker_etld_plus1 (no recomputation)
        unique_reqs = [r for r in reqs1_with_t if r["_tracker_etld_plus1"] in unique_tracker_etlds]
        stats["total_tracking_requests_in_src_only"] += len(unique_reqs)

        for r in unique_reqs:

            chain_top_to_tail, _ = build_html_chain_for_request(sid1, r, html_by_session, scripts_by_session)
            
            if chain_top_to_tail:
                stats["requests_with_chain"] += 1

                match_info = try_match_chain_in_other_location(
                    chain_top_to_tail,
                    sid2,
                    html_by_session,
                    html_src_index_by_session,
                    scripts_by_session,
                    scripts_src_index_by_session,
                )

                if match_info.get("found"):
                    stats["dst_chain_match_found"] += 1
                else:
                    reason = match_info.get("reason")
                    if reason == "inline_chain_no_src":
                        stats["dst_chain_match_inline"] += 1
                    else:
                        stats["dst_chain_match_not_found"] += 1

            else:
                # No chain: do NOT count toward dst_chain_* buckets
                stats["requests_without_chain"] += 1
                match_info = {"found": False, "reason": "no_src_chain"}

            tracker_etld_plus1 = r["_tracker_etld_plus1"]

            rec = {
                "direction": {"src_loc": loc1, "dst_loc": loc2},
                "site": {"etld": etld, "page_url": page_url, "category": CATEGORY},
                "sessions": {
                    "src": {"session_id": sid1, "location": loc1},
                    "dst": {"session_id": sid2, "location": loc2},
                },

                "unique_tracking_key": {"tracker_etld_plus1": tracker_etld_plus1},

                "request": {
                    "request_row_id": r.get("request_row_id"),
                    "request_id": r.get("request_id"),
                    "request_type": r.get("request_type"),
                    "request_url": r.get("request_url"),
                    "etld_request_url_rel": r.get("etld_request_url_rel"),
                    "result_status": r.get("result_status"),
                    "frame_main": r.get("frame_main"),
                    "frame_origin": r.get("frame_origin"),
                    "frame_url": r.get("frame_url"),
                    "parent_id": r.get("parent_id"),
                },

                "html_chain_src_top_to_tail": chain_top_to_tail,
                "dst_match_attempt": match_info,
            }

            details_out_fh.write(json.dumps(rec, ensure_ascii=False) + "\n")

            examples.append({
                "etld": etld,
                "page_url": page_url,
                "src_session_id": sid1,
                "dst_session_id": sid2,
                "tracker_etld_plus1": tracker_etld_plus1,
                "request_row_id": r["request_row_id"],
                "request_url": r.get("request_url"),
                "has_chain": bool(chain_top_to_tail),
                "dst_match_found": bool(match_info.get("found")),
                "matched_kind": match_info.get("matched_kind", ""),
                "matched_on": match_info.get("matched_on", ""),
                "matched_value": match_info.get("matched_value", ""),

            })


    stats['sites_with_tracking_in_src_only'] = len(set(stats['sites_with_tracking_in_src_only']))

    summary = {
        "src_loc": loc1, 
        "dst_loc": loc2,
        "category": CATEGORY,
        "complete_only": TRACKER_ONLY_COMPLETE,
        "stats": dict(stats),
        "examples": examples,
    }
    return summary


def _pair_paths(loc1, loc2):
    safe1 = loc1.replace(" ", "_")
    safe2 = loc2.replace(" ", "_")
    summary_path = f"{OUT_BASE}/{safe1}_TO_{safe2}_summary.json"
    details_path = f"{OUT_BASE}/{safe1}_TO_{safe2}_details.jsonl"
    return summary_path, details_path


def main():
    sessions = load_sessions()
    sessions_by_site_loc = build_sessions_index(sessions)

    all_session_ids = sorted({r["id"] for r in sessions})

    requests_by_session, html_by_session, html_src_index_by_session, scripts_by_session, scripts_src_index_by_session = load_requests_html_scripts_for_sessions(all_session_ids)

    locs = list(TARGET_LOCATIONS)

    for loc1 in locs:
        for loc2 in locs:
            if loc1 == loc2:
                continue

            summary_path, details_path = _pair_paths(loc1, loc2)

            print(f"[PAIR] {loc1} -> {loc2}")
            print(f"  details: {details_path}")
            print(f"  summary: {summary_path}")

            # write details for this pair
            with open(details_path, "w", encoding="utf-8") as details_fh:
                summary = analyze_direction(
                    loc1, loc2,
                    sessions_by_site_loc,
                    requests_by_session,
                    html_by_session,
                    html_src_index_by_session,
                    scripts_by_session,
                    scripts_src_index_by_session,
                    details_fh,
                )

            # write summary for this pair
            out = {
                "summary": summary
            }
            with open(summary_path, "w", encoding="utf-8") as fh:
                json.dump(out, fh, ensure_ascii=False, indent=2)

    print("[OK] wrote per-pair summary + details files")


if __name__ == "__main__":
    main()
