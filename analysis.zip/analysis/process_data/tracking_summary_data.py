import os
import csv
import pymysql
import tldextract
from urllib.parse import urlparse, urlunparse
from tqdm import tqdm
from collections import defaultdict


db_params = {
    "host": "localhost",
    "user": "cursor",
    "password": "whaTaShame",
    "db": "crawl_analysis_new",
    "cursorclass": pymysql.cursors.DictCursor,
}


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TRACKING_DIR = os.path.join(BASE_DIR, "processed_data", "tracking")
os.makedirs(TRACKING_DIR, exist_ok=True)

third_party_tracking_file = os.path.join(
    TRACKING_DIR, "third_party_tracking_requests.csv"
)
first_party_tracking_file = os.path.join(
    TRACKING_DIR, "first_party_tracking_requests.csv"
)
sites_tracking_summary_file = os.path.join(
    TRACKING_DIR, "sites_tracking_summary.csv"
)


def get_hostname_and_registered_domain(url: str):
    """
    Returns (hostname_without_port, registered_domain) for a URL.
    - hostname_without_port: e.g., 'sub.example.com'
    - registered_domain: e.g., 'example.com' (eTLD+1)
    """
    if not url:
        return None, None

    try:
        parsed = urlparse(url)
    except Exception:
        return None, None

    host = parsed.hostname
    if not host:
        return None, None

    ext = tldextract.extract(host)
    reg_domain = ext.top_domain_under_public_suffix or host
    return host, reg_domain


def classify_request(session_reg_domain: str, request_url: str):
    """
    Classify a tracking request as first-party or third-party relative to the session.
    Returns:
      (is_first_party: bool,
       is_third_party: bool,
       req_reg_domain: str or None,
       req_origin_host: str or None)
    """
    req_origin_host, req_reg_domain = get_hostname_and_registered_domain(request_url)

    if not session_reg_domain or not req_reg_domain:
        # If we can't parse things properly, treat as third-party by default.
        return False, True, req_reg_domain, req_origin_host

    if req_reg_domain == session_reg_domain:
        return True, False, req_reg_domain, req_origin_host
    else:
        return False, True, req_reg_domain, req_origin_host


def load_sessions_to_treat(conn):

    sql = """
        SELECT
            id,
            category,
            location,
            etld,
            url
        FROM crawl_sessions
        WHERE
            etld_url_rel <> 'cross-site'
            AND location NOT LIKE '%VPN'
            AND category NOT LIKE '%validation'
            AND (is_cloudflare IS NULL OR is_cloudflare = 0)
            AND is_user_identifiers IS NOT NULL
    """
    with conn.cursor() as cursor:
        cursor.execute(sql)
        rows = cursor.fetchall()

    if not rows:
        print("[!] No sessions found ")
        return []

    global_rows = []
    other_rows = []

    for r in rows:
        if (r.get("category") or "").strip().lower() == "global":
            global_rows.append(r)
        else:
            other_rows.append(r)

    # If no global rows, return the rest
    if not global_rows:
        print("[!] No global rows ")
        return other_rows

    # All locations present among GLOBAL rows (after base filters)
    all_locs_global = set(r.get("location") for r in global_rows if r.get("location"))
    if not all_locs_global:
        print("[!] No locations found")
        return other_rows + global_rows

    # Map etld -> set(locations)
    etld_to_locs = defaultdict(set)
    for r in global_rows:
        etld = r.get("etld")
        loc = r.get("location")
        if not etld or not loc:
            continue
        etld_to_locs[etld].add(loc)

    # Keep only eTLDs that appear in ALL global locations
    eligible_etlds = {e for e, locs in etld_to_locs.items() if locs == all_locs_global}

    # Keep ALL global rows whose eTLD is eligible (all page URLs for that eTLD)
    filtered_global = [r for r in global_rows if r.get("etld") in eligible_etlds]

    return other_rows + filtered_global

def load_tracking_requests_for_session(conn, session_id):
    """
    Load all tracking requests for a given session_id.
    Only:
      - is_tracker = 1
    Returns list of dicts with at least: request_url
    """
    sql = """
        SELECT
            request_url
        FROM requests
        WHERE
            session_id = %s
            AND is_tracker = 1
    """
#    AND result_status = 'complete'

    with conn.cursor() as cursor:
        cursor.execute(sql, (session_id,))
        rows = cursor.fetchall()
    return rows



def treat_session(session, conn):
    """
    Given a session row and the DB connection:
      - load its tracking requests
      - classify them into first-party / third-party
      - build:
          * summary row for this session
          * list of first-party request rows for CSV
          * list of third-party request rows for CSV
    """
    session_id = session["id"]
    category = session["category"]
    location = session["location"]
    etld = session["etld"]
    url = session["url"]

    # Session eTLD+1: use etld column if present, otherwise derive from URL
    if etld:
        session_reg_domain = etld
    else:
        _, session_reg_domain = get_hostname_and_registered_domain(url)

    # Load tracking requests for this session
    tracking_requests = load_tracking_requests_for_session(conn, session_id)

    has_first_party = False
    has_third_party = False
    third_party_domains = set()
    third_party_origins = set()

    first_party_rows = []
    third_party_rows = []

    for r in tracking_requests:
        request_url = r["request_url"]
        if not request_url:
            continue

        is_fp, is_tp, req_reg_domain, req_origin_host = classify_request(
            session_reg_domain, request_url
        )

        base_row = {
            "category": category,
            "location": location,
            "etld": etld,
            "url": url,
            "session_id": session_id,
            "tracking_request": request_url,
            "tracking_request_domain": req_reg_domain or "",
            "tracking_request_origin": req_origin_host or "",
        }

        if is_fp:
            has_first_party = True
            first_party_rows.append(base_row)

        if is_tp:
            has_third_party = True
            third_party_rows.append(base_row)
            if req_reg_domain:
                third_party_domains.add(req_reg_domain)
            if req_origin_host:
                third_party_origins.add(req_origin_host)

    is_tracking = has_first_party or has_third_party

    summary_row = {
        "category": category,
        "location": location,
        "etld": etld,
        "url": url,
        "session_id": session_id,
        "is_first_party_tracking": int(has_first_party),
        "is_third_party_tracking": int(has_third_party),
        "is_tracking": int(is_tracking),
        "distinct_third_party_tracking_domains": ";".join(
            sorted(third_party_domains)
        ),
        "distinct_third_party_tracking_origins": ";".join(
            sorted(third_party_origins)
        ),
    }

    return summary_row, first_party_rows, third_party_rows

def main():
    conn = pymysql.connect(**db_params)

    try:
        print("[*] Loading sessions to process...")
        sessions = load_sessions_to_treat(conn)
        total_sessions = len(sessions)
        print(f"[*] Total sessions to process: {total_sessions}")

        if total_sessions == 0:
            print("[!] No sessions match the filters. Exiting.")
            return

        all_summary_rows = []
        all_first_party_rows = []
        all_third_party_rows = []

        print("[*] Processing sessions...")
        for session in tqdm(sessions, desc="Sessions", unit="session"):
            summary_row, first_rows, third_rows = treat_session(session, conn)
            all_summary_rows.append(summary_row)
            all_first_party_rows.extend(first_rows)
            all_third_party_rows.extend(third_rows)

        print("[*] Writing CSV files...")

        # Summary
        with open(sites_tracking_summary_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "category",
                    "location",
                    "etld",
                    "url",
                    "session_id",
                    "is_first_party_tracking",
                    "is_third_party_tracking",
                    "is_tracking",
                    "distinct_third_party_tracking_domains",
                    "distinct_third_party_tracking_origins",
                ],
            )
            writer.writeheader()
            writer.writerows(all_summary_rows)

        # First-party tracking requests
        with open(first_party_tracking_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "category",
                    "location",
                    "etld",
                    "url",
                    "session_id",
                    "tracking_request",
                    "tracking_request_domain",
                    "tracking_request_origin",
                ],
            )
            writer.writeheader()
            writer.writerows(all_first_party_rows)

        # Third-party tracking requests
        with open(third_party_tracking_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "category",
                    "location",
                    "etld",
                    "url",
                    "session_id",
                    "tracking_request",
                    "tracking_request_domain",
                    "tracking_request_origin",
                ],
            )
            writer.writeheader()
            writer.writerows(all_third_party_rows)

        print("[*] Done.")
        print(f"    Summary:        {sites_tracking_summary_file}")
        print(f"    First-party:    {first_party_tracking_file}")
        print(f"    Third-party:    {third_party_tracking_file}")

    finally:
        conn.close()
        print("[*] DB connection closed.")


if __name__ == "__main__":
    main()
