import pymysql
import pandas as pd
import json
from urllib.parse import urlparse
import os
import tldextract
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor

db_params = {
    "host": "localhost",
    "user": "cursor",
    "password": "whaTaShame",
    "db": "crawl_analysis_new",
    "cursorclass": pymysql.cursors.DictCursor
}

fingerprinting_file = 'data/fingerprinting/all_fingerprinting.csv'
first_party_file = 'data/fingerprinting/first_party_fingerprinting.csv'
third_party_file = 'data/fingerprinting/third_party_fingerprinting.csv'
third_party_file = 'data/fingerprinting/third_party_fingerprinting.csv'
fingerprinting_summary_file = 'data/fingerprinting/sites_fingerprinting_summary.csv'
D1_comparison_file = 'data/fingerprinting/D1_comparison.json'

def normalize_url(u):
    try:
        parsed = urlparse(u)
        return urlunparse((parsed.scheme, parsed.netloc, parsed.path, '', '', ''))
    except Exception:
        return u

def is_valid_url(url):
    return url.startswith(('http://', 'https://'))


def load_crawl_sessions_with_fingerprinting(conn_params):
    sql = """
        SELECT id, etld, url, category, location, fingerprinting, is_fingerprinting
        FROM crawl_sessions where 
          category NOT LIKE '%validation'
          AND location NOT LIKE '%VPN'
          AND etld_url_rel <> 'cross-site'
          AND (is_cloudflare IS NULL OR is_cloudflare = 0)
    """
    conn = pymysql.connect(**conn_params)
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            rows = cursor.fetchall()
            df = pd.DataFrame(rows)
    finally:
        conn.close()
    return df



def fetch_scripts_by_etld(etld, conn_params):
    sql = """
        SELECT 
            script.id, 
            script.script_src,
            script.script_hash, 
            script.etld_script_src_rel,
            session.url AS session_url, 
            session.id AS session_id, 
            session.location
        FROM scripts script
        JOIN crawl_sessions session ON script.session_id = session.id
        WHERE session.etld = %s
          AND session.category NOT LIKE '%%validation'
          AND session.location NOT LIKE '%%VPN'
          AND session.etld_url_rel <> 'cross-site'
    """

    params = [etld]

    conn = pymysql.connect(**conn_params)
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute(sql, tuple(params))
            rows = cursor.fetchall()
            df = pd.DataFrame(rows)
    finally:
        conn.close()

    if df.empty:
        cols = ['id', 'script_src', 'script_hash', 'etld_script_src_rel', 'session_url', 'normalized_url', 'session_id', 'location']
        df = pd.DataFrame(columns=cols)

        return df

    df['normalized_url'] = df['session_url'].apply(normalize_url)
    return df


def expand_fingerprinting(df_sessions: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in df_sessions.iterrows():
        fp_json = row.get('fingerprinting')
        if not fp_json:
            continue
        if isinstance(fp_json, str):
            fp_json = json.loads(fp_json)

        for fp_type, fp_entries in fp_json.items():
            if not fp_entries:
                continue

            for entry in fp_entries:
                entry_row = {
                    'etld': row['etld'],
                    'current_url': row['url'],
                    'location': row['location'],
                    'category': row['category'],
                    'fingerprinting_type': fp_type,
                }
                entry_row.update(entry)

                # Handle matched_scripts: copy script_* fields to caller_*
                if fp_type == 'matched_scripts':
                    entry_row['caller_url'] = entry_row.get('script_src', '')
                    entry_row['caller_type'] = entry_row.get('script_type', '')
                    entry_row['caller_id'] = entry_row.get('script_id', '')
                    entry_row['caller_hash'] = entry_row.get('script_hash', '')

                caller_url = entry_row['caller_url']
                
                if caller_url and is_valid_url(caller_url):
                    
                    parsed = tldextract.extract(caller_url)

                    if parsed.suffix:
                        origin = '.'.join([parsed.subdomain, parsed.domain, parsed.suffix]).strip('.')
                        domain = parsed.domain + '.' + parsed.suffix
                    else:
                        origin = parsed.domain
                        domain = parsed.domain

                    entry_row['caller_origin'] = origin
                    entry_row['caller_domain'] = domain

                else:
                    entry_row['caller_origin'] = ''
                    entry_row['caller_domain'] = ''

                rows.append(entry_row)



    fp_df = pd.DataFrame(rows)

    # Drop columns we no longer need
    drop_cols = ['caller_type', 'executor_id', 'executor_tag', 'executor_attrs',
                 'script_id', 'match_type', 'script_src', 'script_hash', 'script_type']
    fp_df = fp_df.drop(columns=[c for c in drop_cols if c in fp_df.columns], errors='ignore')

    # Remove duplicates
    fp_df = fp_df.drop_duplicates(ignore_index=True)

    fp_df['normalized_url'] = fp_df['current_url'].apply(normalize_url)

    return fp_df


def is_first_party(caller_url, current_url):
    # Ensure both URLs are strings

    caller_url = caller_url if isinstance(caller_url, str) else ''
    current_url = current_url if isinstance(current_url, str) else ''
    
    if caller_url == '' or current_url == '': #if its empty, than its first party 
        return True

    caller_domain = tldextract.extract(caller_url).domain + '.' + tldextract.extract(caller_url).suffix
    current_domain = tldextract.extract(current_url).domain + '.' + tldextract.extract(current_url).suffix

    return caller_domain == current_domain

    
def split_first_third_party(fp_df):
    # Determine first vs third party based on caller_url vs current_url

    fp_df['is_first_party'] = fp_df.apply(lambda r: is_first_party(r.get('caller_url',''), r['current_url']), axis=1)
    first_party_fp = fp_df[fp_df['is_first_party']].copy()
    third_party_fp = fp_df[~fp_df['is_first_party']].copy()
    return first_party_fp, third_party_fp


def build_fingerprinting_summary(df_sessions, fp_df, first_fp, third_fp):
    summary_rows = []

    sessions = df_sessions[['category', 'location', 'etld']].drop_duplicates()

    for row in tqdm(sessions.itertuples(index=False), total=len(sessions), desc="Building fingerprinting summary"):
        category = row.category
        location = row.location
        etld = row.etld

        # Filter fingerprinting instances
        fp_rows = fp_df[
            (fp_df['category'] == category) &
            (fp_df['location'] == location) &
            (fp_df['etld'] == etld)
        ]
        fp_first_rows = first_fp[
            (first_fp['category'] == category) &
            (first_fp['location'] == location) &
            (first_fp['etld'] == etld)
        ]
        fp_third_rows = third_fp[
            (third_fp['category'] == category) &
            (third_fp['location'] == location) &
            (third_fp['etld'] == etld)
        ]

        # Compute distinct third-party domains (ETLD+1) and origins
        distinct_third_party_domains = set(fp_third_rows['caller_domain'].dropna().unique())
        distinct_third_party_origins = set(fp_third_rows['caller_origin'].dropna().unique())

        type_counts = fp_rows['fingerprinting_type'].value_counts().to_dict() if not fp_rows.empty else {}
        type_flags = {f'is_{t}_fingerprinting': t in type_counts for t in type_counts}

        summary_row = {
            'category': category,
            'location': location,
            'etld': etld,
            'is_fingerprinting': not fp_rows.empty,
            'nb_fingerprinting_cases': len(fp_rows),
            'distinct_fingerprinting_callers': fp_rows['caller_url'].to_list(),
            'distinct_third_party_fingerprinting_caller_domains': list(distinct_third_party_domains),
            'distinct_third_party_fingerprinting_caller_origins': list(distinct_third_party_origins),
            'is_first_party_fingerprinting': not fp_first_rows.empty,
            'is_third_party_fingerprinting': not fp_third_rows.empty
        }

        # Add type-specific flags and counts
        summary_row.update(type_flags)

        summary_rows.append(summary_row)

    summary_df = pd.DataFrame(summary_rows)

    # Save summary
    os.makedirs(os.path.dirname(fingerprinting_summary_file), exist_ok=True)
    summary_df.to_csv(fingerprinting_summary_file, index=False)
    print(f"Saved fingerprinting summary to {fingerprinting_summary_file}")

    return summary_df



def process_etld_url_pair_fingerprinting(args):
    etld, norm_url, df, fp_df, first_fp, third_fp, db_params, locations = args
    key_dict = {}

    # --- Fetch all scripts for this ETLD/URL ---
    scripts_etld = fetch_scripts_by_etld(etld, db_params)
    scripts_url = scripts_etld[scripts_etld['normalized_url'] == norm_url]

    for loc in locations:
        # --- Check if this location has the URL ---
        has_loc_entry = not df[
            (df['etld'] == etld) &
            (df['normalized_url'] == norm_url) &
            (df['location'] == loc)
        ].empty
        key_dict[f'is_loc_{loc}'] = has_loc_entry

        scripts_loc = scripts_url[scripts_url['location'] == loc]

        first_party_scripts = scripts_loc[scripts_loc['etld_script_src_rel'] != 'cross-site']
        third_party_scripts = scripts_loc[scripts_loc['etld_script_src_rel'] == 'cross-site']

        key_dict[f'all_first_party_scripts_{loc}'] = first_party_scripts[['script_src','script_hash']].drop_duplicates().to_dict('records')
        key_dict[f'all_third_party_scripts_{loc}'] = third_party_scripts[['script_src','script_hash']].drop_duplicates().to_dict('records')

        # --- Fingerprinting cases separately ---
        fp_loc = fp_df[(fp_df['etld'] == etld) & (fp_df['normalized_url'] == norm_url) & (fp_df['location'] == loc)]
        fp_first_loc = first_fp[(first_fp['etld'] == etld) & (first_fp['normalized_url'] == norm_url) & (first_fp['location'] == loc)]
        fp_third_loc = third_fp[(third_fp['etld'] == etld) & (third_fp['normalized_url'] == norm_url) & (third_fp['location'] == loc)]

        key_dict[f'is_fingerprinting_{loc}'] = not fp_loc.empty
        key_dict[f'is_first_party_fingerprinting_{loc}'] = not fp_first_loc.empty
        key_dict[f'is_third_party_fingerprinting_{loc}'] = not fp_third_loc.empty

        key_dict[f'fingerprinter_domains_{loc}'] = fp_loc['caller_domain'].dropna().unique().tolist()
        key_dict[f'fingerprinter_origins_{loc}'] = fp_loc['caller_origin'].dropna().unique().tolist()
        key_dict[f'fingerprinter_hashes_{loc}'] = fp_loc['caller_hash'].dropna().unique().tolist()

    return (f"{etld}||{norm_url}", key_dict)
    

def build_fingerprinting_comparison_for_D1_bucket(db_params, df, fp_df, first_fp, third_fp, max_workers=8):
    comparison_dict = {}

    # Load rows for global bucket
    df = df[df['category'] == 'global']
    df['normalized_url'] = df['url'].apply(normalize_url)


    location_counts = df.groupby(['etld', 'normalized_url'])['location'].nunique()
    multi_loc_pairs = location_counts[location_counts >= 2].index
    etlds_urls = pd.DataFrame(list(multi_loc_pairs), columns=['etld', 'normalized_url']).drop_duplicates()


    locations = df['location'].unique()

    args_list = [(row['etld'], row['normalized_url'], df, fp_df, first_fp, third_fp, db_params, locations) for _, row in etlds_urls.iterrows()]

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        for key, key_dict in tqdm(executor.map(process_etld_url_pair_fingerprinting, args_list), total=len(args_list), desc="Processing pairs"):
            comparison_dict[key] = key_dict

    # Save JSON
    os.makedirs(os.path.dirname(D1_comparison_file) or '.', exist_ok=True)
    with open(D1_comparison_file, 'w', encoding='utf-8') as f:
        json.dump(comparison_dict, f, indent=2, ensure_ascii=False)

    print(f"Fingerprinting comparison saved to {D1_comparison_file}")




if __name__ == "__main__":
    df_sessions = load_crawl_sessions_with_fingerprinting(db_params)
    print(f"Loaded {len(df_sessions)} fingerprinting crawl sessions")

    fp_df = expand_fingerprinting(df_sessions)
    print(f"Expanded to {len(fp_df)} fingerprinting entries")

    os.makedirs(os.path.dirname(fingerprinting_file), exist_ok=True)
    fp_df.to_csv(fingerprinting_file, index=False)
    print(f"Saved all fingerprinting entries to {fingerprinting_file}")

    first_fp, third_fp = split_first_third_party(fp_df)

    os.makedirs(os.path.dirname(first_party_file), exist_ok=True)
    first_fp.to_csv(first_party_file, index=False)
    print(f"Saved first-party fingerprinting to {first_party_file}")

    os.makedirs(os.path.dirname(third_party_file), exist_ok=True)
    third_fp.to_csv(third_party_file, index=False)
    print(f"Saved third-party fingerprinting to {third_party_file}")

    build_fingerprinting_summary(df_sessions, fp_df, first_fp, third_fp)


#    build_fingerprinting_comparison_for_D1_bucket(db_params, df_sessions, fp_df, first_fp, third_fp, 32)