import pymysql
import pandas as pd
import tldextract
from urllib.parse import urlparse
import os

# MySQL connection parameters
db_params = {
    "host": "localhost",
    "user": "cursor",
    "password": "whaTaShame",
    "db": "crawl_analysis_new",
    "cursorclass": pymysql.cursors.DictCursor
}

output_csv = "data/requests_cname_mismatch.csv"
os.makedirs(os.path.dirname(output_csv), exist_ok=True)

# Function to extract eTLD+1
def get_etld_plus_one(url):
    if not url or pd.isna(url) or url.strip() == "":
        return ""
    ext = tldextract.extract(url)
    if not ext.suffix:
        return ext.domain
    return ext.domain + "." + ext.suffix

# Load requests table
def load_requests(conn_params):
    sql = """
        SELECT id, session_id, request_url, cname_final_url, etld_request_url_rel
        FROM requests
        WHERE request_url IS NOT NULL AND cname_final_url IS NOT NULL
    """
    conn = pymysql.connect(**conn_params)
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute(sql)
            rows = cursor.fetchall()
            df = pd.DataFrame(rows)
    finally:
        conn.close()
    return df

# Main
df = load_requests(db_params)

# Extract eTLD+1s
df['request_etld'] = df['request_url'].apply(get_etld_plus_one)
df['cname_etld'] = df['cname_final_url'].apply(get_etld_plus_one)

# Filter rows where they differ
mismatch_df = df[df['request_etld'] != df['cname_etld']]

# Save CSV
mismatch_df.to_csv(output_csv, index=False)
print(f"Saved {len(mismatch_df)} rows to {output_csv}")
