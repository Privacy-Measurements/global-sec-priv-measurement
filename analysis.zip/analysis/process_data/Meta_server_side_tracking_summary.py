import json
import os
import csv
import pymysql
from urllib.parse import urlparse
from collections import defaultdict
from config import db_params
from tqdm import tqdm  


DISTINCT_KEYS = []
DISTINCT_DOMAINS = [] 

FACEBOOK_HOST_KEYWORDS = [
    "facebook.com",
    "facebook.net",
    "fbcdn.net",
    "connect.facebook.net",
    "www.facebook.com",
]

FACEBOOK_KEY_KEYWORDS = [
    "_fbp",
    "_fbc",
    "fbp",
    "fbc",
    "facebook",
    "fb_",
]


def is_facebook_identifier(entry: dict) -> bool:
    """
    Decide whether a user_identifier entry is Facebook-related.
    """

    key = (entry.get("key") or "").lower()
    caller_url = (entry.get("caller_url") or "").lower()

    # Only count strict key matches as distinct keys
    if key in FACEBOOK_KEY_KEYWORDS:
        DISTINCT_KEYS.append(key)
        return True

    # Sometimes the key is generic ("data") but comes from a Facebook script
#    if any(host_frag in caller_url for host_frag in FACEBOOK_HOST_KEYWORDS):
#        return True

    return False


def is_facebook_domain(domain: str) -> bool:
    """Return True if a bare domain (from cname_final_url) is Facebook-related."""
    if not domain:
        return False

    domain = domain.strip().lower().rstrip("/").rstrip(".")

    for fb_host in FACEBOOK_HOST_KEYWORDS:
        fb_host = fb_host.strip().lower().rstrip("/").rstrip(".")
        # exact match or subdomain: something.facebook.com
        if domain == fb_host or domain.endswith("." + fb_host):
            DISTINCT_DOMAINS.append(domain)
            return True

    return False


def is_facebook_url(url: str) -> bool:
    if not url:
        return False

    try:
        parsed = urlparse(url)
    except ValueError:
        return False

    host = parsed.hostname
    if not host:
        return False

    host = host.strip().lower().rstrip("/").rstrip(".")

    return is_facebook_domain(host)


def json_dumps_safe(obj):
    return json.dumps(obj, ensure_ascii=False)


def write_etld_summary_csv(filename, rows):
    if not rows:
        print(f"No rows for {filename}")
        return
    print(f"Writing {len(rows)} rows to {filename}")
    fieldnames = [
        "etld",
        "n_sessions",
        "has_fb_identifiers",
        "has_direct_fb_requests",
        "has_cloaked_fb_requests",
        "category",          # direct / cloaked / silent
        "sessions",
        "fb_keys",
        "fb_direct_requests",
        "fb_cloaked_requests",
        "fb_cname_domains",
    ]
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


def main():
    print(db_params)
    conn = pymysql.connect(**db_params)
    cursor = conn.cursor()

    # 1. Load all candidate sessions (session-level, but we'll aggregate per eTLD)
    session_query = """
        SELECT id, etld, url, user_identifiers
        FROM crawl_sessions
        WHERE category = 'global'
          AND location NOT LIKE '%VPN'
          AND location = 'GERMANY'
          AND (etld_url_rel IS NULL OR etld_url_rel <> 'cross-site')
          AND is_user_identifiers = 1
          AND user_identifiers IS NOT NULL
    """

    cursor.execute(session_query)
    sessions = cursor.fetchall()

    print(f"Loaded {len(sessions)} candidate sessions with user_identifiers")

    # 2. Group rows by eTLD
    etld_to_sessions = defaultdict(list)
    for row in sessions:
        etld = row["etld"]
        etld_to_sessions[etld].append(row)

    print(f"Found {len(etld_to_sessions)} distinct eTLDs")

    etld_summary_rows = []

    # 3. Main loop over distinct eTLDs (site-level analysis)
    for etld, etld_sessions in tqdm(etld_to_sessions.items(),
                                    desc="Processing eTLDs",
                                    total=len(etld_to_sessions)):

        etld_session_ids = {row["id"] for row in etld_sessions}

        etld_has_fb_identifiers = False
        etld_fb_keys = []              # all FB-related storage items across this eTLD

        # --- First pass: collect all storage items across all URLs/sessions of this eTLD ---
        for row in etld_sessions:
            session_id = row["id"]
            user_identifiers_raw = row["user_identifiers"]

            if not user_identifiers_raw:
                continue

            try:
                ui = json.loads(user_identifiers_raw)
            except Exception:
                # Bad JSON – skip this session's identifiers
                continue

            # localStorage
            for entry in ui.get("local_storage_identifiers", []):
                if is_facebook_identifier(entry):
                    etld_has_fb_identifiers = True
                    etld_fb_keys.append({
                        "storage_type": "local_storage",
                        "key": entry.get("key"),
                        "val": entry.get("val"),
                        "caller_url": entry.get("caller_url"),
                        "caller_type": entry.get("caller_type"),
                    })

            # cookies
            for entry in ui.get("cookies_storage_identifiers", []):
                # event_type = entry.get("event_type")
                # if event_type != "storage set":
                #     continue
                if is_facebook_identifier(entry):
                    etld_has_fb_identifiers = True
                    etld_fb_keys.append({
                        "storage_type": "cookie",
                        "key": entry.get("key"),
                        "val": entry.get("val"),
                        "caller_url": entry.get("caller_url"),
                        "caller_type": entry.get("caller_type"),
                    })

            # sessionStorage
            for entry in ui.get("session_storage_identifiers", []):
                if is_facebook_identifier(entry):
                    etld_has_fb_identifiers = True
                    etld_fb_keys.append({
                        "storage_type": "session_storage",
                        "key": entry.get("key"),
                        "val": entry.get("val"),
                        "caller_url": entry.get("caller_url"),
                        "caller_type": entry.get("caller_type"),
                    })

        # If the site (eTLD) never sets any FB identifiers at all -> skip, not relevant
        if not etld_has_fb_identifiers:
            continue

        # --- Second pass: get all requests for all sessions of this eTLD ---
        etld_has_direct_fb = False
        etld_has_cloaked_fb = False
        etld_direct_requests = set()
        etld_cloaked_requests = set()
        etld_cname_domains = set()

        # Build a single query with IN (...) over all session_ids of this eTLD
        session_id_list = list(etld_session_ids)
        placeholders = ", ".join(["%s"] * len(session_id_list))
        request_query = f"""
            SELECT request_url, cname_final_url
            FROM requests
            WHERE session_id IN ({placeholders})
              AND result_status = 'complete'
              AND is_tracker IS TRUE
        """
        cursor.execute(request_query, session_id_list)
        reqs = cursor.fetchall()

        for req in reqs:
            req_url = req["request_url"]
            cname_final = req["cname_final_url"]

            # Direct FB
            if req_url and is_facebook_url(req_url):
                etld_has_direct_fb = True
                etld_direct_requests.add(req_url)

            # Cloaked FB via CNAME
            if cname_final and is_facebook_domain(cname_final):
                etld_has_cloaked_fb = True
                etld_cloaked_requests.add(req_url)
                etld_cname_domains.add(cname_final)

        # --- Decide category purely at eTLD/site level ---
        if etld_has_direct_fb:
            category = "direct"
        elif etld_has_cloaked_fb:
            category = "cloaked"
        else:
            # Has FB identifiers but no FB requests (neither direct nor cloaked)
            category = "silent"

        etld_summary_rows.append({
            "etld": etld,
            "n_sessions": len(etld_session_ids),
            "has_fb_identifiers": etld_has_fb_identifiers,
            "has_direct_fb_requests": etld_has_direct_fb,
            "has_cloaked_fb_requests": etld_has_cloaked_fb,
            "category": category,
            "sessions": json_dumps_safe(sorted(etld_session_ids)),
            "fb_keys": json_dumps_safe(etld_fb_keys),
            "fb_direct_requests": json_dumps_safe(list(etld_direct_requests)),
            "fb_cloaked_requests": json_dumps_safe(list(etld_cloaked_requests)),
            "fb_cname_domains": json_dumps_safe(list(etld_cname_domains)),
        })

    cursor.close()
    conn.close()

    out_dir = "../processed_data/Meta_SST"
    os.makedirs(out_dir, exist_ok=True)

    summary_path = os.path.join(out_dir, "fb_etld_summary.csv")
    write_etld_summary_csv(summary_path, etld_summary_rows)

    # Some quick counts by category
    n_direct = sum(1 for r in etld_summary_rows if r["category"] == "direct")
    n_cloaked = sum(1 for r in etld_summary_rows if r["category"] == "cloaked")
    n_silent = sum(1 for r in etld_summary_rows if r["category"] == "silent")

    print("\n========== ETLD-LEVEL SUMMARY ==========")
    print(f"Total eTLDs with FB identifiers: {len(etld_summary_rows)}")
    print(f"Direct Facebook eTLDs : {n_direct}")
    print(f"Cloaked Facebook eTLDs: {n_cloaked}")
    print(f"Silent Facebook eTLDs : {n_silent}")
    print("=========================================\n")

    print("Distinct Facebook-related keys found:", set(DISTINCT_KEYS))
    print("Distinct Facebook-related domains found:", set(DISTINCT_DOMAINS))

    print("Done.")


if __name__ == "__main__":
    main()
