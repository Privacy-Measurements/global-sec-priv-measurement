import pymysql
from collections import defaultdict
import statistics
from concurrent.futures import ProcessPoolExecutor, as_completed

db_params = {
    "host": "localhost",
    "user": "cursor",
    "password": "whaTaShame",
    "db": "crawl_analysis_new",
    "cursorclass": pymysql.cursors.DictCursor,
}

TARGET_LOCATIONS = ( "GERMANY", "ALGERIA", "USA", "INDIA")
NUM_CORES = 32


def load_sessions():
    sql = """
        SELECT id, location
        FROM crawl_sessions
        WHERE category = 'global'
          AND location IN (%s, %s, %s, %s)
    """
    conn = pymysql.connect(**db_params)
    with conn.cursor() as cur:
        cur.execute(sql, TARGET_LOCATIONS)
        rows = cur.fetchall()
    conn.close()
    return rows


def load_requests_and_script_sets(session_ids_chunk):
    """
    Load:
      - requests (request.id + parent_id) for sessions
      - scripts.script_id set per session
      - html_elements.element_id set per session
      - html_elements.parent_id set per session
    """
    requests_by_session = defaultdict(list)
    scripts_by_session = defaultdict(set)
    html_elements_by_session = defaultdict(set)
    html_parent_ids_by_session = defaultdict(set)

    if not session_ids_chunk:
        return (
            requests_by_session,
            scripts_by_session,
            html_elements_by_session,
            html_parent_ids_by_session,
        )

    placeholders = ",".join(["%s"] * len(session_ids_chunk))

    conn = pymysql.connect(**db_params)
    try:
        with conn.cursor() as cur:
            # ---- Requests (include request.id for examples) ----
            sql = f"""
                SELECT id AS request_id, session_id, parent_id
                FROM requests
                WHERE session_id IN ({placeholders})
            """
            cur.execute(sql, session_ids_chunk)
            for r in cur.fetchall():
                requests_by_session[r["session_id"]].append(r)

            # ---- Scripts table (script_id) ----
            sql = f"""
                SELECT session_id, script_id
                FROM scripts
                WHERE session_id IN ({placeholders})
                  AND script_id IS NOT NULL
            """
            cur.execute(sql, session_ids_chunk)
            for r in cur.fetchall():
                scripts_by_session[r["session_id"]].add(r["script_id"])

            # ---- html_elements table (element_id + parent_id) ----
            sql = f"""
                SELECT session_id, element_id, parent_id
                FROM html_elements
                WHERE session_id IN ({placeholders})
            """
            cur.execute(sql, session_ids_chunk)
            for r in cur.fetchall():
                sid = r["session_id"]
                if r.get("element_id"):
                    html_elements_by_session[sid].add(r["element_id"])
                if r.get("parent_id"):
                    html_parent_ids_by_session[sid].add(r["parent_id"])

    finally:
        conn.close()

    return (
        requests_by_session,
        scripts_by_session,
        html_elements_by_session,
        html_parent_ids_by_session,
    )


def analyze_session(args):
    """
    Denominator: requests with parent_id present (non-empty).

    Counts "found" if requests.parent_id is in:
      - scripts.script_id
      - html_elements.element_id
      - html_elements.parent_id
      - any of the above

    Also splits NOT FOUND cases into:
      - parent_id == 'n48'
      - parent_id != 'n48'

    Returns dict with totals + per-session % + up to 1 example for this session where parent_id
    was not found in ANY of those sets.
    """
    sid, reqs, scripts_set, html_scripts_set, html_parent_ids_set = args

    total_requests = len(reqs)
    if total_requests == 0:
        return {
            "session_id": sid,
            "total_requests": 0,
            "parent_present": 0,
            "found_scripts": 0,
            "found_html_script_id": 0,
            "found_html_parent_id": 0,
            "found_any": 0,
            "pct_scripts": 0.0,
            "pct_html_script_id": 0.0,
            "pct_html_parent_id": 0.0,
            "pct_any": 0.0,
            "not_found_n48": 0,
            "not_found_other": 0,
            "not_found_total": 0,
            "not_found_examples": [],
        }

    parent_present = 0
    found_scripts = 0
    found_html_script_id = 0
    found_html_parent_id = 0
    found_any = 0

    not_found_n48 = 0
    not_found_other = 0

    not_found_examples = []  # at most 1 per session

    for r in reqs:
        parent = r.get("parent_id")
        if not parent:
            continue

        parent_present += 1

        in_scripts = parent in scripts_set
        in_html_script_id = parent in html_scripts_set
        in_html_parent_id = parent in html_parent_ids_set

        if in_scripts:
            found_scripts += 1
        if in_html_script_id:
            found_html_script_id += 1
        if in_html_parent_id:
            found_html_parent_id += 1

        if in_scripts or in_html_script_id or in_html_parent_id:
            found_any += 1
        else:
            if parent == "n48":
                not_found_n48 += 1
            else:
                not_found_other += 1

            # keep only ONE example per session
            if not not_found_examples:
                not_found_examples.append(
                    {
                        "session_id": sid,
                        "request_id": r.get("request_id"),
                        "parent_id": parent,
                    }
                )

    denom = parent_present if parent_present > 0 else 1
    not_found_total = not_found_n48 + not_found_other

    return {
        "session_id": sid,
        "total_requests": total_requests,
        "parent_present": parent_present,
        "found_scripts": found_scripts,
        "found_html_script_id": found_html_script_id,
        "found_html_parent_id": found_html_parent_id,
        "found_any": found_any,
        "pct_scripts": found_scripts / denom,
        "pct_html_script_id": found_html_script_id / denom,
        "pct_html_parent_id": found_html_parent_id / denom,
        "pct_any": found_any / denom,
        "not_found_n48": not_found_n48,
        "not_found_other": not_found_other,
        "not_found_total": not_found_total,
        "not_found_examples": not_found_examples,
    }


def main():
    sessions = load_sessions()
    session_ids = [s["id"] for s in sessions]
    print(f"Loaded {len(session_ids)} sessions")

    # ---- Parallel loading ----
    chunk_size = max(len(session_ids) // NUM_CORES, 1)
    chunks = [session_ids[i:i + chunk_size] for i in range(0, len(session_ids), chunk_size)]

    requests_by_session = defaultdict(list)
    scripts_by_session = defaultdict(set)
    html_elements_by_session = defaultdict(set)
    html_parent_ids_by_session = defaultdict(set)

    with ProcessPoolExecutor(max_workers=NUM_CORES) as executor:
        futures = [executor.submit(load_requests_and_script_sets, chunk) for chunk in chunks]
        for future in as_completed(futures):
            req_chunk, scr_chunk, html_scr_chunk, html_pid_chunk = future.result()

            for sid, lst in req_chunk.items():
                requests_by_session[sid].extend(lst)

            for sid, sset in scr_chunk.items():
                scripts_by_session[sid].update(sset)

            for sid, hset in html_scr_chunk.items():
                html_elements_by_session[sid].update(hset)

            for sid, pset in html_pid_chunk.items():
                html_parent_ids_by_session[sid].update(pset)

    # ---- Parallel session analysis ----
    session_args = [
        (
            sid,
            requests_by_session.get(sid, []),
            scripts_by_session.get(sid, set()),
            html_elements_by_session.get(sid, set()),
            html_parent_ids_by_session.get(sid, set()),
        )
        for sid in session_ids
    ]

    total_requests = 0
    total_parent_present = 0
    total_found_scripts = 0
    total_found_html_script_id = 0
    total_found_html_parent_id = 0
    total_found_any = 0

    total_not_found_n48 = 0
    total_not_found_other = 0

    pct_scripts_list = []
    pct_html_script_id_list = []
    pct_html_parent_id_list = []
    pct_any_list = []

    not_found_global_examples = []
    not_found_example_sessions = set()  # ensure examples come from different sessions

    with ProcessPoolExecutor(max_workers=NUM_CORES) as executor:
        futures = [executor.submit(analyze_session, args) for args in session_args]
        for future in as_completed(futures):
            r = future.result()

            total_requests += r["total_requests"]
            total_parent_present += r["parent_present"]
            total_found_scripts += r["found_scripts"]
            total_found_html_script_id += r["found_html_script_id"]
            total_found_html_parent_id += r["found_html_parent_id"]
            total_found_any += r["found_any"]

            total_not_found_n48 += r.get("not_found_n48", 0)
            total_not_found_other += r.get("not_found_other", 0)

            if r["parent_present"] > 0:
                pct_scripts_list.append(r["pct_scripts"])
                pct_html_script_id_list.append(r["pct_html_script_id"])
                pct_html_parent_id_list.append(r["pct_html_parent_id"])
                pct_any_list.append(r["pct_any"])

            # collect up to 5 global examples, each from a different session
            for ex in r["not_found_examples"]:
                if len(not_found_global_examples) >= 5:
                    break
                sid = ex["session_id"]
                if sid in not_found_example_sessions:
                    continue
                not_found_example_sessions.add(sid)
                not_found_global_examples.append(ex)

    def safe_ratio(a, b):
        return a / b if b > 0 else 0.0

    overall_pct_scripts = safe_ratio(total_found_scripts, total_parent_present)
    overall_pct_html_script_id = safe_ratio(total_found_html_script_id, total_parent_present)
    overall_pct_html_parent_id = safe_ratio(total_found_html_parent_id, total_parent_present)
    overall_pct_any = safe_ratio(total_found_any, total_parent_present)

    avg_pct_scripts = sum(pct_scripts_list) / len(pct_scripts_list) if pct_scripts_list else 0.0
    avg_pct_html_script_id = (
        sum(pct_html_script_id_list) / len(pct_html_script_id_list) if pct_html_script_id_list else 0.0
    )
    avg_pct_html_parent_id = (
        sum(pct_html_parent_id_list) / len(pct_html_parent_id_list) if pct_html_parent_id_list else 0.0
    )
    avg_pct_any = sum(pct_any_list) / len(pct_any_list) if pct_any_list else 0.0

    med_pct_scripts = statistics.median(pct_scripts_list) if pct_scripts_list else 0.0
    med_pct_html_script_id = statistics.median(pct_html_script_id_list) if pct_html_script_id_list else 0.0
    med_pct_html_parent_id = statistics.median(pct_html_parent_id_list) if pct_html_parent_id_list else 0.0
    med_pct_any = statistics.median(pct_any_list) if pct_any_list else 0.0

    total_not_found = total_not_found_n48 + total_not_found_other

    print("\n=== RESULTS (denominator = requests with parent_id present) ===")
    print(f"Total requests: {total_requests}")
    print(f"Requests with parent_id: {total_parent_present}")

    print("\n-- Found counts --")
    print(f"Found in scripts.script_id:                 {total_found_scripts}")
    print(f"Found in html_elements.element_id:          {total_found_html_script_id}")
    print(f"Found in html_elements.parent_id:           {total_found_html_parent_id}")
    print(f"Found in ANY of the above:                  {total_found_any}")

    print("\n-- Not found (parent present but NOT found in ANY set) --")
    print(f"Total not found:                            {total_not_found}")
    print(f"Not found where parent_id == 'n48':         {total_not_found_n48}")
    print(f"Not found where parent_id != 'n48':         {total_not_found_other}")

    print("\n-- Overall % (found / parent present) --")
    print(f"scripts.script_id:                 {overall_pct_scripts:.4f}")
    print(f"html_elements.element_id:          {overall_pct_html_script_id:.4f}")
    print(f"html_elements.parent_id:           {overall_pct_html_parent_id:.4f}")
    print(f"ANY:                               {overall_pct_any:.4f}")

    print("\n-- Not found % of parent_present --")
    print(f"Not found overall:                 {safe_ratio(total_not_found, total_parent_present):.4f}")
    print(f"Not found (parent_id == 'n48'):    {safe_ratio(total_not_found_n48, total_parent_present):.4f}")
    print(f"Not found (parent_id != 'n48'):    {safe_ratio(total_not_found_other, total_parent_present):.4f}")

    print("\n-- Avg per-session % --")
    print(f"scripts.script_id:                 {avg_pct_scripts:.4f}")
    print(f"html_elements.element_id:          {avg_pct_html_script_id:.4f}")
    print(f"html_elements.parent_id:           {avg_pct_html_parent_id:.4f}")
    print(f"ANY:                               {avg_pct_any:.4f}")

    print("\n-- Median per-session % --")
    print(f"scripts.script_id:                 {med_pct_scripts:.4f}")
    print(f"html_elements.element_id:          {med_pct_html_script_id:.4f}")
    print(f"html_elements.parent_id:           {med_pct_html_parent_id:.4f}")
    print(f"ANY:                               {med_pct_any:.4f}")

    print("\n=== EXAMPLES: parent_id NOT FOUND in ANY set (different sessions) ===")
    if not not_found_global_examples:
        print("No examples found 🎉")
    else:
        for i, ex in enumerate(not_found_global_examples, 1):
            print(
                f"{i}. crawl_session.id={ex['session_id']} | "
                f"request.id={ex['request_id']} | "
                f"parent_id={ex['parent_id']}"
            )


if __name__ == "__main__":
    main()
