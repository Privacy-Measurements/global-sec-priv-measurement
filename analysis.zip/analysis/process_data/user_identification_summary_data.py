import pymysql
import pandas as pd
import json
from urllib.parse import urlparse
import os
import tldextract
from tqdm import tqdm
from functools import partial
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import csv
import numpy as np


db_params = {
    "host": "localhost",
    "user": "cursor",
    "password": "whaTaShame",
    "db": "crawl_analysis_new",
    "cursorclass": pymysql.cursors.DictCursor
}

identifiers_file = 'data/identifiers/all_identifiers.csv'
first_party_file = 'data/identifiers/first_party_identifiers.csv'
third_party_file = 'data/identifiers/third_party_identifiers.csv'
identifiers_summary_file = 'data/identifiers/sites_identifiers_summary.csv'
D1_comparison_file = 'data/identifiers/D1_comparison.json'

def normalize_url(u):
    try:
        parsed = urlparse(u)
        return urlunparse((parsed.scheme, parsed.netloc, parsed.path, '', '', ''))
    except Exception:
        return u

def is_valid_url(url):
    return url.startswith(('http://', 'https://'))


def load_crawl_sessions(conn_params):
    sql = """
        SELECT id, etld, url, category, location, user_identifiers, is_user_identifiers
        FROM crawl_sessions where 
          category NOT LIKE '%validation'
          AND location NOT LIKE '%VPN'
          AND etld_url_rel <> 'cross-site'
    """
    conn = pymysql.connect(**conn_params)
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            rows = cursor.fetchall()
            df = pd.DataFrame(rows)
    finally:
        conn.close()
    return df



def fetch_scripts_by_etld(etld, conn_params):
    sql = """
        SELECT 
            script.id, 
            script.script_src,
            script.script_hash, 
            script.etld_script_src_rel,
            session.url AS session_url, 
            session.id AS session_id, 
            session.location
        FROM scripts script
        JOIN crawl_sessions session ON script.session_id = session.id
        WHERE session.etld = %s
          AND session.category NOT LIKE '%%validation'
          AND session.location NOT LIKE '%%VPN'
          AND session.etld_url_rel <> 'cross-site'
    """

    params = [etld]

    conn = pymysql.connect(**conn_params)
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute(sql, tuple(params))
            rows = cursor.fetchall()
            df = pd.DataFrame(rows)
    finally:
        conn.close()

    if df.empty:
        cols = ['id', 'script_src', 'script_hash', 'etld_script_src_rel', 'session_url', 'normalized_url', 'session_id', 'location']
        df = pd.DataFrame(columns=cols)

        return df

    df['normalized_url'] = df['session_url'].apply(normalize_url)
    return df


def expand_identifiers(df_sessions: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in df_sessions.iterrows():
        id_json = row.get('user_identifiers')
        if not id_json:
            continue
        if isinstance(id_json, str):
            id_json = json.loads(id_json)

        for id_type, id_entries in id_json.items():
            if not id_entries:
                continue

            for entry in id_entries:

                if 'event_type' in entry and entry['event_type'] != ' storage set':
                    continue

                entry_row = {
                    'etld': row['etld'],
                    'current_url': row['url'],
                    'location': row['location'],
                    'category': row['category'],
                    'id_type': id_type,
                    'key': entry['key'],
                    'val': entry['val'],
                    'caller_id': entry['caller_id'],
                    'caller_url': entry['caller_url'],
                    'caller_hash': entry['caller_hash'],
                }

                entry_row.update(entry)
                caller_url = entry_row['caller_url']
                
                if caller_url and is_valid_url(caller_url):
                    
                    parsed = tldextract.extract(caller_url)

                    if parsed.suffix:
                        origin = '.'.join([parsed.subdomain, parsed.domain, parsed.suffix]).strip('.')
                        domain = parsed.domain + '.' + parsed.suffix
                    else:
                        origin = parsed.domain
                        domain = parsed.domain

                    entry_row['caller_origin'] = origin
                    entry_row['caller_domain'] = domain

                else:
                    entry_row['caller_origin'] = ''
                    entry_row['caller_domain'] = ''

                rows.append(entry_row)

    id_df = pd.DataFrame(rows)
    total_rows_before = len(id_df)

    id_df = id_df[~id_df['val'].apply(lambda x: isinstance(x, list))].reset_index(drop=True)
    skipped_rows = total_rows_before - len(id_df)

    print(f"Skipped {skipped_rows} rows where 'val' was a list ({skipped_rows/total_rows_before*100:.2f}%)")

    id_df = id_df.drop_duplicates(ignore_index=True)

    id_df['normalized_url'] = id_df['current_url'].apply(normalize_url)

    return id_df


def is_first_party(caller_url, current_url):
    # Ensure both URLs are strings

    caller_url = caller_url if isinstance(caller_url, str) else ''
    current_url = current_url if isinstance(current_url, str) else ''
    
    if caller_url == '' or current_url == '': #if its empty, than its first party 
        return True

    caller_domain = tldextract.extract(caller_url).domain + '.' + tldextract.extract(caller_url).suffix
    current_domain = tldextract.extract(current_url).domain + '.' + tldextract.extract(current_url).suffix

    return caller_domain == current_domain

    
def split_first_third_party(df):
    # Determine first vs third party based on caller_url vs current_url

    df['is_first_party'] = df.apply(lambda r: is_first_party(r.get('caller_url',''), r['current_url']), axis=1)
    first_party_df = df[df['is_first_party']].copy()
    third_party_df = df[~df['is_first_party']].copy()
    return first_party_df, third_party_df





def process_site(etld, category, location, id_dict, first_dict, third_dict):
    fname = f"{category}_{location}_{etld.replace('.', '_')}.json"
    out_path = os.path.join(PER_SITE_DIR, fname)

    if os.path.exists(out_path):
        print('file exists, skipping', out_path)
        return None

    subset = id_dict.get((etld, category, location), pd.DataFrame())
    first_rows = first_dict.get((etld, category, location), pd.DataFrame())
    third_rows = third_dict.get((etld, category, location), pd.DataFrame())

    result = {
        "etld": etld,
        "category": category,
        "location": location,
        "num_ids": len(subset),
        "has_first_party": not first_rows.empty,
        "has_third_party": not third_rows.empty,
        "distinct_callers": subset["caller_url"].dropna().unique().tolist() if not subset.empty else [],
        "distinct_third_party_domains": third_rows["caller_domain"].dropna().unique().tolist() if not third_rows.empty else [],
        "distinct_third_party_origins": third_rows["caller_origin"].dropna().unique().tolist() if not third_rows.empty else [],
        "id_type_counts": subset["id_type"].value_counts().to_dict() if not subset.empty else {}
    }

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print('file written to ', out_path)
    return result


def pregroup_ids(df):
    """
    Pre-group a DataFrame by (category, location, etld) into a dictionary for fast lookup.
    """
    grouped = {}
    for (cat, loc, etld), group in df.groupby(['category', 'location', 'etld']):
        grouped[(etld, cat, loc)] = group
    return grouped



def process_site_summary(etld, category, location, id_dict, first_dict, third_dict):
    subset = id_dict.get((etld, category, location), pd.DataFrame())
    first_rows = first_dict.get((etld, category, location), pd.DataFrame())
    third_rows = third_dict.get((etld, category, location), pd.DataFrame())

    summary_row = {
        "etld": etld,
        "category": category,
        "location": location,
        "num_ids": len(subset),
        "has_first_party": not first_rows.empty,
        "has_third_party": not third_rows.empty,
        "distinct_callers_count": subset["caller_url"].nunique() if not subset.empty else 0,
        "distinct_third_party_domains_count": third_rows["caller_domain"].nunique() if not third_rows.empty else 0,
        "distinct_third_party_origins_count": third_rows["caller_origin"].nunique() if not third_rows.empty else 0,
        "id_types": ','.join(subset["id_type"].unique()) if not subset.empty else ""
    }
    return summary_row



def build_site_summaries(df_sessions, id_df, first_df, third_df, max_workers=16):
    # Pre-group identifiers
    id_dict = pregroup_ids(id_df)
    first_dict = pregroup_ids(first_df)
    third_dict = pregroup_ids(third_df)

    # Pre-group crawl_sessions for unique sites
    unique_sites = df_sessions[['etld', 'category', 'location']].drop_duplicates()
    tasks = [(row.etld, row.category, row.location) for _, row in unique_sites.iterrows()]

    all_rows = []

    # Use threads to process each site
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(process_site_summary, etld, category, location, id_dict, first_dict, third_dict)
            for etld, category, location in tasks
        ]
        for f in tqdm(as_completed(futures), total=len(futures), desc="Processing site summaries"):
            row = f.result()
            if row:
                all_rows.append(row)

    summary_df = pd.DataFrame(all_rows)
    os.makedirs(os.path.dirname(identifiers_summary_file), exist_ok=True)
    summary_df.to_csv(identifiers_summary_file, index=False, quoting=csv.QUOTE_ALL)
    print(f"Saved site summaries to {identifiers_summary_file}")



    

if __name__ == "__main__":
    df_sessions = load_crawl_sessions(db_params)
    print(f"Loaded {len(df_sessions)}  crawl sessions")
    df_sessions.to_csv('data/identifiers/crawl_sessions.csv', index=False, quoting=csv.QUOTE_ALL, quotechar='"', escapechar='\\')

    id_df = expand_identifiers(df_sessions)
    print(f"Expanded to {len(id_df)} id entries")

    os.makedirs(os.path.dirname(identifiers_file), exist_ok=True)
    id_df.to_csv(identifiers_file, index=False, quoting=csv.QUOTE_ALL, quotechar='"', escapechar='\\')
    print(f"Saved all identifiers entries to {identifiers_file}")

    first_id, third_id = split_first_third_party(id_df)

    os.makedirs(os.path.dirname(first_party_file), exist_ok=True)
    first_id.to_csv(first_party_file, index=False, quoting=csv.QUOTE_ALL, quotechar='"', escapechar='\\')
    print(f"Saved first-party fingerprinting to {first_party_file}")

    os.makedirs(os.path.dirname(third_party_file), exist_ok=True, )
    third_id.to_csv(third_party_file, index=False, quoting=csv.QUOTE_ALL, quotechar='"', escapechar='\\')
    print(f"Saved third-party fingerprinting to {third_party_file}")

    build_site_summaries(df_sessions, id_df, first_id, third_id, max_workers=8)

